import { module, test } from 'qunit';
import { setupRenderingTest } from 'ember-qunit';
import { render } from '@ember/test-helpers';
import hbs from 'htmlbars-inline-precompile';

module('Integration | Component | etb-deeplinking', function(hooks) {
  setupRenderingTest(hooks);

  test('it renders', async function(assert) {
    assert.expect(3);
    this.label="{'label1': 'label', 'label2': 'labelTxt', 'buttonLabel':'LOGIN'}";

    await render(hbs`{{etb-deeplinking label=label}}`);
    assert.dom(".main-division .sub-division label").hasText("label");
    assert.dom(".main-division .sub-division .content").hasText("labelTxt");
    assert.dom(".main-division .rdc-button").hasText("LOGIN");

  });
});
