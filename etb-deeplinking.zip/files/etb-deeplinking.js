import Component from '@ember/component';
import layout from '../templates/components/etb-deeplinking';
import { isEmpty } from '@ember/utils';

export default Component.extend({
  layout,
  classNames: ['rdc-component-base etb-deeplinking'],
  action:() => {},

  init(){
    this._super(...arguments)
    if(!isEmpty(this.label)){
      let responseLabel = JSON.parse(this.label.replace(/'/g,'"'));
      this.set("responseLabel",responseLabel);
    }
  },

  actions:{
    onLogin(){
      this.action();
    }
  }
});
