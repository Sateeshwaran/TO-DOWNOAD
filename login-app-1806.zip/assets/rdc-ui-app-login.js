'use strict';



;define("rdc-ui-app-login/adapters/account-proxy", ["exports", "rdc-ui-adn-core/adapters/account-proxy"], function (_exports, _accountProxy) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _accountProxy.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/application", ["exports", "rdc-ui-adn-core/adapters/application"], function (_exports, _application) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _application.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/authorize", ["exports", "rdc-ui-app-login/utils/constants", "rdc-ui-adn-core/adapters/application"], function (_exports, _constants, _application) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = _application.default.extend({
    cslLoginHeaders: Ember.inject.service(),
    rdcAjax: Ember.inject.service(),

    ajaxOptions(url, type, options = {}) {
      let hash = this._super(url, type, options);

      hash.headers = hash.headers || {};
      hash.headers['Accept'] = "application/json";
      hash.headers["Content-Type"] = "application/json";
      hash.headers["X-Market"] = this.rdcAjax.countryHeader(location.pathname);
      let beforeSend = hash.beforeSend;

      hash.beforeSend = function (xhr) {
        if (beforeSend) {
          beforeSend(xhr);
        }

        xhr.setRequestHeader('Accept', 'application/json');
      };

      return hash;
    },

    urlForQuery() {
      return _constants.default.openAPIURL(window.location.hostname).AUTH_GRANT + this.cslLoginHeaders.queryParams;
    },

    urlForFindAll() {
      return _constants.default.openAPIURL(window.location.hostname).AUTH_GRANT + this.cslLoginHeaders.queryParams;
    }

  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/adapters/bank", ["exports", "rdc-ui-adn-core/adapters/bank"], function (_exports, _bank) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _bank.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/barcode", ["exports", "rdc-ui-adn-core/adapters/barcode"], function (_exports, _barcode) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _barcode.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/branch", ["exports", "rdc-ui-adn-core/adapters/branch"], function (_exports, _branch) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _branch.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/challenge-otp-validation", ["exports", "rdc-ui-adn-core/adapters/challenge-otp-validation"], function (_exports, _challengeOtpValidation) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _challengeOtpValidation.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/country", ["exports", "rdc-ui-adn-core/adapters/country"], function (_exports, _country) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _country.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/cryptokey", ["exports", "rdc-ui-adn-core/adapters/cryptokey"], function (_exports, _cryptokey) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _cryptokey.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/delivery-ack", ["exports", "rdc-ui-adn-core/adapters/delivery-ack"], function (_exports, _deliveryAck) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _deliveryAck.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/detail", ["exports", "rdc-ui-adn-core/adapters/detail"], function (_exports, _detail) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _detail.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/device-registration-feature", ["exports", "rdc-ui-adn-core/adapters/device-registration-feature"], function (_exports, _deviceRegistrationFeature) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _deviceRegistrationFeature.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/device-registration", ["exports", "rdc-ui-adn-core/adapters/device-registration"], function (_exports, _deviceRegistration) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _deviceRegistration.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/hr-login", ["exports", "rdc-ui-adn-core/adapters/application"], function (_exports, _application) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  // import fetch from 'fetch';
  var _default = _application.default.extend({
    // namespace: 'api',
    // queryRecord(store,type,query) {
    //   return fetch(namespace)
    // },
    // namespace: 'retail/api/v3'
    buildURL: function (modelName, id, snapshot, requestType, query) {
      if (requestType === 'queryRecord') {
        let url = this._super(modelName, query.id);

        delete query.id;
        return url;
      } else {
        return this._super(modelName, id, snapshot, requestType, query);
      }
    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/adapters/location", ["exports", "rdc-ui-adn-core/adapters/location"], function (_exports, _location) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _location.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/message", ["exports", "rdc-ui-adn-core/adapters/message"], function (_exports, _message) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _message.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/notification", ["exports", "rdc-ui-adn-core/adapters/notification"], function (_exports, _notification) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _notification.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/payment", ["exports", "rdc-ui-adn-core/adapters/payment"], function (_exports, _payment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _payment.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/pop", ["exports", "rdc-ui-adn-core/adapters/pop"], function (_exports, _pop) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _pop.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/reference", ["exports", "rdc-ui-adn-core/adapters/reference"], function (_exports, _reference) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _reference.default;
    }
  });
});
;define("rdc-ui-app-login/adapters/soft-token-activation", ["exports", "rdc-ui-adn-core/adapters/soft-token-activation"], function (_exports, _softTokenActivation) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _softTokenActivation.default;
    }
  });
});
;define("rdc-ui-app-login/app", ["exports", "rdc-ui-app-login/resolver", "ember-load-initializers", "rdc-ui-app-login/config/environment"], function (_exports, _resolver, _emberLoadInitializers, _environment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  const App = Ember.Application.extend({
    modulePrefix: _environment.default.modulePrefix,
    podModulePrefix: _environment.default.podModulePrefix,
    Resolver: _resolver.default
  });
  (0, _emberLoadInitializers.default)(App, _environment.default.modulePrefix);
  var _default = App;
  _exports.default = _default;
});
;define("rdc-ui-app-login/authenticators/axway", ["exports", "rdc-ui-adn-core/authenticators/axway"], function (_exports, _axway) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _axway.default;
    }
  });
});
;define("rdc-ui-app-login/authenticators/bsoi-login", ["exports", "rdc-ui-adn-core/authenticators/bsoi-login"], function (_exports, _bsoiLogin) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _bsoiLogin.default;
    }
  });
});
;define("rdc-ui-app-login/authenticators/credit-card", ["exports", "rdc-ui-adn-core/authenticators/credit-card"], function (_exports, _creditCard) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _creditCard.default;
    }
  });
});
;define("rdc-ui-app-login/authenticators/csl-login", ["exports", "rdc-ui-adn-core/authenticators/csl-login"], function (_exports, _cslLogin) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _cslLogin.default;
    }
  });
});
;define("rdc-ui-app-login/authenticators/otp-authenticator", ["exports", "rdc-ui-adn-core/authenticators/otp-authenticator"], function (_exports, _otpAuthenticator) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _otpAuthenticator.default;
    }
  });
});
;define("rdc-ui-app-login/authenticators/rdc-landing-authenticator", ["exports", "rdc-ui-adn-core/authenticators/rdc-landing-authenticator"], function (_exports, _rdcLandingAuthenticator) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcLandingAuthenticator.default;
    }
  });
});
;define("rdc-ui-app-login/authenticators/trusted-application-authenticator", ["exports", "rdc-ui-adn-core/authenticators/trusted-application-authenticator"], function (_exports, _trustedApplicationAuthenticator) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _trustedApplicationAuthenticator.default;
    }
  });
});
;define("rdc-ui-app-login/breakpoints", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    mobile: '(min-width: 320px) and (max-width: 767px)'
    /* Mobile Specific */
    ,
    tablet: '(min-width: 768px) and (max-width: 991px)'
    /* Tablet specific */
    ,
    landscapeOrientation: '(orientation: landscape)',
    tabletLandscape: '(min-width: 992px)'
    /* Tablet landscape Specific */
    ,
    desktop: '(min-width: 1200px)'
    /* Desktop and Above */
    ,
    jumbo: '(min-width: 1201px)'
    /* Jumbo */

  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/components/-lf-get-outlet-state", ["exports", "liquid-fire/components/-lf-get-outlet-state"], function (_exports, _lfGetOutletState) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _lfGetOutletState.default;
    }
  });
});
;define("rdc-ui-app-login/components/app-link", ["exports", "rdc-ui-adn-components/components/app-link"], function (_exports, _appLink) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _appLink.default;
    }
  });
});
;define("rdc-ui-app-login/components/basic-dropdown", ["exports", "ember-basic-dropdown/components/basic-dropdown"], function (_exports, _basicDropdown) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _basicDropdown.default;
    }
  });
});
;define("rdc-ui-app-login/components/basic-dropdown/content-element", ["exports", "ember-basic-dropdown/components/basic-dropdown/content-element"], function (_exports, _contentElement) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _contentElement.default;
    }
  });
});
;define("rdc-ui-app-login/components/basic-dropdown/content", ["exports", "ember-basic-dropdown/components/basic-dropdown/content"], function (_exports, _content) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _content.default;
    }
  });
});
;define("rdc-ui-app-login/components/basic-dropdown/trigger", ["exports", "ember-basic-dropdown/components/basic-dropdown/trigger"], function (_exports, _trigger) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _trigger.default;
    }
  });
});
;define("rdc-ui-app-login/components/before-options", ["exports", "rdc-ui-adn-component-form-select/components/before-options"], function (_exports, _beforeOptions) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _beforeOptions.default;
    }
  });
});
;define("rdc-ui-app-login/components/biometric-auth", ["exports", "rdc-ui-adn-core/components/biometric-auth"], function (_exports, _biometricAuth) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _biometricAuth.default;
    }
  });
});
;define("rdc-ui-app-login/components/bm-menu-item", ["exports", "rdc-ui-adn-components/components/bm-menu-item"], function (_exports, _bmMenuItem) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _bmMenuItem.default;
    }
  });
});
;define("rdc-ui-app-login/components/bm-menu", ["exports", "rdc-ui-adn-components/components/bm-menu"], function (_exports, _bmMenu) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _bmMenu.default;
    }
  });
});
;define("rdc-ui-app-login/components/bm-outlet", ["exports", "rdc-ui-adn-components/components/bm-outlet"], function (_exports, _bmOutlet) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _bmOutlet.default;
    }
  });
});
;define("rdc-ui-app-login/components/burger-menu", ["exports", "rdc-ui-adn-components/components/burger-menu"], function (_exports, _burgerMenu) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _burgerMenu.default;
    }
  });
});
;define("rdc-ui-app-login/components/credit-card-input", ["exports", "ember-inputmask/components/credit-card-input"], function (_exports, _creditCardInput) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _creditCardInput.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/components/currency-input", ["exports", "ember-inputmask/components/currency-input"], function (_exports, _currencyInput) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _currencyInput.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/components/date-input", ["exports", "ember-inputmask/components/date-input"], function (_exports, _dateInput) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _dateInput.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/components/dialog/rdc-full-screen-dialog", ["exports", "rdc-ui-adn-components/components/dialog/rdc-full-screen-dialog"], function (_exports, _rdcFullScreenDialog) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcFullScreenDialog.default;
    }
  });
});
;define("rdc-ui-app-login/components/email-input", ["exports", "ember-inputmask/components/email-input"], function (_exports, _emailInput) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _emailInput.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/components/ember-chart", ["exports", "ember-cli-chart/components/ember-chart"], function (_exports, _emberChart) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _emberChart.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/components/ember-wormhole", ["exports", "ember-wormhole/components/ember-wormhole"], function (_exports, _emberWormhole) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _emberWormhole.default;
    }
  });
});
;define("rdc-ui-app-login/components/external-link", ["exports", "rdc-ui-adn-components/components/external-link"], function (_exports, _externalLink) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _externalLink.default;
    }
  });
});
;define("rdc-ui-app-login/components/file-dropzone", ["exports", "ember-file-upload/components/file-dropzone/component"], function (_exports, _component) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _component.default;
    }
  });
});
;define("rdc-ui-app-login/components/file-upload", ["exports", "ember-file-upload/components/file-upload/component"], function (_exports, _component) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _component.default;
    }
  });
});
;define("rdc-ui-app-login/components/illiquid-model", ["exports", "liquid-fire/components/illiquid-model"], function (_exports, _illiquidModel) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _illiquidModel.default;
    }
  });
});
;define("rdc-ui-app-login/components/input-mask", ["exports", "ember-inputmask/components/input-mask"], function (_exports, _inputMask) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _inputMask.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/components/layout/rdc-button-group", ["exports", "rdc-ui-adn-components/components/layout/rdc-button-group"], function (_exports, _rdcButtonGroup) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcButtonGroup.default;
    }
  });
});
;define("rdc-ui-app-login/components/layout/rdc-translucent-overlay", ["exports", "rdc-ui-adn-components/components/layout/rdc-translucent-overlay"], function (_exports, _rdcTranslucentOverlay) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcTranslucentOverlay.default;
    }
  });
});
;define("rdc-ui-app-login/components/legacy-ae-android-link", ["exports", "rdc-ui-adn-components/components/legacy-ae-android-link"], function (_exports, _legacyAeAndroidLink) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _legacyAeAndroidLink.default;
    }
  });
});
;define("rdc-ui-app-login/components/legacy-link", ["exports", "rdc-ui-adn-components/components/legacy-link"], function (_exports, _legacyLink) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _legacyLink.default;
    }
  });
});
;define("rdc-ui-app-login/components/legacy-native-link", ["exports", "rdc-ui-adn-components/components/legacy-native-link"], function (_exports, _legacyNativeLink) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _legacyNativeLink.default;
    }
  });
});
;define("rdc-ui-app-login/components/liquid-bind", ["exports", "liquid-fire/components/liquid-bind"], function (_exports, _liquidBind) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _liquidBind.default;
    }
  });
});
;define("rdc-ui-app-login/components/liquid-child", ["exports", "liquid-fire/components/liquid-child"], function (_exports, _liquidChild) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _liquidChild.default;
    }
  });
});
;define("rdc-ui-app-login/components/liquid-container", ["exports", "liquid-fire/components/liquid-container"], function (_exports, _liquidContainer) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _liquidContainer.default;
    }
  });
});
;define("rdc-ui-app-login/components/liquid-if", ["exports", "liquid-fire/components/liquid-if"], function (_exports, _liquidIf) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _liquidIf.default;
    }
  });
});
;define("rdc-ui-app-login/components/liquid-measured", ["exports", "liquid-fire/components/liquid-measured"], function (_exports, _liquidMeasured) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _liquidMeasured.default;
    }
  });
  Object.defineProperty(_exports, "measure", {
    enumerable: true,
    get: function () {
      return _liquidMeasured.measure;
    }
  });
});
;define("rdc-ui-app-login/components/liquid-outlet", ["exports", "liquid-fire/components/liquid-outlet"], function (_exports, _liquidOutlet) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _liquidOutlet.default;
    }
  });
});
;define("rdc-ui-app-login/components/liquid-spacer", ["exports", "liquid-fire/components/liquid-spacer"], function (_exports, _liquidSpacer) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _liquidSpacer.default;
    }
  });
});
;define("rdc-ui-app-login/components/liquid-sync", ["exports", "liquid-fire/components/liquid-sync"], function (_exports, _liquidSync) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _liquidSync.default;
    }
  });
});
;define("rdc-ui-app-login/components/liquid-unless", ["exports", "liquid-fire/components/liquid-unless"], function (_exports, _liquidUnless) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _liquidUnless.default;
    }
  });
});
;define("rdc-ui-app-login/components/liquid-versions", ["exports", "liquid-fire/components/liquid-versions"], function (_exports, _liquidVersions) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _liquidVersions.default;
    }
  });
});
;define("rdc-ui-app-login/components/live-face-detection", ["exports", "rdc-ui-adn-core/components/live-face-detection"], function (_exports, _liveFaceDetection) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _liveFaceDetection.default;
    }
  });
});
;define("rdc-ui-app-login/components/number-input", ["exports", "ember-inputmask/components/number-input"], function (_exports, _numberInput) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _numberInput.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/components/one-way-credit-card-mask", ["exports", "ember-inputmask/components/one-way-credit-card-mask"], function (_exports, _oneWayCreditCardMask) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _oneWayCreditCardMask.default;
    }
  });
});
;define("rdc-ui-app-login/components/one-way-currency-mask", ["exports", "ember-inputmask/components/one-way-currency-mask"], function (_exports, _oneWayCurrencyMask) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _oneWayCurrencyMask.default;
    }
  });
});
;define("rdc-ui-app-login/components/one-way-date-mask", ["exports", "ember-inputmask/components/one-way-date-mask"], function (_exports, _oneWayDateMask) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _oneWayDateMask.default;
    }
  });
});
;define("rdc-ui-app-login/components/one-way-email-mask", ["exports", "ember-inputmask/components/one-way-email-mask"], function (_exports, _oneWayEmailMask) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _oneWayEmailMask.default;
    }
  });
});
;define("rdc-ui-app-login/components/one-way-input-mask", ["exports", "ember-inputmask/components/one-way-input-mask"], function (_exports, _oneWayInputMask) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _oneWayInputMask.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/components/one-way-number-mask", ["exports", "ember-inputmask/components/one-way-number-mask"], function (_exports, _oneWayNumberMask) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _oneWayNumberMask.default;
    }
  });
});
;define("rdc-ui-app-login/components/one-way-phone-mask", ["exports", "ember-inputmask/components/one-way-phone-mask"], function (_exports, _oneWayPhoneMask) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _oneWayPhoneMask.default;
    }
  });
});
;define("rdc-ui-app-login/components/one-way-ssn-mask", ["exports", "ember-inputmask/components/one-way-ssn-mask"], function (_exports, _oneWaySsnMask) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _oneWaySsnMask.default;
    }
  });
});
;define("rdc-ui-app-login/components/one-way-zip-code-mask", ["exports", "ember-inputmask/components/one-way-zip-code-mask"], function (_exports, _oneWayZipCodeMask) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _oneWayZipCodeMask.default;
    }
  });
});
;define("rdc-ui-app-login/components/phone-number-input", ["exports", "ember-inputmask/components/phone-number-input"], function (_exports, _phoneNumberInput) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _phoneNumberInput.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/components/power-select-multiple", ["exports", "ember-power-select/components/power-select-multiple"], function (_exports, _powerSelectMultiple) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _powerSelectMultiple.default;
    }
  });
});
;define("rdc-ui-app-login/components/power-select-multiple/trigger", ["exports", "ember-power-select/components/power-select-multiple/trigger"], function (_exports, _trigger) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _trigger.default;
    }
  });
});
;define("rdc-ui-app-login/components/power-select", ["exports", "ember-power-select/components/power-select"], function (_exports, _powerSelect) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _powerSelect.default;
    }
  });
});
;define("rdc-ui-app-login/components/power-select/before-options", ["exports", "ember-power-select/components/power-select/before-options"], function (_exports, _beforeOptions) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _beforeOptions.default;
    }
  });
});
;define("rdc-ui-app-login/components/power-select/options", ["exports", "ember-power-select/components/power-select/options"], function (_exports, _options) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _options.default;
    }
  });
});
;define("rdc-ui-app-login/components/power-select/placeholder", ["exports", "ember-power-select/components/power-select/placeholder"], function (_exports, _placeholder) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _placeholder.default;
    }
  });
});
;define("rdc-ui-app-login/components/power-select/power-select-group", ["exports", "ember-power-select/components/power-select/power-select-group"], function (_exports, _powerSelectGroup) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _powerSelectGroup.default;
    }
  });
});
;define("rdc-ui-app-login/components/power-select/search-message", ["exports", "ember-power-select/components/power-select/search-message"], function (_exports, _searchMessage) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _searchMessage.default;
    }
  });
});
;define("rdc-ui-app-login/components/power-select/trigger", ["exports", "ember-power-select/components/power-select/trigger"], function (_exports, _trigger) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _trigger.default;
    }
  });
});
;define("rdc-ui-app-login/components/pull-to-refresh", ["exports", "rdc-ui-adn-components/components/pull-to-refresh"], function (_exports, _pullToRefresh) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _pullToRefresh.default;
    }
  });
});
;define("rdc-ui-app-login/components/radio-button-label", ["exports", "rdc-ui-adn-components/components/radio-button-label"], function (_exports, _radioButtonLabel) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _radioButtonLabel.default;
    }
  });
});
;define("rdc-ui-app-login/components/radio-button", ["exports", "rdc-ui-adn-components/components/radio-button"], function (_exports, _radioButton) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _radioButton.default;
    }
  });
});
;define("rdc-ui-app-login/components/ral-link", ["exports", "rdc-ui-adn-components/components/ral-link"], function (_exports, _ralLink) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _ralLink.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-accordion-item", ["exports", "rdc-ui-adn-components/components/rdc-accordion-item"], function (_exports, _rdcAccordionItem) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcAccordionItem.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-accordion-list", ["exports", "rdc-ui-adn-components/components/rdc-accordion-list"], function (_exports, _rdcAccordionList) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcAccordionList.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-accordion-panel", ["exports", "rdc-ui-adn-components/components/rdc-accordion-panel"], function (_exports, _rdcAccordionPanel) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcAccordionPanel.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-accordion-toggle", ["exports", "rdc-ui-adn-components/components/rdc-accordion-toggle"], function (_exports, _rdcAccordionToggle) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcAccordionToggle.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-action-modal", ["exports", "rdc-ui-adn-components/components/rdc-action-modal"], function (_exports, _rdcActionModal) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcActionModal.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-action-sheet-body", ["exports", "rdc-ui-adn-components/components/rdc-action-sheet-body"], function (_exports, _rdcActionSheetBody) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcActionSheetBody.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-action-sheet", ["exports", "rdc-ui-adn-components/components/rdc-action-sheet"], function (_exports, _rdcActionSheet) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcActionSheet.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-alert-modal", ["exports", "rdc-ui-adn-components/components/rdc-alert-modal"], function (_exports, _rdcAlertModal) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcAlertModal.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-alert", ["exports", "rdc-ui-adn-components/components/rdc-alert"], function (_exports, _rdcAlert) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcAlert.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-app-bar", ["exports", "rdc-ui-adn-components/components/rdc-app-bar"], function (_exports, _rdcAppBar) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcAppBar.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-bottom-bar", ["exports", "rdc-ui-adn-components/components/rdc-bottom-bar"], function (_exports, _rdcBottomBar) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcBottomBar.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-bottom-sheet", ["exports", "rdc-ui-adn-components/components/rdc-bottom-sheet"], function (_exports, _rdcBottomSheet) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcBottomSheet.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-button", ["exports", "rdc-ui-adn-components/components/rdc-button"], function (_exports, _rdcButton) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcButton.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-calculator", ["exports", "rdc-ui-adn-components/components/rdc-calculator"], function (_exports, _rdcCalculator) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcCalculator.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-checkbox-group", ["exports", "rdc-ui-adn-components/components/rdc-checkbox-group"], function (_exports, _rdcCheckboxGroup) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcCheckboxGroup.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-checkbox", ["exports", "rdc-ui-adn-components/components/rdc-checkbox"], function (_exports, _rdcCheckbox) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcCheckbox.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-circular-steps-progress", ["exports", "rdc-ui-adn-components/components/rdc-circular-steps-progress"], function (_exports, _rdcCircularStepsProgress) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcCircularStepsProgress.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-collapsible-panel-body", ["exports", "rdc-ui-adn-components/components/rdc-collapsible-panel-body"], function (_exports, _rdcCollapsiblePanelBody) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcCollapsiblePanelBody.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-collapsible-panel-header", ["exports", "rdc-ui-adn-components/components/rdc-collapsible-panel-header"], function (_exports, _rdcCollapsiblePanelHeader) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcCollapsiblePanelHeader.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-collapsible-panel", ["exports", "rdc-ui-adn-components/components/rdc-collapsible-panel"], function (_exports, _rdcCollapsiblePanel) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcCollapsiblePanel.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-context-menu-body", ["exports", "rdc-ui-adn-components/components/rdc-context-menu-body"], function (_exports, _rdcContextMenuBody) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcContextMenuBody.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-context-menu-header", ["exports", "rdc-ui-adn-components/components/rdc-context-menu-header"], function (_exports, _rdcContextMenuHeader) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcContextMenuHeader.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-context-menu-options", ["exports", "rdc-ui-adn-components/components/rdc-context-menu-options"], function (_exports, _rdcContextMenuOptions) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcContextMenuOptions.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-context-menu", ["exports", "rdc-ui-adn-components/components/rdc-context-menu"], function (_exports, _rdcContextMenu) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcContextMenu.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-countdown-timer", ["exports", "rdc-ui-adn-components/components/rdc-countdown-timer"], function (_exports, _rdcCountdownTimer) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcCountdownTimer.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-currency-input", ["exports", "rdc-ui-adn-components/components/rdc-currency-input"], function (_exports, _rdcCurrencyInput) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcCurrencyInput.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-currency", ["exports", "rdc-ui-adn-components/components/rdc-currency"], function (_exports, _rdcCurrency) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcCurrency.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-date-input", ["exports", "rdc-ui-adn-components/components/rdc-date-input"], function (_exports, _rdcDateInput) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcDateInput.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-drawer", ["exports", "rdc-ui-adn-components/components/rdc-drawer"], function (_exports, _rdcDrawer) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcDrawer.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-file-download", ["exports", "rdc-ui-adn-components/components/rdc-file-download"], function (_exports, _rdcFileDownload) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcFileDownload.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-file-upload", ["exports", "rdc-ui-adn-components/components/rdc-file-upload"], function (_exports, _rdcFileUpload) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcFileUpload.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-flyout-message", ["exports", "rdc-ui-adn-components/components/rdc-flyout-message"], function (_exports, _rdcFlyoutMessage) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcFlyoutMessage.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-flyout", ["exports", "rdc-ui-adn-components/components/rdc-flyout"], function (_exports, _rdcFlyout) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcFlyout.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-form-progress-bar", ["exports", "rdc-ui-adn-components/components/rdc-form-progress-bar"], function (_exports, _rdcFormProgressBar) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcFormProgressBar.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-form-select", ["exports", "rdc-ui-adn-component-form-select/components/rdc-form-select"], function (_exports, _rdcFormSelect) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcFormSelect.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-iframe", ["exports", "rdc-ui-adn-components/components/rdc-iframe"], function (_exports, _rdcIframe) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcIframe.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-image", ["exports", "rdc-ui-adn-components/components/rdc-image"], function (_exports, _rdcImage) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcImage.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-info-banner", ["exports", "rdc-ui-adn-components/components/rdc-info-banner"], function (_exports, _rdcInfoBanner) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcInfoBanner.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-info-message", ["exports", "rdc-ui-adn-components/components/rdc-info-message"], function (_exports, _rdcInfoMessage) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcInfoMessage.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-input-spinner", ["exports", "rdc-ui-adn-components/components/rdc-input-spinner"], function (_exports, _rdcInputSpinner) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcInputSpinner.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-label", ["exports", "rdc-ui-adn-components/components/rdc-label"], function (_exports, _rdcLabel) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcLabel.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-load-more", ["exports", "rdc-ui-adn-components/components/rdc-load-more"], function (_exports, _rdcLoadMore) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcLoadMore.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-loading-indicator", ["exports", "rdc-ui-adn-components/components/rdc-loading-indicator"], function (_exports, _rdcLoadingIndicator) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcLoadingIndicator.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-login-textbox", ["exports", "rdc-ui-adn-components/components/rdc-login-textbox"], function (_exports, _rdcLoginTextbox) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcLoginTextbox.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-modal-popup-wrapper", ["exports", "rdc-ui-adn-components/components/rdc-modal-popup-wrapper"], function (_exports, _rdcModalPopupWrapper) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcModalPopupWrapper.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-modal-popup", ["exports", "rdc-ui-adn-components/components/rdc-modal-popup"], function (_exports, _rdcModalPopup) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcModalPopup.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-native-date-picker", ["exports", "rdc-ui-adn-components/components/rdc-native-date-picker"], function (_exports, _rdcNativeDatePicker) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcNativeDatePicker.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-native-file-upload", ["exports", "rdc-ui-adn-components/components/rdc-native-file-upload"], function (_exports, _rdcNativeFileUpload) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcNativeFileUpload.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-native-select", ["exports", "rdc-ui-adn-components/components/rdc-native-select"], function (_exports, _rdcNativeSelect) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcNativeSelect.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-navbar", ["exports", "rdc-ui-adn-components/components/rdc-navbar"], function (_exports, _rdcNavbar) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcNavbar.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-notes", ["exports", "rdc-ui-adn-components/components/rdc-notes"], function (_exports, _rdcNotes) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcNotes.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-numberpad-key", ["exports", "rdc-ui-adn-components/components/rdc-numberpad-key"], function (_exports, _rdcNumberpadKey) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcNumberpadKey.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-numberpad", ["exports", "rdc-ui-adn-components/components/rdc-numberpad"], function (_exports, _rdcNumberpad) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcNumberpad.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-open-external-link", ["exports", "rdc-ui-adn-components/components/rdc-open-external-link"], function (_exports, _rdcOpenExternalLink) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcOpenExternalLink.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-otp", ["exports", "rdc-ui-adn-core/components/rdc-otp"], function (_exports, _rdcOtp) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcOtp.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-passcode-input", ["exports", "rdc-ui-adn-components/components/rdc-passcode-input"], function (_exports, _rdcPasscodeInput) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcPasscodeInput.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-passcode-viewer-v2", ["exports", "rdc-ui-adn-core/components/rdc-passcode-viewer-v2"], function (_exports, _rdcPasscodeViewerV) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcPasscodeViewerV.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-passcode-viewer", ["exports", "rdc-ui-adn-components/components/rdc-passcode-viewer"], function (_exports, _rdcPasscodeViewer) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcPasscodeViewer.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-passcode", ["exports", "rdc-ui-adn-components/components/rdc-passcode"], function (_exports, _rdcPasscode) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcPasscode.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-progress-bar", ["exports", "rdc-ui-adn-components/components/rdc-progress-bar"], function (_exports, _rdcProgressBar) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcProgressBar.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-radio-group", ["exports", "rdc-ui-adn-components/components/rdc-radio-group"], function (_exports, _rdcRadioGroup) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcRadioGroup.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-radio", ["exports", "rdc-ui-adn-components/components/rdc-radio"], function (_exports, _rdcRadio) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcRadio.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-safe-area", ["exports", "rdc-ui-adn-components/components/rdc-safe-area"], function (_exports, _rdcSafeArea) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcSafeArea.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-screen", ["exports", "rdc-ui-adn-components/components/rdc-screen"], function (_exports, _rdcScreen) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcScreen.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-scrollable-container", ["exports", "rdc-ui-adn-components/components/rdc-scrollable-container"], function (_exports, _rdcScrollableContainer) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcScrollableContainer.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-scrollview", ["exports", "rdc-ui-adn-components/components/rdc-scrollview"], function (_exports, _rdcScrollview) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcScrollview.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-select-multiple", ["exports", "rdc-ui-adn-components/components/rdc-select-multiple"], function (_exports, _rdcSelectMultiple) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcSelectMultiple.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-select", ["exports", "rdc-ui-adn-component-form-select/components/rdc-select"], function (_exports, _rdcSelect) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcSelect.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-shield-spinner", ["exports", "rdc-ui-adn-components/components/rdc-shield-spinner"], function (_exports, _rdcShieldSpinner) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcShieldSpinner.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-slide-carousel", ["exports", "rdc-ui-adn-components/components/rdc-slide-carousel"], function (_exports, _rdcSlideCarousel) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcSlideCarousel.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-slide-carousel/carousel", ["exports", "rdc-ui-adn-components/components/rdc-slide-carousel/carousel"], function (_exports, _carousel) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _carousel.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-slide-carousel/dots", ["exports", "rdc-ui-adn-components/components/rdc-slide-carousel/dots"], function (_exports, _dots) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _dots.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-slide-scroller", ["exports", "rdc-ui-adn-components/components/rdc-slide-scroller"], function (_exports, _rdcSlideScroller) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcSlideScroller.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-slide-scroller/dots", ["exports", "rdc-ui-adn-components/components/rdc-slide-scroller/dots"], function (_exports, _dots) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _dots.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-slide-scroller/scroller", ["exports", "rdc-ui-adn-components/components/rdc-slide-scroller/scroller"], function (_exports, _scroller) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _scroller.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-spinner", ["exports", "rdc-ui-adn-components/components/rdc-spinner"], function (_exports, _rdcSpinner) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcSpinner.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-swipe-to-confirm", ["exports", "rdc-ui-adn-components/components/rdc-swipe-to-confirm"], function (_exports, _rdcSwipeToConfirm) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcSwipeToConfirm.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-tel-input", ["exports", "rdc-ui-adn-components/components/rdc-tel-input"], function (_exports, _rdcTelInput) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcTelInput.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-textarea", ["exports", "rdc-ui-adn-components/components/rdc-textarea"], function (_exports, _rdcTextarea) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcTextarea.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-textbox", ["exports", "rdc-ui-adn-components/components/rdc-textbox"], function (_exports, _rdcTextbox) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcTextbox.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-textinput-formatter", ["exports", "rdc-ui-adn-components/components/rdc-textinput-formatter"], function (_exports, _rdcTextinputFormatter) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcTextinputFormatter.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-toggle", ["exports", "rdc-ui-adn-components/components/rdc-toggle"], function (_exports, _rdcToggle) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcToggle.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-tooltip", ["exports", "rdc-ui-adn-components/components/rdc-tooltip"], function (_exports, _rdcTooltip) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcTooltip.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-txnpwd", ["exports", "rdc-ui-adn-core/components/rdc-txnpwd"], function (_exports, _rdcTxnpwd) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcTxnpwd.default;
    }
  });
});
;define("rdc-ui-app-login/components/rdc-visual-radio-group", ["exports", "rdc-ui-adn-components/components/rdc-visual-radio-group"], function (_exports, _rdcVisualRadioGroup) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcVisualRadioGroup.default;
    }
  });
});
;define("rdc-ui-app-login/components/sc-online-terms-and-conditions", ["exports", "rdc-ui-adn-components/components/sc-online-terms-and-conditions"], function (_exports, _scOnlineTermsAndConditions) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _scOnlineTermsAndConditions.default;
    }
  });
});
;define("rdc-ui-app-login/components/sc-online-terms-modal-content", ["exports", "rdc-ui-adn-components/components/sc-online-terms-modal-content"], function (_exports, _scOnlineTermsModalContent) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _scOnlineTermsModalContent.default;
    }
  });
});
;define("rdc-ui-app-login/components/sidemenu-link", ["exports", "rdc-ui-adn-components/components/sidemenu-link"], function (_exports, _sidemenuLink) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _sidemenuLink.default;
    }
  });
});
;define("rdc-ui-app-login/components/soft-token-otp-manager", ["exports", "rdc-ui-adn-core/components/soft-token-otp-manager"], function (_exports, _softTokenOtpManager) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _softTokenOtpManager.default;
    }
  });
});
;define("rdc-ui-app-login/components/soft-token-otp", ["exports", "rdc-ui-adn-core/components/soft-token-otp"], function (_exports, _softTokenOtp) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _softTokenOtp.default;
    }
  });
});
;define("rdc-ui-app-login/components/ssn-input", ["exports", "ember-inputmask/components/ssn-input"], function (_exports, _ssnInput) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _ssnInput.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/components/welcome-page", ["exports", "ember-welcome-page/components/welcome-page"], function (_exports, _welcomePage) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _welcomePage.default;
    }
  });
});
;define("rdc-ui-app-login/components/zip-code-input", ["exports", "ember-inputmask/components/zip-code-input"], function (_exports, _zipCodeInput) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _zipCodeInput.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/controllers/agent-login", ["exports", "rdc-ui-app-login/mixins/show-error-message"], function (_exports, _showErrorMessage) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Controller.extend(_showErrorMessage.default, {
    session: Ember.inject.service(),
    i18n: Ember.inject.service(),
    rdcLoadingIndicator: Ember.inject.service(),
    router: Ember.inject.service(),
    rdcAjax: Ember.inject.service(),
    identification: '',
    password: '',
    isRunning: false,

    _launchStaffAssistedWeb(data) {
      let staffId = data.hrEmpId;
      let companyCode = data.companyCode;
      let redirectUrl = `${window.location.origin}/retail/service-requests/?targetRoute=hr-portal-dashboard&lang=en&ctry=KE&flow=web&EID=${staffId}&CC=${companyCode}`;
      -this.clearLoginInputs();
      window.open(redirectUrl, '_system');
    },

    validateCredentials(identification, password) {
      this.clearLoginInputs();
      return !identification && !password ? this.showLoginError(this.i18n.t("login.errorMessages.allEmptyError")) : !identification ? this.showLoginError(this.i18n.t("login.errorMessages.emptyUser")) : !password ? this.showLoginError(this.i18n.t("login.errorMessages.emptyPassword")) : true;
    },

    clearLoginInputs() {
      this.set('password', '');
      this.get('store').unloadAll('hrLogin');
    },

    async openBankingLogin() {
      let {
        identification,
        password
      } = this;
      this.get('rdcLoadingIndicator').showLoadingIndicator();

      if (identification && password || this.validateCredentials(identification, password)) {
        await this.get('store').queryRecord('hr-login', {
          id: identification,
          filter: {
            countryCode: this.inputParams.countryCode
          }
        }).then(result => {
          this.set('agentRamdomChanllenge', result);
          return;
        }).catch(error => {
          this.showLoginError(error);
          this.clearLoginInputs();
        });
        let otpExponent = this.agentRamdomChanllenge.exponent;
        let otpModulus = this.agentRamdomChanllenge.modulus;
        let otpBase64Challenge = this.agentRamdomChanllenge.base64Challenge;
        let encryptedPassword = hex2b64(rsaEncrypt(otpExponent, otpModulus, password + '_-_' + otpBase64Challenge));
        this.set('encryptValue', encryptedPassword);
        this.get('store').unloadAll('hrLogin');
        let hrLoginRequest = this.get('store').createRecord('hrLogin', {
          id: identification,
          action: 'login',
          countryCode: this.inputParams.countryCode,
          encryptValue: encryptedPassword
        });

        try {
          this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(hrLoginRequest.save()).then(responseData => {
            this._launchStaffAssistedWeb(responseData);
          }, error => {
            this.showLoginError(error);
            this.clearLoginInputs();
          });
        } catch (error) {
          this.showLoginError(error);
          this.clearLoginInputs();
        }
      }
    },

    actions: {
      login() {
        this.openBankingLogin();
      },

      navigateToRegistration(actionType) {
        this.clearLoginInputs();
        this.router.transitionTo('agent-registration', {
          queryParams: {
            action: actionType
          }
        });
      }

    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/controllers/agent-registration", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Controller.extend({});

  _exports.default = _default;
});
;define("rdc-ui-app-login/controllers/application", ["exports", "rdc-ui-adn-core/controllers/application"], function (_exports, _application) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = _application.default.extend({});

  _exports.default = _default;
});
;define("rdc-ui-app-login/controllers/login", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Controller.extend(Ember.Evented, {
    i18n: Ember.inject.service(),
    rdcModalManager: Ember.inject.service('rdcModalManager'),
    loginClient: Ember.inject.service(),
    rdcLoadingIndicator: Ember.inject.service(),
    identification: '',
    password: '',
    captcha: '',
    nfsSessionId: '',

    validateCredentials(identification, password) {
      let regEx = new RegExp('^[A-Za-z0-9]+$');

      if (identification && !regEx.test(identification)) {
        this.rdcModalManager.showDialogModal({
          level: "error",
          message: this.i18n.t("login.errorMessages.specialCharacterError"),
          acceptButtonLabel: this.i18n.t("generic.ok"),
          customClass: "login-app-popup"
        });
        this.clearLoginInputs();
        return false;
      }

      if (identification && password) {
        return true;
      } else if (!identification && !password) {
        this.rdcModalManager.showDialogModal({
          level: "error",
          message: this.i18n.t("login.errorMessages.allEmptyError"),
          acceptButtonLabel: this.i18n.t("generic.ok"),
          customClass: "login-app-popup"
        });
        this.clearLoginInputs();
        return false;
      } else if (!identification) {
        this.rdcModalManager.showDialogModal({
          level: "error",
          message: this.i18n.t("login.errorMessages.emptyUser"),
          acceptButtonLabel: this.i18n.t("generic.ok"),
          customClass: "login-app-popup"
        });
        this.clearLoginInputs();
        return false;
      } else {
        this.rdcModalManager.showDialogModal({
          level: "error",
          message: this.i18n.t("login.errorMessages.emptyPassword"),
          acceptButtonLabel: this.i18n.t("generic.ok"),
          customClass: "login-app-popup"
        });
        this.clearLoginInputs();
        return false;
      }
    },

    clearLoginInputs() {
      this.set('password', '');
    },

    mobilePlatform: Ember.computed(function () {
      return typeof window.orientation !== "undefined";
    }),
    isRedirectUri: Ember.computed(function () {
      if (document.location.href.indexOf('ref-app') != -1) {
        return true;
      } else {
        return false;
      }
    }),
    isMobile: Ember.computed(function () {
      return !!window.cordova;
    }),
    actions: {
      login() {
        let {
          identification,
          password,
          captcha,
          nfsSessionId
        } = this;

        if (this.isCN) {
          identification = identification.trim();
        } else {
          identification = identification.trim().toUpperCase();
        }

        password = password.trim();

        if (this.validateCredentials(identification, password)) {
          let bsoiSecurityParams;
          bsoiSecurityParams = {
            securityNonce: this.resNonce,
            e2eRsaExponent: this.resExponent,
            e2eRsaModulus: this.resModulus,
            urlParamsVal: this.urlParamsVal
          };
          this.rdcLoadingIndicator.showLoadingIndicator(" ");
          this.get("loginClient.initlogin").perform(bsoiSecurityParams, identification, password, captcha, nfsSessionId, this.resScope, this.tmxId);
        }
      }

    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/controllers/open-banking-consent-permission", ["exports", "rdc-ui-app-login/utils/constants"], function (_exports, _constants) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Controller.extend({
    rdcAjax: Ember.inject.service(),
    session: Ember.inject.service(),
    i18n: Ember.inject.service(),
    isRunning: false,
    rdcModalManager: Ember.inject.service(),
    scope: '',
    decisionURL: Ember.computed('session', function () {
      return `${_constants.default.openAPIURL(window.location.hostname).AUTH_DECISION}?Authorization=Bearer ${this.session.data.authenticated.access_token}&X-Market=${this.rdcAjax.countryHeader(location.pathname)}`;
    }),
    selectedAccounts: Ember.computed('model.parsedAccounts.@each.consent_permission', function () {
      return JSON.stringify(this.get('model.parsedAccounts').filterBy('consent_permission', true));
    }),
    actions: {
      toggleAccount(account) {
        if (this.scope.includes('payments') && !account.consent_permission) {
          this.get('model.parsedAccounts').setEach('consent_permission', false);
        }

        account.toggleProperty('consent_permission');
      },

      allow() {
        this.rdcModalManager.showDialogModal({
          level: 'warning',
          title: '',
          message: 'This page will redirect you to consent page. Are you ok to redirect?',
          acceptButtonLabel: this.i18n.t('generic.ok'),
          rejectButtonLabel: this.i18n.t('generic.cancel')
        }).then(() => {
          this.set("isRunning", true);
          document.querySelector("#consent-form").submit();
          this.set("isRunning", false);
        }).catch(() => {});
      },

      deny() {
        this.set("isRunning", true);
        document.querySelector("#consent-form").submit();
        this.set("isRunning", false);
      }

    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/controllers/open-banking-login", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Controller.extend({
    session: Ember.inject.service(),
    i18n: Ember.inject.service(),
    router: Ember.inject.service(),
    rdcModalManager: Ember.inject.service(),
    cslLoginHeaders: Ember.inject.service(),
    rdcAjax: Ember.inject.service(),
    identification: '',
    password: '',
    isRunning: false,
    country: Ember.computed(function () {
      let country = this.rdcAjax.countryHeader(location.pathname);
      return country ? country : 'HK';
    }),

    showLoginError(error) {
      this.rdcModalManager.showDialogModal({
        level: "error",
        message: error,
        acceptButtonLabel: this.i18n.t("generic.ok"),
        customClass: "login-app-popup"
      });
      this.clearLoginInputs();
      return false;
    },

    validateCredentials(identification, password) {
      let hasError = false;

      if (!identification && !password) {
        this.showLoginError(this.i18n.t("login.errorMessages.allEmptyError"));
        hasError = true;
      } else if (!identification) {
        this.showLoginError(this.i18n.t("login.errorMessages.emptyUser"));
        hasError = true;
      } else if (!password) {
        this.showLoginError(this.i18n.t("login.errorMessages.emptyPassword"));
        hasError = true;
      }

      return hasError;
    },

    clearLoginInputs() {
      this.set('password', '');
    },

    async openBankingLogin() {
      let {
        identification,
        password
      } = this;
      let consentId = this.cslLoginHeaders.queryObject ? this.cslLoginHeaders.queryObject['ConsentId'] : '';

      if (this.validateCredentials(identification, password)) {
        return false;
      }

      try {
        this.set('isRunning', true);
        await this.session.authenticate('authenticator:cslLogin', identification, password, consentId);
        this.clearLoginInputs();
        this.router.transitionTo('open-banking-consent-permission');
        this.set('isRunning', false);
      } catch (err) {
        this.set('isRunning', false);
        this.showLoginError(this.i18n.t("login.errorMessages.incorrectCredentials"));
      }
    },

    actions: {
      keyPress(value, event) {
        if (event) {
          let charCode = event.which || event.keyCode;

          if (charCode === 13) {
            this.openBankingLogin();
          }
        }
      },

      async login() {
        this.openBankingLogin();
      }

    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/controllers/staff-login", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Controller.extend({
    i18n: Ember.inject.service(),
    rdcLoadingIndicator: Ember.inject.service(),
    rdcModalManager: Ember.inject.service(),
    rdcAjax: Ember.inject.service(),
    identification: '',
    password: '',
    country: Ember.computed(function () {
      let code = '';
      let srcURL = window.location.href;

      if (srcURL) {
        srcURL = srcURL.split('?')[1];

        if (srcURL) {
          srcURL = srcURL.split('&');

          for (let i = 0; i < srcURL.length; i++) {
            if (srcURL[i].indexOf('ctry') !== -1) {
              code = srcURL[i].split('=')[1];
            }
          }
        }
      }

      return code ? code : 'AE';
    }),

    _launchStaffAssistedWeb(data) {
      let staffId = data.data.id;
      let redirectUrl = window.location.protocol + '//' + window.location.host + "/retail/service-requests/?targetRoute=product-list.list&lang=en&ctry=AE&flow=web&staffId=" + staffId;
      window.open(redirectUrl, '_self');
    },

    showLoginError(error) {
      this.rdcModalManager.showDialogModal({
        level: "error",
        message: error,
        acceptButtonLabel: this.i18n.t("generic.ok"),
        customClass: "login-app-popup"
      });
      this.clearLoginInputs();
      return false;
    },

    validateCredentials(identification, password) {
      return !identification && !password ? this.showLoginError(this.i18n.t("login.errorMessages.allEmptyError")) : !identification ? this.showLoginError(this.i18n.t("login.errorMessages.emptyUser")) : true;
    },

    clearLoginInputs() {
      this.set('password', '');
    },

    async openBankingLogin() {
      let {
        identification,
        password
      } = this;

      if (identification && password || this.validateCredentials(identification, password)) {
        let requestData = {
          data: {
            id: identification,
            type: "staff-agent-auths",
            attributes: {
              operation: "login",
              type: "AUTHENTICATE_AUTHORIZE",
              "country-code": "AE",
              agent: false,
              password: password
            }
          }
        };

        try {
          let loginRequestUrl = window.location.protocol + '//' + window.location.host + '/retail/api/v3/staff-agent-auths';
          let loginResponse = await this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(this.rdcAjax.request(loginRequestUrl, {
            method: 'POST',
            contentType: 'application/vnd.api+json',
            data: requestData
          }));

          this._launchStaffAssistedWeb(loginResponse);
        } catch (error) {
          let errorMessage = error.payload;

          if (errorMessage && errorMessage.errors && errorMessage.errors.length) {
            errorMessage = errorMessage.errors[0].detail;
          } else if (errorMessage && errorMessage.errMsg) {
            errorMessage = errorMessage.errMsg;
          } else {
            errorMessage = this.i18n.t('errors.unknownError');
          }

          this.showLoginError(errorMessage);
        }
      }
    },

    actions: {
      login() {
        this.openBankingLogin();
      }

    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/errors", ["exports", "rdc-ui-adn-core/errors"], function (_exports, _errors) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "NetworkUnavailableError", {
    enumerable: true,
    get: function () {
      return _errors.NetworkUnavailableError;
    }
  });
  Object.defineProperty(_exports, "OTPCancelledError", {
    enumerable: true,
    get: function () {
      return _errors.OTPCancelledError;
    }
  });
  Object.defineProperty(_exports, "DisplayableError", {
    enumerable: true,
    get: function () {
      return _errors.DisplayableError;
    }
  });
  Object.defineProperty(_exports, "DeviceRegistrationError", {
    enumerable: true,
    get: function () {
      return _errors.DeviceRegistrationError;
    }
  });
});
;define("rdc-ui-app-login/helpers/and", ["exports", "ember-truth-helpers/helpers/and"], function (_exports, _and) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _and.default;
    }
  });
  Object.defineProperty(_exports, "and", {
    enumerable: true,
    get: function () {
      return _and.and;
    }
  });
});
;define("rdc-ui-app-login/helpers/app-version", ["exports", "rdc-ui-app-login/config/environment", "ember-cli-app-version/utils/regexp"], function (_exports, _environment, _regexp) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.appVersion = appVersion;
  _exports.default = void 0;

  function appVersion(_, hash = {}) {
    const version = _environment.default.APP.version; // e.g. 1.0.0-alpha.1+4jds75hf
    // Allow use of 'hideSha' and 'hideVersion' For backwards compatibility

    let versionOnly = hash.versionOnly || hash.hideSha;
    let shaOnly = hash.shaOnly || hash.hideVersion;
    let match = null;

    if (versionOnly) {
      if (hash.showExtended) {
        match = version.match(_regexp.versionExtendedRegExp); // 1.0.0-alpha.1
      } // Fallback to just version


      if (!match) {
        match = version.match(_regexp.versionRegExp); // 1.0.0
      }
    }

    if (shaOnly) {
      match = version.match(_regexp.shaRegExp); // 4jds75hf
    }

    return match ? match[0] : version;
  }

  var _default = Ember.Helper.helper(appVersion);

  _exports.default = _default;
});
;define("rdc-ui-app-login/helpers/breaklines", ["exports", "rdc-ui-adn-components/helpers/breaklines"], function (_exports, _breaklines) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _breaklines.default;
    }
  });
  Object.defineProperty(_exports, "breaklines", {
    enumerable: true,
    get: function () {
      return _breaklines.breaklines;
    }
  });
});
;define("rdc-ui-app-login/helpers/cancel-all", ["exports", "ember-concurrency/helpers/cancel-all"], function (_exports, _cancelAll) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _cancelAll.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/currency-symbol", ["exports", "rdc-ui-adn-components/helpers/currency-symbol"], function (_exports, _currencySymbol) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _currencySymbol.default;
    }
  });
  Object.defineProperty(_exports, "currencySymbol", {
    enumerable: true,
    get: function () {
      return _currencySymbol.currencySymbol;
    }
  });
});
;define("rdc-ui-app-login/helpers/ember-power-select-is-group", ["exports", "ember-power-select/helpers/ember-power-select-is-group"], function (_exports, _emberPowerSelectIsGroup) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _emberPowerSelectIsGroup.default;
    }
  });
  Object.defineProperty(_exports, "emberPowerSelectIsGroup", {
    enumerable: true,
    get: function () {
      return _emberPowerSelectIsGroup.emberPowerSelectIsGroup;
    }
  });
});
;define("rdc-ui-app-login/helpers/ember-power-select-is-selected", ["exports", "ember-power-select/helpers/ember-power-select-is-selected"], function (_exports, _emberPowerSelectIsSelected) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _emberPowerSelectIsSelected.default;
    }
  });
  Object.defineProperty(_exports, "emberPowerSelectIsSelected", {
    enumerable: true,
    get: function () {
      return _emberPowerSelectIsSelected.emberPowerSelectIsSelected;
    }
  });
});
;define("rdc-ui-app-login/helpers/ember-power-select-true-string-if-present", ["exports", "ember-power-select/helpers/ember-power-select-true-string-if-present"], function (_exports, _emberPowerSelectTrueStringIfPresent) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _emberPowerSelectTrueStringIfPresent.default;
    }
  });
  Object.defineProperty(_exports, "emberPowerSelectTrueStringIfPresent", {
    enumerable: true,
    get: function () {
      return _emberPowerSelectTrueStringIfPresent.emberPowerSelectTrueStringIfPresent;
    }
  });
});
;define("rdc-ui-app-login/helpers/eq", ["exports", "ember-truth-helpers/helpers/equal"], function (_exports, _equal) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _equal.default;
    }
  });
  Object.defineProperty(_exports, "equal", {
    enumerable: true,
    get: function () {
      return _equal.equal;
    }
  });
});
;define("rdc-ui-app-login/helpers/fap-enabled", ["exports", "rdc-ui-adn-core/helpers/fap-enabled"], function (_exports, _fapEnabled) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _fapEnabled.default;
    }
  });
  Object.defineProperty(_exports, "fapEnabled", {
    enumerable: true,
    get: function () {
      return _fapEnabled.fapEnabled;
    }
  });
});
;define("rdc-ui-app-login/helpers/file-queue", ["exports", "ember-file-upload/helpers/file-queue"], function (_exports, _fileQueue) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _fileQueue.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/gt", ["exports", "ember-truth-helpers/helpers/gt"], function (_exports, _gt) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _gt.default;
    }
  });
  Object.defineProperty(_exports, "gt", {
    enumerable: true,
    get: function () {
      return _gt.gt;
    }
  });
});
;define("rdc-ui-app-login/helpers/gte", ["exports", "ember-truth-helpers/helpers/gte"], function (_exports, _gte) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _gte.default;
    }
  });
  Object.defineProperty(_exports, "gte", {
    enumerable: true,
    get: function () {
      return _gte.gte;
    }
  });
});
;define("rdc-ui-app-login/helpers/index-sum", ["exports", "rdc-ui-adn-components/helpers/index-sum"], function (_exports, _indexSum) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _indexSum.default;
    }
  });
  Object.defineProperty(_exports, "indexSum", {
    enumerable: true,
    get: function () {
      return _indexSum.indexSum;
    }
  });
});
;define("rdc-ui-app-login/helpers/is-after", ["exports", "ember-moment/helpers/is-after"], function (_exports, _isAfter) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _isAfter.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/is-array", ["exports", "ember-truth-helpers/helpers/is-array"], function (_exports, _isArray) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _isArray.default;
    }
  });
  Object.defineProperty(_exports, "isArray", {
    enumerable: true,
    get: function () {
      return _isArray.isArray;
    }
  });
});
;define("rdc-ui-app-login/helpers/is-before", ["exports", "ember-moment/helpers/is-before"], function (_exports, _isBefore) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _isBefore.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/is-between", ["exports", "ember-moment/helpers/is-between"], function (_exports, _isBetween) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _isBetween.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/is-empty", ["exports", "ember-truth-helpers/helpers/is-empty"], function (_exports, _isEmpty) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _isEmpty.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/is-equal", ["exports", "ember-truth-helpers/helpers/is-equal"], function (_exports, _isEqual) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _isEqual.default;
    }
  });
  Object.defineProperty(_exports, "isEqual", {
    enumerable: true,
    get: function () {
      return _isEqual.isEqual;
    }
  });
});
;define("rdc-ui-app-login/helpers/is-same-or-after", ["exports", "ember-moment/helpers/is-same-or-after"], function (_exports, _isSameOrAfter) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _isSameOrAfter.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/is-same-or-before", ["exports", "ember-moment/helpers/is-same-or-before"], function (_exports, _isSameOrBefore) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _isSameOrBefore.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/is-same", ["exports", "ember-moment/helpers/is-same"], function (_exports, _isSame) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _isSame.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/lf-lock-model", ["exports", "liquid-fire/helpers/lf-lock-model"], function (_exports, _lfLockModel) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _lfLockModel.default;
    }
  });
  Object.defineProperty(_exports, "lfLockModel", {
    enumerable: true,
    get: function () {
      return _lfLockModel.lfLockModel;
    }
  });
});
;define("rdc-ui-app-login/helpers/lf-or", ["exports", "liquid-fire/helpers/lf-or"], function (_exports, _lfOr) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _lfOr.default;
    }
  });
  Object.defineProperty(_exports, "lfOr", {
    enumerable: true,
    get: function () {
      return _lfOr.lfOr;
    }
  });
});
;define("rdc-ui-app-login/helpers/lt", ["exports", "ember-truth-helpers/helpers/lt"], function (_exports, _lt) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _lt.default;
    }
  });
  Object.defineProperty(_exports, "lt", {
    enumerable: true,
    get: function () {
      return _lt.lt;
    }
  });
});
;define("rdc-ui-app-login/helpers/lte", ["exports", "ember-truth-helpers/helpers/lte"], function (_exports, _lte) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _lte.default;
    }
  });
  Object.defineProperty(_exports, "lte", {
    enumerable: true,
    get: function () {
      return _lte.lte;
    }
  });
});
;define("rdc-ui-app-login/helpers/media", ["exports", "ember-responsive/helpers/media"], function (_exports, _media) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _media.default;
    }
  });
  Object.defineProperty(_exports, "media", {
    enumerable: true,
    get: function () {
      return _media.media;
    }
  });
});
;define("rdc-ui-app-login/helpers/moment-add", ["exports", "ember-moment/helpers/moment-add"], function (_exports, _momentAdd) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _momentAdd.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/moment-calendar", ["exports", "ember-moment/helpers/moment-calendar"], function (_exports, _momentCalendar) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _momentCalendar.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/moment-diff", ["exports", "ember-moment/helpers/moment-diff"], function (_exports, _momentDiff) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _momentDiff.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/moment-duration", ["exports", "ember-moment/helpers/moment-duration"], function (_exports, _momentDuration) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _momentDuration.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/moment-format", ["exports", "ember-moment/helpers/moment-format"], function (_exports, _momentFormat) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _momentFormat.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/moment-from-now", ["exports", "ember-moment/helpers/moment-from-now"], function (_exports, _momentFromNow) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _momentFromNow.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/moment-from", ["exports", "ember-moment/helpers/moment-from"], function (_exports, _momentFrom) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _momentFrom.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/moment-subtract", ["exports", "ember-moment/helpers/moment-subtract"], function (_exports, _momentSubtract) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _momentSubtract.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/moment-to-date", ["exports", "ember-moment/helpers/moment-to-date"], function (_exports, _momentToDate) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _momentToDate.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/moment-to-now", ["exports", "ember-moment/helpers/moment-to-now"], function (_exports, _momentToNow) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _momentToNow.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/moment-to", ["exports", "ember-moment/helpers/moment-to"], function (_exports, _momentTo) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _momentTo.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/moment-unix", ["exports", "ember-moment/helpers/unix"], function (_exports, _unix) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _unix.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/moment", ["exports", "ember-moment/helpers/moment"], function (_exports, _moment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _moment.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/not-eq", ["exports", "ember-truth-helpers/helpers/not-equal"], function (_exports, _notEqual) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _notEqual.default;
    }
  });
  Object.defineProperty(_exports, "notEq", {
    enumerable: true,
    get: function () {
      return _notEqual.notEq;
    }
  });
});
;define("rdc-ui-app-login/helpers/not", ["exports", "ember-truth-helpers/helpers/not"], function (_exports, _not) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _not.default;
    }
  });
  Object.defineProperty(_exports, "not", {
    enumerable: true,
    get: function () {
      return _not.not;
    }
  });
});
;define("rdc-ui-app-login/helpers/now", ["exports", "ember-moment/helpers/now"], function (_exports, _now) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _now.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/or", ["exports", "ember-truth-helpers/helpers/or"], function (_exports, _or) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _or.default;
    }
  });
  Object.defineProperty(_exports, "or", {
    enumerable: true,
    get: function () {
      return _or.or;
    }
  });
});
;define("rdc-ui-app-login/helpers/perform", ["exports", "ember-concurrency/helpers/perform"], function (_exports, _perform) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _perform.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/phonenumberlink", ["exports", "rdc-ui-adn-components/helpers/phonenumberlink"], function (_exports, _phonenumberlink) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _phonenumberlink.default;
    }
  });
  Object.defineProperty(_exports, "phonenumberlink", {
    enumerable: true,
    get: function () {
      return _phonenumberlink.phonenumberlink;
    }
  });
});
;define("rdc-ui-app-login/helpers/pluralize", ["exports", "ember-inflector/lib/helpers/pluralize"], function (_exports, _pluralize) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _pluralize.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/helpers/singularize", ["exports", "ember-inflector/lib/helpers/singularize"], function (_exports, _singularize) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _singularize.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/helpers/t", ["exports", "ember-i18n/helper"], function (_exports, _helper) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _helper.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/task", ["exports", "ember-concurrency/helpers/task"], function (_exports, _task) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _task.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/unix", ["exports", "ember-moment/helpers/unix"], function (_exports, _unix) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _unix.default;
    }
  });
});
;define("rdc-ui-app-login/helpers/utc", ["exports", "ember-moment/helpers/utc"], function (_exports, _utc) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _utc.default;
    }
  });
  Object.defineProperty(_exports, "utc", {
    enumerable: true,
    get: function () {
      return _utc.utc;
    }
  });
});
;define("rdc-ui-app-login/helpers/xor", ["exports", "ember-truth-helpers/helpers/xor"], function (_exports, _xor) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _xor.default;
    }
  });
  Object.defineProperty(_exports, "xor", {
    enumerable: true,
    get: function () {
      return _xor.xor;
    }
  });
});
;define("rdc-ui-app-login/index", ["exports", "ember-uuid"], function (_exports, _emberUuid) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "v4", {
    enumerable: true,
    get: function () {
      return _emberUuid.v4;
    }
  });
  Object.defineProperty(_exports, "v1", {
    enumerable: true,
    get: function () {
      return _emberUuid.v1;
    }
  });
  Object.defineProperty(_exports, "parse", {
    enumerable: true,
    get: function () {
      return _emberUuid.parse;
    }
  });
  Object.defineProperty(_exports, "unparse", {
    enumerable: true,
    get: function () {
      return _emberUuid.unparse;
    }
  });
});
;define("rdc-ui-app-login/initializers/app-version", ["exports", "ember-cli-app-version/initializer-factory", "rdc-ui-app-login/config/environment"], function (_exports, _initializerFactory, _environment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  let name, version;

  if (_environment.default.APP) {
    name = _environment.default.APP.name;
    version = _environment.default.APP.version;
  }

  var _default = {
    name: 'App Version',
    initialize: (0, _initializerFactory.default)(name, version)
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/initializers/container-debug-adapter", ["exports", "ember-resolver/resolvers/classic/container-debug-adapter"], function (_exports, _containerDebugAdapter) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    name: 'container-debug-adapter',

    initialize() {
      let app = arguments[1] || arguments[0];
      app.register('container-debug-adapter:main', _containerDebugAdapter.default);
      app.inject('container-debug-adapter:main', 'namespace', 'application:main');
    }

  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/initializers/ember-concurrency", ["exports", "ember-concurrency/initializers/ember-concurrency"], function (_exports, _emberConcurrency) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _emberConcurrency.default;
    }
  });
});
;define("rdc-ui-app-login/initializers/ember-data", ["exports", "ember-data/setup-container", "ember-data"], function (_exports, _setupContainer, _emberData) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  /*
  
    This code initializes Ember-Data onto an Ember application.
  
    If an Ember.js developer defines a subclass of DS.Store on their application,
    as `App.StoreService` (or via a module system that resolves to `service:store`)
    this code will automatically instantiate it and make it available on the
    router.
  
    Additionally, after an application's controllers have been injected, they will
    each have the store made available to them.
  
    For example, imagine an Ember.js application with the following classes:
  
    ```app/services/store.js
    import DS from 'ember-data';
  
    export default DS.Store.extend({
      adapter: 'custom'
    });
    ```
  
    ```app/controllers/posts.js
    import { Controller } from '@ember/controller';
  
    export default Controller.extend({
      // ...
    });
  
    When the application is initialized, `ApplicationStore` will automatically be
    instantiated, and the instance of `PostsController` will have its `store`
    property set to that instance.
  
    Note that this code will only be run if the `ember-application` package is
    loaded. If Ember Data is being used in an environment other than a
    typical application (e.g., node.js where only `ember-runtime` is available),
    this code will be ignored.
  */
  var _default = {
    name: 'ember-data',
    initialize: _setupContainer.default
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/initializers/ember-i18n", ["exports", "ember-i18n/initializers/ember-i18n"], function (_exports, _emberI18n) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _emberI18n.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/initializers/ember-responsive-breakpoints", ["exports", "ember-responsive/initializers/responsive"], function (_exports, _responsive) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _responsive.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/initializers/ember-simple-auth", ["exports", "rdc-ui-app-login/config/environment", "ember-simple-auth/configuration", "ember-simple-auth/initializers/setup-session", "ember-simple-auth/initializers/setup-session-service", "ember-simple-auth/initializers/setup-session-restoration"], function (_exports, _environment, _configuration, _setupSession, _setupSessionService, _setupSessionRestoration) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    name: 'ember-simple-auth',

    initialize(registry) {
      const config = _environment.default['ember-simple-auth'] || {};
      config.rootURL = _environment.default.rootURL || _environment.default.baseURL;

      _configuration.default.load(config);

      (0, _setupSession.default)(registry);
      (0, _setupSessionService.default)(registry);
      (0, _setupSessionRestoration.default)(registry);
    }

  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/initializers/export-application-global", ["exports", "rdc-ui-app-login/config/environment"], function (_exports, _environment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.initialize = initialize;
  _exports.default = void 0;

  function initialize() {
    var application = arguments[1] || arguments[0];

    if (_environment.default.exportApplicationGlobal !== false) {
      var theGlobal;

      if (typeof window !== 'undefined') {
        theGlobal = window;
      } else if (typeof global !== 'undefined') {
        theGlobal = global;
      } else if (typeof self !== 'undefined') {
        theGlobal = self;
      } else {
        // no reasonable global, just bail
        return;
      }

      var value = _environment.default.exportApplicationGlobal;
      var globalName;

      if (typeof value === 'string') {
        globalName = value;
      } else {
        globalName = Ember.String.classify(_environment.default.modulePrefix);
      }

      if (!theGlobal[globalName]) {
        theGlobal[globalName] = application;
        application.reopen({
          willDestroy: function () {
            this._super.apply(this, arguments);

            delete theGlobal[globalName];
          }
        });
      }
    }
  }

  var _default = {
    name: 'export-application-global',
    initialize: initialize
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/initializers/liquid-fire", ["exports", "liquid-fire/velocity-ext"], function (_exports, _velocityExt) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    name: 'liquid-fire',
    initialize: function () {}
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/initializers/local-storage-adapter", ["exports", "ember-local-storage/initializers/local-storage-adapter"], function (_exports, _localStorageAdapter) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _localStorageAdapter.default;
    }
  });
  Object.defineProperty(_exports, "initialize", {
    enumerable: true,
    get: function () {
      return _localStorageAdapter.initialize;
    }
  });
});
;define("rdc-ui-app-login/initializers/rdc-mobile-detector", ["exports", "rdc-ui-adn-components/initializers/rdc-mobile-detector"], function (_exports, _rdcMobileDetector) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcMobileDetector.default;
    }
  });
  Object.defineProperty(_exports, "initialize", {
    enumerable: true,
    get: function () {
      return _rdcMobileDetector.initialize;
    }
  });
});
;define("rdc-ui-app-login/initializers/responsive", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  /**
   * Ember responsive initializer
   *
   * Supports auto injecting media service app-wide.
   *
   * Generated by the ember-responsive addon. Customize initialize to change
   * injection.
   */
  var _default = {
    name: 'responsive',

    initialize(application) {
      application.inject('route', 'media', 'service:media');
      application.inject('controller', 'media', 'service:media');
    }

  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/instance-initializers/app-authenticator", ["exports", "rdc-ui-adn-core/instance-initializers/app-authenticator"], function (_exports, _appAuthenticator) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _appAuthenticator.default;
    }
  });
  Object.defineProperty(_exports, "initialize", {
    enumerable: true,
    get: function () {
      return _appAuthenticator.initialize;
    }
  });
});
;define("rdc-ui-app-login/instance-initializers/ember-data", ["exports", "ember-data/initialize-store-service"], function (_exports, _initializeStoreService) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    name: 'ember-data',
    initialize: _initializeStoreService.default
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/instance-initializers/ember-i18n", ["exports", "ember-i18n/instance-initializers/ember-i18n"], function (_exports, _emberI18n) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _emberI18n.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/instance-initializers/ember-simple-auth", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  // This is only needed for backwards compatibility and will be removed in the
  // next major release of ember-simple-auth. Unfortunately, there is no way to
  // deprecate this without hooking into Ember's internals…
  var _default = {
    name: 'ember-simple-auth',

    initialize() {}

  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/instance-initializers/raven-setup", ["exports", "ember-cli-sentry", "rdc-ui-app-login/config/environment"], function (_exports, _emberCliSentry, _environment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    name: 'sentry-setup',

    initialize(application) {
      (0, _emberCliSentry.initialize)(application.lookup ? application : application.container, _environment.default);
    }

  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/cn/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  const translations = {};
  Ember.merge(translations, {
    /* Side Menu Items */
    generic: {
      ok: '继续',
      cancel: '取消',
      login: "登录"
    },
    errors: {
      unknownError: "现在无法登录系统，请稍后再试。",
      serviceUnavailable: "渣打流动理财服务暂停服务，请稍后再试。",
      captchaError: "获取验证码失败，请稍后点击重试。",
      "CSL-TMX-666": "基于网上安全，您的网上理财服务已被暂停，我们将致电您以提供协助。若您收不到我们电话，请致电(852) 2886 8868 (按1 6 0)联络我们 。 (系统信息: 4258)。",
      "CSL-TMX-667": "基于网上安全，请经sc.com/cn 登录网上理财服务。"
    },

    /* Login Page */
    login: {
      heading: "请使用您在我行的网上银行/手机银行用户名、密码登录",
      step_up_prompt: "请先登录以申请服务或更改设定。",
      user_name: "用户名",
      password: "密码",
      captcha: "验证码",
      forgot: "忘记密码？",
      registrationLabel: "新电子理财用户？",
      registrationLabel_Web: "新的网上银行用户？",
      loginButton: "登录",
      registrationLink: "按此注册。",
      errorMessages: {
        wrongUserNamePassword: "请核对您的用户名及密码，并再次尝试。如果您仍未能登录本服务，请致电本行客户服务热线。(系统信息 : 3227)",
        allEmptyError: "请输入有效的用户名及密码。",
        emptyUser: "请输入您的用户名。",
        emptyPassword: "请输入您的密码。",
        specialCharacterError: "用户名必须为8-16位(请勿使用特殊字体 、符号、标点或空格)，请重新输入。 (系统信息 : 3226)",
        incorrectCredentials: "请核对您的用户名及密码，并再次尝试。如您仍未能登录本服务，请致电本行客户服务热线。(系统信息：3227)",
        blockSecondUser: "此流动设备已被另一用户注册，注册此服务只限于该用户在此设备上查阅。"
      },
      forgotPasswordUrl: 'https://cn.online.standardchartered.com/nfs/ral_mobile_registration.htm?a=doInitForgotUsrNamePasswd&lang=zh_CN',
      forgotPasswordUrlWeb: 'https://cn.online.standardchartered.com/nfs/ral_mobile_registration.htm?a=doInitForgotUsrNamePasswd&lang=zh_CN',
      mobileRegistrationUrl: '',
      mobileRegistrationUrlWeb: ''
    }
  });
  var _default = translations;
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-ae/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '30',
      heading: 'An SMS with a One Time Password (OTP) has been sent to the mobile number.',
      title: 'ENTER OTP',
      resendRetryText: "If you do not receive your OTP within 30 seconds, you may request for another one by clicking on the 'Request New OTP' link.",
      resendExceedLimitText: 'If you still do not receive your OTP after 30 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      messages: {
        otp_is_expired: 'Your last requested OTP has expired and is no longer valid. Please retry and input the new OTP within 240 seconds.',
        otp_is_invalid: 'You have entered an invalid OTP. Please enter a valid OTP.',
        your_account_locked: 'Sorry, due to maximum invalid OTP attempts, you will not receive any OTP for the next 24 hours. Please re-start your application later.'
      }
    },
    'rdc.loading.text': 'Loading...',
    'rdc.loading.saving': 'Loading...',
    upload: {
      circularProgress: ''
    },
    'rdc.file.upload.error.max.file': 'Exceeds the number of files allowed to upload.',
    coreModalMessages: {
      noInternet: 'There is no or poor internet connection. Please try again when there is a stable connection to a Wi-Fi or cellular data network.'
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-bd/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '30',
      resendRetryText: "If you do not receive your OTP within 30 seconds, you may request for another one by clicking on the 'Request New OTP ' link.",
      resendExceedLimitText: 'If you still do not receive your OTP after 30 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      messages: {
        your_account_locked: "We're sorry You have exceeded the maximum tries to enter the correct OTP and therefore your transaction has been cancelled.You may only retry again after 24 hours.",
        otp_is_expired: 'Your one-time password (OTP) had expired. Please request for a new OTP.',
        otp_is_invalid: 'You had entered invalid one-time password (OTP). Please check and re-enter your OTP.'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-bn/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '30',
      resendRetryText: "If you do not receive your OTP within 30 seconds, you may request for another one by clicking on the 'Request New OTP ' link.",
      resendExceedLimitText: 'If you still do not receive your OTP after 30 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      messages: {
        your_account_locked: "We're sorry You have exceeded the maximum tries to enter the correct OTP and therefore your transaction has been cancelled.You may only retry again after 24 hours.",
        otp_is_expired: 'Your one-time password (OTP) had expired. Please request for a new OTP.',
        otp_is_invalid: 'You had entered invalid one-time password (OTP). Please check and re-enter your OTP.'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-bw/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '30',
      heading: 'An SMS with the One Time Password(OTP) has been sent to your registered mobile number',
      title: 'ENTER OTP',
      resendRetryText: "If you do not receive your OTP within 30 seconds, you may request for another one by clicking on the 'Request New OTP' link.",
      resendExceedLimitText: 'If you still do not receive your OTP after 30 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      messages: {
        otp_is_expired: 'Your last requested OTP has expired and is no longer valid. Please retry and input the new OTP within 240 seconds.'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-ci/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    modalMessages: {
      commonError: 'We have encountered a technical error while processing your request. Please cancel the request and try again or contact our call centre open from Monday to Friday from 8:00 to 17:00 at +2252030281 for assistance if the problem persists.'
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-gh/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '30',
      heading: 'An SMS with the One Time Password(OTP) has been sent to your registered mobile number',
      title: 'ENTER OTP',
      resendRetryText: "If you do not receive your OTP within 30 seconds, you may request for another one by clicking on the 'Request New OTP' link.",
      resendExceedLimitText: 'If you still do not receive your OTP after 30 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      messages: {
        otp_is_expired: 'Your last requested OTP has expired and is no longer valid. Please retry and input the new OTP within 240 seconds.'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-hk/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    rdcOtp: {
      resendOtpEnableTime: '60',
      messages: {
        the_digits_of_the_pin_code_you_have_entered: 'The digits of the PIN code you have entered is invalid. Your transaction was cancelled',
        your_account_locked: 'Sorry, due to maximum invalid OTP attempts you will not receive any OTP for transactions for the next 2 mins.',
        otp_is_invalid: 'Sorry, the OTP you have entered is incorrect, Please try again. (Msg Code : 3239)',
        otp_is_expired: 'Your last requested OTP has expired and is no longer valid. Please retry and input the new OTP within 100 seconds. (Msg Code : 3286)',

        /* Soft Token */
        sc_invalid_pin: 'Sorry, the SC Mobile Key you have entered is incorrect, Please try again.',
        sc_invalid_pin_max_attempt: 'You have continuosly entered the wrong SC Mobile Key. Please call our customer care center now at +852 2886 8868',
        sc_generic_error: 'Sorry, something went wrong. Please try again. If the issue persists, please call our 24-hour Client Contact Centre at +852 2886 8868'
      }
    },
    //transaction password
    rdcTxnPwd: {
      sectionHeader: 'TRANSACTION PASSWORD',
      fieldLabel: 'PLEASE ENTER YOUR TRANSACTION PASSWORD',
      button: {
        back: 'BACK',
        next: 'NEXT'
      },
      messages: {
        txnpwd_invalid: 'Sorry, you have entered an invalid Transaction Password. Please try again.',
        txnpwd_limit_exceeded: 'Max retry attempt reached, kindly reset.'
      }
    },
    coreModalMessages: {
      pleaseCallSupport: "Please call our customer care center now at <a href='tel:+852 2886 8868' class='nowrap'>(+852) 2886 8868</a>."
    },
    softTokenNotifications: {
      contactForFurtherAssistance: "If you need further assistance, please call our Customer Service Hotline at <a href='tel:+852 2886 8868' class='nowrap'>(+852) 2886 8868</a>.",
      transactionNotAuthorized: "If you have not authorise this transaction, please call <a href='tel:+852 2886 8868' class='nowrap'>(+852) 2886 8868</a>",
      transactionNotDoneByYou: "If this transaction was not done by you, please call <a href='tel:+852 2886 8868' class='nowrap'>(+852) 2886 8868</a>"
    },
    modalMessages: {
      commonError: "Sorry, please try again. If the issue persists, please call our 24-hour Client Contact Centre at <a href='tel:+852 2886 8868'>(+852) 2886 8868</a>.",
      softTokenError: "Sorry. Your SC Mobile Key authentication was unsuccessful. If you need further assistance, please call our customer care center at <a href='tel:+852 2886 8868' class='nowrap'>(+852) 2886 8868</a>.",
      softTokenPinLocked: "You have continuously entered the wrong PIN. Please call our customer care center now at <a href='tel:+852 2886 8868' class='nowrap'>(+852) 2886 8868</a>.",
      softTokenDeviceOverride: 'You are registered for <i>SC Mobile Key</i> previously. Would you like to register for <i>SC Mobile Key</i> on this device? Do note that by doing so, <i>SC Mobile Key</i> registered previously will be deregistered.'
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-in/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      heading: 'An SMS with the One Time Password(OTP) has been sent to your registered mobile number',
      title: 'ENTER OTP',
      messages: {
        otp_is_expired: 'Your last requested OTP has expired and is no longer valid. Please retry and input the new OTP within 240 seconds.'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-ke/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '30',
      heading: 'Please enter the One Time Password (OTP) we have sent to your mobile phone number',
      title: 'ENTER OTP',
      resendRetryText: "If you do not receive your OTP within 30 seconds, you may request for another one by clicking on the 'Request New OTP' link.",
      resendExceedLimitText: 'If you still do not receive your OTP after 30 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      messages: {
        the_digits_of_the_pin_code_you_have_entered: 'The digits of the PIN code you have entered is invalid. Your transaction was cancelled',
        your_account_locked: 'You have exceeded the maximum attempts to enter the One Time Password(OTP) and therefore your transaction has been cancelled. You may only retry again after 24 hours.',
        otp_is_invalid: 'Sorry, the OTP you have entered is incorrect, Please try again.',
        otp_is_expired: 'Your one-time password(OTP) had expired. Please request for a new OTP.'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-lk/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '30',
      resendRetryText: "If you do not receive your OTP within 30 seconds, you may request for another one by clicking on the 'Request New OTP ' link.",
      resendExceedLimitText: 'If you still do not receive your OTP after 30 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      messages: {
        your_account_locked: "We're sorry You have exceeded the maximum tries to enter the correct OTP and therefore your transaction has been cancelled.You may only retry again after 24 hours.",
        otp_is_expired: 'Your one-time password (OTP) had expired. Please request for a new OTP.',
        otp_is_invalid: 'You had entered invalid one-time password (OTP). Please check and re-enter your OTP.'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-my/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '30',
      heading: 'An SMS with the One Time Password(OTP) has been sent to your registered mobile number',
      title: 'ENTER OTP',
      resendRetryText: "If you do not receive your OTP within 30 seconds, you may request for another one by clicking on the 'Request New OTP'.",
      resendExceedLimitText: 'If you still do not receive your OTP after 30 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      messages: {
        the_digits_of_the_pin_code_you_have_entered: 'The digits of the PIN code you have entered is invalid. Your transaction was cancelled',
        your_account_locked: 'You have exceeded the PIN try limit. Kindly call our 24-hour Customer Care hotline at 1300 888 888/ + 603 7711 8888 for further assistance.',
        otp_is_invalid: 'Sorry, the OTP you have entered is incorrect, Please try again.',
        otp_is_expired: 'Your one-time password (OTP) had expired. Please request for a new OTP.'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-ng/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '30',
      heading: 'An SMS with the One Time Password(OTP) has been sent to your registered mobile number',
      title: 'ENTER OTP',
      resendRetryText: "If you do not receive your OTP within 30 seconds, you may request for another one by clicking on the 'Request New OTP' link.",
      resendExceedLimitText: 'If you still do not receive your OTP after 30 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      messages: {
        otp_is_expired: 'Your last requested OTP has expired and is no longer valid. Please retry and input the new OTP within 240 seconds.'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-np/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '30',
      resendRetryText: "If you do not receive your OTP within 30 seconds, you may request for another one by clicking on the 'Request New OTP ' link.",
      resendExceedLimitText: 'If you still do not receive your OTP after 30 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      messages: {
        your_account_locked: "We're sorry You have exceeded the maximum tries to enter the correct OTP and therefore your transaction has been cancelled.You may only retry again after 24 hours.",
        otp_is_expired: 'Your one-time password (OTP) had expired. Please request for a new OTP.',
        otp_is_invalid: 'You had entered invalid one-time password (OTP). Please check and re-enter your OTP.'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-pk/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '30',
      resendRetryText: "If you do not receive your OTP within 30 seconds, you may request for another one by clicking on the 'Request New OTP ' link.",
      resendExceedLimitText: 'If you still do not receive your OTP after 30 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      messages: {
        your_account_locked: 'Your current One Time Password (OTP) has become invalid due to multiple incorrect attempts.',
        otp_is_expired: 'Your one-time password (OTP) had expired. Please request for a new OTP.',
        otp_is_invalid: 'You had entered invalid one-time password (OTP). Please check and re-enter your OTP.'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-sg/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    modalMessages: {
      commonError: 'Sorry, something went wrong. Please try again. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000.'
    },
    rdcOtp: {
      title: 'ENTER OTP',
      button: {
        resend: 'REQUEST NEW OTP'
      },
      messages: {
        /* Soft Token */
        sc_invalid_pin: 'Sorry, the SC Mobile Key you have entered is incorrect, Please try again.',
        sc_invalid_pin_max_attempt: 'You have continuosly entered the wrong SC Mobile Key. Please call our customer care center now at +65 6747 7000',
        sc_generic_error: 'Sorry, something went wrong. Please try again. If the issue persists, please call our 24-hour Client Contact Centre at +65 6747 7000'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-vn/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '30',
      resendRetryText: "If you do not receive your OTP within 30 seconds, you may request for another one by clicking on the 'Request New OTP ' link.",
      resendExceedLimitText: 'If you still do not receive your OTP after 30 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      messages: {
        your_account_locked: "We're sorry You have exceeded the maximum tries to enter the correct OTP and therefore your transaction has been cancelled.You may only retry again after 24 hours.",
        otp_is_expired: 'Your one-time password (OTP) had expired. Please request for a new OTP.',
        otp_is_invalid: 'You had entered invalid one-time password (OTP). Please check and re-enter your OTP.'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en-zm/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '30',
      heading: 'An SMS with the One Time Password(OTP) has been sent to your registered mobile number',
      title: 'ENTER OTP',
      resendRetryText: "If you do not receive your OTP within 30 seconds, you may request for another one by clicking on the 'Request New OTP' link.",
      resendExceedLimitText: 'If you still do not receive your OTP after 30 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      messages: {
        otp_is_expired: 'Your last requested OTP has expired and is no longer valid. Please retry and input the new OTP within 240 seconds.'
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en/config", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  // Ember-I18n includes configuration for common locales. Most users
  // can safely delete this file. Use it if you need to override behavior
  // for a locale or define behavior for a locale that Ember-I18n
  // doesn't know about.
  var _default = {// rtl: [true|FALSE],
    //
    // pluralForm: function(count) {
    //   if (count === 0) { return 'zero'; }
    //   if (count === 1) { return 'one'; }
    //   if (count === 2) { return 'two'; }
    //   if (count < 5) { return 'few'; }
    //   if (count >= 5) { return 'many'; }
    //   return 'other';
    // }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/en/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    generic: {
      ok: "Ok",
      cancel: "Cancel",
      login: "LOGIN"
    },
    biometricAuth: {
      title: 'Biometric Auth Help',
      message: 'Please use bio metric authentication from your app to setup.',
      step1: 'Standard Chartered Bank requires that you login in with Touch ID (or) Face ID on your SCmobile registered mobile device to confirm your identity.',
      step2: 'This page will reload automatically once you complete the Standard chartered bio-metric login on your mobile.',
      step3: 'Please do not click back or refresh button.',
      biometric_auth_time_expired: 'For online security, we are not processing your request at this moment. Please try again later.'
    },
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '20',
      heading: 'An SMS with OTP has been sent to your mobile number',
      title: 'Enter your OTP',
      titleWithMobileNumber: 'Enter the {{count}} digit code sent to *****{{mobileNumber}}',
      resendRetryText: "If you do not receive your OTP within 20 seconds, you may request for another one by clicking on the 'Request New OTP'.",
      resendExceedLimitText: 'If you still do not receive your OTP after 20 seconds, please try again later. The SMS network may be experiencing heavy traffic.',
      button: {
        cancel: 'CANCEL',
        resend: 'Request New OTP',
        resend2: 'Resend',
        proceed: 'PROCEED',
        back: 'BACK',
        next: 'NEXT',
        home: 'HOME',
        submit: 'SUBMIT'
      },
      messages: {
        the_digits_of_the_pin_code_you_have_entered: 'The digits of the PIN code you have entered is invalid. Your transaction was cancelled',
        your_account_locked: 'Sorry, due to maximum invalid OTP attempts you will not receive any OTP for transactions for the next 24 hours.',
        otp_is_invalid: 'Sorry, the OTP you have entered is incorrect, Please try again.',
        otp_is_expired: 'Your last requested OTP has expired and is no longer valid. Please retry and input the new OTP within 100 seconds.',
        otp_is_expired_and_limit_exceeded: 'Your One Time Pin (OTP) has expired. Please login again to obtain a new OTP. (Err Code:2353)'
      },
      requestCountdown: 'Request New OTP in <span> {{remainingTime}} </span> seconds',
      scMobileKey: 'SC Mobile Key',
      firstLoginHeader: 'Activate <span class="nowrap">SC Mobile Key</span>',
      firstLoginMessage: 'You are logging in for the first time using <span class="nowrap">SC Mobile Key</span>. To activate <span class="nowrap">SC Mobile Key</span>, please key in the OTP sent to your mobile number in the next screen.',
      firstLoginHelp: 'If you have not registered for <span class="nowrap">SC Mobile Key</span>, please call +65 6747 7000 immediately.',
      firstLoginHeading: 'To activate <span class="nowrap">SC Mobile Key</span>, please key in the OTP sent to your mobile number',
      firstTxnMessage: 'You are performing a Transaction Signing for the first time using SC Mobile Key. To activate SC Mobile Key, please key in the OTP sent to your mobile number in the next screen.',
      firstTxnOtpScreenHeading: 'To activate SC Mobile Key for Transaction Signing usage, please key in the OTP sent to your mobile number.'
    },
    errors: {
      unknownError: "We’re unable to log you in at this moment. Please try again later.",
      serviceUnavailable: "The Standard Chartered Mobile Banking service is currently unavaliable. Please try again later.",
      "CSL-TMX-666": "For online security, your Online Banking service access is currently suspended and we will call you to assist. Please contact us at (852) 2886 8868 (press 2 6 0) if you cannot receive our call. (Msg Code : 4258)",
      "CSL-TMX-667": "For online security, please login to Online Banking at sc.com/hk",
      genericError: "Something went wrong. Please try again.",
      loginId: "Enter your valid ID"
    },

    /* Login Page */
    login: {
      enter_your_agent_details: "Sign in to employee verification portal",
      forgot_agent_details: "Forgot Username or Password?",
      registration_agent: "New to Employee Loan Applications verification portal?",
      registerLabel: "REGISTER",
      custCareNo: "+254 329 3900",
      loginId: "Enter your login Id",
      register_otp: "Enter the OTP sent to your mail",
      register_header: "Create new password for your account",
      register_newPwd: "New Password (8-16 letters and/or numbers)",
      register_reconfirm: "Reconfirm Password (8-16 letters and/or numbers)",
      heading: "Login",
      enter_your_staff_details: "Enter your staff details to continue",
      step_up_prompt: "Please login to register for this feature or to change your settings.",
      user_name: "Username",
      password: "Password",
      forgot: "FORGOT?",
      registrationLabel: "New to Digital Banking?",
      registrationLabel_Web: "New to Online Banking?",
      loginButton: "Login",
      registrationLink: "Register Here",
      errorMessages: {
        enter_your_agent_details: "Sign in to employee verification portal",
        forgot_agent_details: "Forgot Username or Password?",
        registration_agent: "New to Employee Loan Applications verification portal?",
        registerLabel: "REGISTER",
        custCareNo: "+254 329 3900",
        register_header: "Create new password for your account",
        register_newPwd: "New Password (8-16 letters and/or numbers)",
        register_reconfirm: "Reconfirm Password (8-16 letters and/or numbers)",
        wrongUserNamePassword: "Please verify your Username/Password and retry. If the problem still exists, please call our Customer Service Hotline. (Msg Code : 3227)",
        allEmptyError: "Please enter a valid username and password.",
        emptyUser: "Please enter your username.",
        emptyPassword: "Please enter your password.",
        emptyLoginIdError: "Please enter login ID",
        specialCharacterError: "Username must be 8-16 characters (do not use special character, punctuation mark or space), please re-input.",
        incorrectCredentials: "Please verify your Username/Password and retry. If the problem still exists, please call our Customer Service Hotline.",
        blockSecondUser: "This device is registered to another user. Feature registration is restricted to the registered user on this device.",
        passwordSpecialCharacterError: 'Password must contain one capital letter, one small letter , one number and one special character with minimum of 8 character and maximum of 16 character',
        passwordDoNotMatch: "Passwords does not match"
      },
      forgotPasswordUrl: 'https://ibank.standardchartered.com.hk/nfs/ral_mobile_registration.htm?a=doInitForgotUsrNamePasswd&regMethod=ATM&lang=en_US',
      forgotPasswordUrlWeb: 'https://ibank.standardchartered.com.hk/nfs/ral_forgot_passcode.htm?a=doInitCommonLanding&r=0314C5BF-5E9C-76A1-4531-8F8BD0490300&lang=en_US',
      mobileRegistrationUrl: 'https://ibank.standardchartered.com.hk/nfs/ral_mobile_registration.htm?a=doInitMobile&lang=en_US',
      mobileRegistrationUrlWeb: 'https://ibank.standardchartered.com.hk/nfs/ral_tnc.htm?t=18-2-A4733C3ADACBFBBAA49EA8FAAFECCBAB&r=0BDD9664-0583-075D-F2FE-B0E71DDE2946&lang=en_US'
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/fr-ci/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    modalMessages: {
      commonError: 'We have encountered a technical error while processing your request. Please cancel the request and try again or contact our call centre open from Monday to Friday from 8:00 to 17:00 at +2252030281 for assistance if the problem persists.'
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/fr/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    /* Generic Items */
    generic: {
      back: 'Retour',
      login: 'LOGIN',
      termsAndCondition: 'Terms and Conditions',
      on: 'ON',
      off: 'OFF',
      yes: 'Yes',
      no: 'NO',
      ok: 'OK',
      cancel: 'CANCEL',
      continue: 'Continue',
      new: 'NEW',
      done: 'DONE',
      logout: 'Déconnexion',
      coming_soon: 'coming soon..'
    },
    coreModalMessages: {
      noInternet: 'La connexion internet est mauvaise ou non fonctionnelle. Veuillez réessayer lorsque la connexion au réseau Wi-Fi ou cellulaire est stable.',
      serviceUnavailable: 'Ce service est actuellement indisponible, veuillez réessayer plus tard.'
    },
    // otp page
    rdcOtp: {
      resendOtpEnableTime: '20',
      heading: 'Un mot de passe à usage unique (OTP) vous a été envoyé par SMS',
      title: 'Entrez votre OTP',
      button: {
        cancel: 'ANNULER',
        resend: 'Renvoyer OTP',
        resend2: 'Renvoyer',
        proceed: 'PROCÉDER',
        back: 'PRÉCÉDENT',
        next: 'SUIVANT',
        home: 'ACCUEIL',
        submit: 'VALIDER'
      },
      messages: {
        the_digits_of_the_pin_code_you_have_entered: 'The digits of the PIN code you have entered is invalid. Your transaction was cancelled',
        your_account_locked: 'Your account locked for 24 hours.',
        otp_is_invalid: 'Le mot de passe temporaire est invalide. Veuillez réessayer',
        otp_is_expired: 'Your last requested OTP has expired and is no longer valid. Please retry and input the new OTP within 100 seconds.'
      },
      requestCountdown: 'Demandez un nouveau OTP dans <span> {{remainingTime}} </span> secondes'
    },
    navigationMenu: {
      logout: 'DECONNEXION'
    },
    upload: {
      circularProgress: 'Veuillez fournir les documents suivants'
    },
    'rdc.file.upload.label': 'Prendre une Photo / Importer un document',
    'rdc.file.upload.more': 'Importer une autre image',
    'rdc.file.upload.success': 'Fichier téléchargé avec succès',
    'rdc.file.upload.unsuccess': 'Le téléchargement du fichier a échoué. Veuillez supprimer ce fichier pour continuer',
    'rdc.file.upload.uploading': 'Téléchargement',
    'rdc.file.upload.placeholder': 'Télécharger ou prendre une photo',
    'rdc.file.upload.error.max.file': 'Le téléchargement de fichiers dépasse le nombre maximal de fichiers.',
    'rdc.file.upload.error.max.size': 'La taille des fichiers téléchargés dépasse la taille totale maximale de tous les fichiers.',
    'rdc.file.upload.error.file.exists': ' déjà téléchargé.',
    'rdc.file.upload.error.max.size.single': 'La taille du fichier téléchargé dépasse la taille maximale du fichier unique.',
    'rdc.file.upload.error.file.unsupported': 'Type de fichier non pris en charge.',
    'rdc.file.upload.status.deleting': 'Suppression ......',
    'rdc.loading.text': 'Création de la référence du dossier ...',
    'rdc.loading.saving': 'Enregistrement en cours…',
    'rdc.dateInput.placeholder': 'JJ/MM/AAAA',
    rdcDatePicker: {
      label1: 'Les 7 derniers jours',
      label2: 'Le mois dernier',
      label3: '3 derniers mois'
    },
    modalMessages: {
      idleSessionTitle: 'Votre session va bientôt expirer.',
      idleSessionMessage: 'Appuyez OK pour continuer la session. Appuyez Déconnexion pour retourner à la page de Connexion.'
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/vi/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = {
    // otp page
    generic: {
      logout: 'ĐĂNG XUẤT',
      ok: 'OK'
    },
    rdcOtp: {
      resendOtpEnableTime: '30',
      heading: 'Tin nhắn OTP đã được gửi đến số điện thoại đăng ký của Quý khách',
      title: 'Nhập OTP',
      resendRetryText: 'Vui lòng yêu cầu OTP mới nếu Quý khách không nhận được OTP trong 30 giây nữa.',
      resendExceedLimitText: 'Nếu Quý khách vẫn chưa nhận được mã OTP, vui lòng thử lại lần nữa.',
      button: {
        resend: 'Yêu cầu OTP mới',
        back: 'Quay lại',
        next: 'Tiếp theo',
        submit: 'GỬI'
      },
      messages: {
        your_account_locked: 'Giao dịch đã bị hủy do Quý khách đã nhập sai OTP quá số lần cho phép. Quý khách có thể  thử lại lần nữa sau 24h tới.',
        otp_is_invalid: 'Quý khách đã nhập sai OTP. Vui lòng kiểm tra và nhập lại.'
      }
    },
    modalMessages: {
      idleSessionTitle: 'Phiên giao dịch của Quý Khách sắp kết thúc',
      idleSessionMessage: 'Chọn OK để tiếp tục. Chọn ĐĂNG XUẤT để quay trở lại trang đăng nhập'
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/zh-cn/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  // import preloginTranslation from "rdc-ui-app-mobile-banking/locales/en/translations";
  //
  // const translations = {};
  // Ember.merge(translations, preloginTranslation);
  // Ember.merge(translations,{
  //   'baseapp.login-message.back-to-login': '返回登入'
  // });
  // export default translations;
  var _default = {
    /* Generic Items */
    generic: {
      back: '返回',
      login: '登入',
      termsAndCondition: '條款及細則',
      on: '開',
      off: '關',
      yes: '是',
      no: '沒有',
      ok: '繼續',
      cancel: '取消',
      continue: '繼續',
      new: '新',
      done: '確定',
      coming_soon: 'coming soon..'
    },
    'baseapp.login-message.back-to-login': '返回登入',
    CREDITCARD: {
      pinSetup: {
        journeyHeader: 'Credit Card PIN Setup/Change'
      }
    },
    prelogin: {
      home: {
        goodMorning: '早晨',
        goodAfternoon: '午安',
        goodEvening: '晚安'
      }
    },
    coreModalMessages: {
      settingsBlocked: '此流動裝置已經被登記，故不能更新「設定」。',
      switchDeviceRegistration: 'By choosing to continue, you are registering on this device and past registrations on any other devices would be lost. Do you want to continue?',
      switchDeviceRegistrationForSoftToken: 'You are registering for <i>SC Mobile Key</i> on this device. By doing so, all registrations on any other device would be lost. <br>Do you want to continue?',
      noInternet: 'There is no internet connection. Please try again when there is a stable connection to a Wi-Fi or cellular data network.',
      pleaseCallSupport: "请致电我们的客户服务中心 <a href='tel:+852 2886 8868'>(+852) 2886 8868</a>."
    },
    // otp page
    rdcOtp: {
      heading: '已发送6位数的短信验证码至您的手机上。',
      title: '请输入6位数的短信验证码。',
      resendRetryText: '如您在20秒内仍未能接收一次有效密码，请选择重新接收。',
      resendExceedLimitText: '如您在20秒内仍未能接收一次有效密码，请稍后再试。',
      button: {
        resend: '重新接收一次有效密码。',
        proceed: '提交',
        submit: '提交',
        back: '上一步',
        next: '下一步'
      },
      messages: {
        your_account_locked: '输入一次有效密码次数已超出限制。您可在24小时后再试。 (错误编号:1572)',
        otp_is_invalid: '您输入的一次有效密码不正确。请核实并再次输入一次有效密码。',
        otp_is_expired: '短信验证码已失效，请重新获取验证码并在4分钟之内完成输入和验证。[系统讯息8002]'
      },
      requestCountdown: '未收到短信验证码于<span>{{remainingTime}}</span>秒后重发'
    },
    rdcTxnPwd: {
      sectionHeader: '交易密码',
      fieldLabel: '请输入阁下的交易密码',
      button: {
        back: '上一步',
        next: '下一步',
        submit: '提交'
      },
      messages: {
        txnpwd_invalid: '对不起，您所输入的「交易密码」不正确，请重新输入.',
        txnpwd_limit_exceeded: '「交易密碼」已因多次錯誤輸入而無效.'
      }
    },
    // Navigation Menu
    navigationMenu: {
      standard_chartered: '渣打銀行',
      inbox: '收件箱',
      settings: '設定',
      login: '登入',
      logout: '登出',
      lastLogin: '閣下上一次登入[HH:SS] 上午or下午',
      home: '主頁',
      wealthPro: '專智融資',
      transfers: '轉賬',
      transfersSubMenu: {
        betweenMyAccounts: '至我的戶口',
        payNowTransfers: 'PayNow Transfers',
        localTransfers: ' 至其他戶口',
        internationalTransfers: 'International Transfers',
        scheduledTransfer: 'Standing Instructions & Scheduled Transfers',
        addNewPayee: 'Manage Payee',
        transferHistory: '紀錄',
        payScCreditCards: 'Pay SC Credit Cards',
        alipayAccountTransfers: '至支付寶賬戶',
        octopusOePayTransfers: '至八達通O! ePay賬戶'
      },
      payments: '繳款',
      paymentsSubMenu: {
        payBills: '繳付賬單',
        addBiller: 'Add Biller',
        payScCreditCards: '繳付我的信用卡',
        payOtherBanksCreditCards: "Pay Other Bank's Credit Cards",
        eCashiersOrder: "eCashier's Order",
        paymentHistory: '紀錄'
      },
      invesments: '投資',
      invesmentsSubMenu: {
        latestMarketInsights: '最新市場觀點',
        personalInvestmentIdeas: 'Personal Investment Ideas',
        wealthDashboard: 'Wealth Dashboard',
        scEquitiesApp: 'SC Equities 程式',
        investmentProfile: '投資取向'
      },
      profileDetails: '配置文件詳情',
      helpNServices: 'Help & Services',
      helpAndServices: 'Help and Services',
      helpAndServicesSubMenu: {
        overseasCardUsage: 'Overseas Card Usage',
        cardActivation: 'Card Activation',
        faq: '常見問題'
      },
      latestMarketInsights: '最新市場觀點',
      theGoodLifeApp: 'The Good Life App',
      getCashOrLocate: 'Get Cash/Locate',
      locate: '尋找',
      contact: 'Contact',
      about: '關於我們',
      scHomeApp: 'SC Home 程式',
      octopusOePay: '八達通O! ePay程式',
      apply: '申請',
      language: '語言',
      faqs: '常見問題',
      switchToDesktop: '切換至桌面模式'
    },
    'rdc.file.upload.label': '上载图片',
    'rdc.file.upload.more': '上载其他图片',
    'rdc.file.upload.placeholder': 'Upload or take a picture',
    'rdc.file.upload.error.max.file': 'Uploading files exceeds max number of files.',
    'rdc.file.upload.error.max.size': "Uploading files' size exceeds max total size of all files.",
    'rdc.file.upload.error.file.exists': '已上载',
    'rdc.file.upload.error.max.size.single': '文件大小超过上限',
    'rdc.file.upload.error.file.unsupported': '文件格式不相容',
    'rdc.file.upload.status.deleting': '移除中 ......',
    'rdc.file.completed': '完成',
    'rdc.file.conn.lost': '连接失败，无法上载。',
    'rdc.file.uploading': '已上載',
    models: {
      accounts: {
        balance: 'Balance',
        outstandingBalance: 'Outstanding Balance',
        currentBalance: '戶口結餘',
        availableBalance: 'Available Balance'
      }
    },
    modalMessages: {
      idleSessionTitle: '您的登入即将超时',
      idleSessionMessage: '请按「是」以继续浏览，或按「登出」以回到登入页面。'
    },
    softTokenNotifications: {
      successfullyRejected: '您已成功拒絕此交易。',
      contactForFurtherAssistance: "如果您需要進一步的幫助，請致電 <a href='tel:+852 2886 8868' class='nowrap'>(+852) 2886 8868</a>.",
      rejectBtn: '拒絕',
      approveBtn: '批准',
      notYou: 'Not you?',
      confirmReject: '请确认您想拒绝此交易。',
      pushExpired: '此驗證無效​​或已過期。請重新發送通知。',
      oops: 'Oops!',
      transactionRejected: '您已拒绝此交易。',
      transactionNotAuthorized: "如果您尚未授權此交易，請致電 <a href='tel:+852 2886 8868' class='nowrap'>(+852) 2886 8868</a>",
      transactionNotDoneByYou: "如果这项交易不是由您完成的，请致电<a href='tel: +852 2886 8868' class='nowrap'>(+852) 2886 8868</a>。",
      otpGenerationErrorInpush: '您的SC Mobile Key無效。請重新啟動。',
      pushSendingFailed: '您的驗證失敗。如果您想再試一次，請按「重新發送通知」。',
      abortRequest: '你想取消這個交易? '
    },

    /* 3rd Party App Disclaimer - Short Version for Modal Dialog*/
    thirdPartyAppDisclaimerShort: '按以下「繼續」可連接至一個第三方流動應用程式(「第三方程式」)。第三方程式乃非渣打銀行(香港)有限公司及其他渣打集團成員(合稱「本行」)所擁有。',
    SoftToken: {
      authoriseTransaction: 'Verify this transaction by entering your Soft Token PIN',
      ENTERPIN: {
        header: 'Soft Token Verification',
        header2: 'Enter Soft Token PIN',
        ERRORS: {
          wrongPin: 'You have entered an invalid PIN'
        }
      },
      BUTTONS: {
        cancel: '取消',
        confirm: '确认',
        forgotPin: 'Forgot PIN'
      }
    },
    softTokenOtp: {
      loginauth_title: 'Login Authentication',
      offlinepin_title: 'Offline PIN',
      offlinepin_challenge_section: 'Follow these steps to generate an offline PIN to authorise your transaction.',
      offlinepin_nochallenge_section: 'Please complete the following for your offline transaction.',
      button: {
        generate_offline_pin: 'Generate Offline PIN',
        resend_notify: 'RESEND NOTIFICATION',
        cancel: '取消',
        confirm: '确认',
        back: '上一步',
        next: '下一步',
        submit: '提交'
      },
      messages: {
        transaction_push_notification: 'A push notification was sent to your primary device, please authorise this transaction.',
        transaction_push_notification_fail: 'We are unable to reach your primary device. Please click generate offline pin to authorise this transaction.',
        enter_challenge_code: 'Enter the 8-digit PIN below to generate the offline PIN for transaction:',
        sc_invalid_pin_max_attempt: 'You have continuosly entered the wrong SC Mobile Key. Please call our customer care center now at +852 2886 8868',
        sc_generic_error: 'Sorry, something went wrong. Please try again. If the issue persists, please call our 24-hour Client Contact Centre at +852 2886 8868'
      },
      label: {
        ERRORS: {
          wrongPin: 'Softtoken is incorrect',
          //yet to receive chinese text
          expire: 'Sorry,this softtoken has expired and is no longer valid.Please request for a new softtoken pin and try again.(Error Code:1522),'
        },
        loginauth_push_notify: 'To proceed, please go to your registered Soft Token device and tap on “Approve" on <br/> the notification. Then, enter your Soft Token PIN to approve this transaction.',
        loginauth_generate_offline_pin: 'If you do not have wi-fi or data service on your Soft Token enabled device, you can',
        offline_pin: {
          no_challenge: {
            step1: '<b>第一步:</b> <br/> 于渣打流动理财的选单中，先选择「离线密码」再选择「取得离线交易密码」。',
            step2: '<b>第二步:</b> <br/> 在已登记的手提电话上输入6位数字流动保安密码。',
            step3: '<b>第三步:</b> <br/> 输入6位数字密码以完成交易。',
            field: '输入6位数字密码',
            mobile_pin_input_title: 'Enter your Soft Token PIN to proceed with your offline transaction.',
            mobile_pin_input_field: 'Enter 6-digit PIN'
          },
          with_challenge: {
            step1: '<b>Step 1:</b> <br/> On your SC Mobile Key registered device, go to the side-menu of the SC<br/> Mobile app and select "Generate Offline PIN for Transactions".',
            step2: '<b>Step 2:</b> <br/> Enter the PIN for your SC Mobile Key into your registered device.',
            step3: '<b>Step 3:</b> <br/> Enter the 8 digits shown below into your SC Mobile Key registered device.',
            step4: '<b>Step 4:</b> <br/> Enter the 6-digit PIN that was generated into the field below to authorise your transaction.',
            field: 'ENTER 6-DIGIT PIN:'
          }
        }
      }
    }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/zh-hk/config", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  // Ember-I18n includes configuration for common locales. Most users
  // can safely delete this file. Use it if you need to override behavior
  // for a locale or define behavior for a locale that Ember-I18n
  // doesn't know about.
  var _default = {// rtl: [true|FALSE],
    //
    // pluralForm: function(count) {
    //   if (count === 0) { return 'zero'; }
    //   if (count === 1) { return 'one'; }
    //   if (count === 2) { return 'two'; }
    //   if (count < 5) { return 'few'; }
    //   if (count >= 5) { return 'many'; }
    //   return 'other';
    // }
  };
  _exports.default = _default;
});
;define("rdc-ui-app-login/locales/zh-hk/translations", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  const translations = {};
  Ember.merge(translations, {
    /* Side Menu Items */
    generic: {
      ok: '繼續',
      cancel: '取消',
      login: "登入"
    },
    errors: {
      unknownError: "現時無法登入系統，請稍候再試。",
      serviceUnavailable: "渣打流動理財服務暫停服務，請稍後再試。",
      "CSL-TMX-666": "基於網上保安，您的網上理財服務已被暫停，我們將致電您以提供協助。若您收不到我們電話，請致電(852) 2886 8868 (按1 6 0)聯絡我們 。 (系統信息: 4258)。",
      "CSL-TMX-667": "基於網上保安，請經sc.com/hk/zh 登入網上理財服務。"
    },

    /* Login Page */
    login: {
      heading: "登入",
      step_up_prompt: "請先登入以申請服務或更改設定。",
      user_name: "用戶名稱",
      password: "密碼",
      forgot: "忘記密碼？",
      registrationLabel: "新電子理財用戶？",
      registrationLabel_Web: "新的網上銀行用戶？",
      loginButton: "登入",
      registrationLink: "按此登記。",
      errorMessages: {
        wrongUserNamePassword: "請核對您的用戶名稱及密碼，並再次嘗試。如您仍未能登入本服務﹐請致電本行客戶服務熱線。 (系統訊息 : 3227)",
        allEmptyError: "請輸入有效的用戶名稱及密碼。",
        emptyUser: "請輸入您的用戶名稱。",
        emptyPassword: "請輸入您的密碼。",
        specialCharacterError: "用戶名稱必須為8-16個位(請勿使用特別字體 、符號、標點或空格)，請重新輸入。 (系統訊息 : 3226)",
        incorrectCredentials: "請核對您的用戶名稱及密碼，並再次嘗試。如您仍未能登入本服務，請致電本行客戶服務熱線。(系統訊息：3227)",
        blockSecondUser: "此流動裝置己被另一用戶登記，登記此服務只限該用戶於此裝置查閱。"
      },
      forgotPasswordUrl: 'https://ibank.standardchartered.com.hk/nfs/ral_mobile_registration.htm?a=doInitForgotUsrNamePasswd&regMethod=ATM&lang=zh_HK',
      forgotPasswordUrlWeb: 'https://ibank.standardchartered.com.hk/nfs/ral_forgot_passcode.htm?a=doInitCommonLanding&r=0314C5BF-5E9C-76A1-4531-8F8BD0490300&lang=zh_HK',
      mobileRegistrationUrl: 'https://ibank.standardchartered.com.hk/nfs/ral_mobile_registration.htm?a=doInitMobile&lang=zh_HK',
      mobileRegistrationUrlWeb: 'https://ibank.standardchartered.com.hk/nfs/ral_tnc.htm?t=18-2-A4733C3ADACBFBBAA49EA8FAAFECCBAB&r=0BDD9664-0583-075D-F2FE-B0E71DDE2946&lang=zh_HK'
    }
  });
  var _default = translations;
  _exports.default = _default;
});
;define("rdc-ui-app-login/mixins/csl-authenticated-route-mixin", ["exports", "ember-simple-auth/mixins/authenticated-route-mixin"], function (_exports, _authenticatedRouteMixin) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Mixin.create(_authenticatedRouteMixin.default, {
    authenticationRoute: 'open-banking-login'
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/mixins/show-error-message", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Mixin.create({
    rdcModalManager: Ember.inject.service(),

    showLoginError(error) {
      let errorMessage = error;

      if (error.payload) {
        errorMessage = error.payload;

        if (errorMessage && errorMessage.errors && errorMessage.errors.length) {
          errorMessage = errorMessage.errors[0].detail;
        } else if (errorMessage && errorMessage.errMsg) {
          errorMessage = errorMessage.errMsg;
        }
      }

      if (!errorMessage) {
        errorMessage = this.i18n.t('errors.unknownError');
      }

      this.rdcModalManager.showDialogModal({
        level: "error",
        message: error,
        acceptButtonLabel: this.i18n.t("generic.ok"),
        customClass: "login-app-popup"
      });
      return false;
    }

  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/models/account-proxy", ["exports", "rdc-ui-adn-core/models/account-proxy"], function (_exports, _accountProxy) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _accountProxy.default;
    }
  });
});
;define("rdc-ui-app-login/models/account", ["exports", "rdc-ui-adn-core/models/account"], function (_exports, _account) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _account.default;
    }
  });
});
;define("rdc-ui-app-login/models/activation", ["exports", "rdc-ui-adn-core/models/activation"], function (_exports, _activation) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _activation.default;
    }
  });
});
;define("rdc-ui-app-login/models/authorize", ["exports", "ember-data"], function (_exports, _emberData) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = _emberData.default.Model.extend({
    accounts: _emberData.default.attr(),
    permissionsAsStrings: _emberData.default.attr(),
    clientId: _emberData.default.attr('string'),
    nonce: _emberData.default.attr('string'),
    state: _emberData.default.attr('string'),
    redirectUri: _emberData.default.attr('string'),
    responseType: _emberData.default.attr('string'),
    extraApplicationProperties: _emberData.default.attr(),
    // parsing accounts to make emberobject
    parsedAccounts: Ember.computed('accounts', function () {
      return this.accounts.map(function (item) {
        return Ember.Object.create(item);
      });
    })
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/models/bank", ["exports", "rdc-ui-adn-core/models/bank"], function (_exports, _bank) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _bank.default;
    }
  });
});
;define("rdc-ui-app-login/models/barcode", ["exports", "rdc-ui-adn-core/models/barcode"], function (_exports, _barcode) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _barcode.default;
    }
  });
});
;define("rdc-ui-app-login/models/branch", ["exports", "rdc-ui-adn-core/models/branch"], function (_exports, _branch) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _branch.default;
    }
  });
});
;define("rdc-ui-app-login/models/cardtransaction", ["exports", "rdc-ui-adn-core/models/cardtransaction"], function (_exports, _cardtransaction) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _cardtransaction.default;
    }
  });
});
;define("rdc-ui-app-login/models/casa", ["exports", "rdc-ui-adn-core/models/casa"], function (_exports, _casa) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _casa.default;
    }
  });
});
;define("rdc-ui-app-login/models/casatransaction", ["exports", "rdc-ui-adn-core/models/casatransaction"], function (_exports, _casatransaction) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _casatransaction.default;
    }
  });
});
;define("rdc-ui-app-login/models/challenge-otp-validation", ["exports", "rdc-ui-adn-core/models/challenge-otp-validation"], function (_exports, _challengeOtpValidation) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _challengeOtpValidation.default;
    }
  });
});
;define("rdc-ui-app-login/models/country", ["exports", "rdc-ui-adn-core/models/country"], function (_exports, _country) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _country.default;
    }
  });
});
;define("rdc-ui-app-login/models/credit-card", ["exports", "rdc-ui-adn-core/models/credit-card"], function (_exports, _creditCard) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _creditCard.default;
    }
  });
});
;define("rdc-ui-app-login/models/cryptokey", ["exports", "rdc-ui-adn-core/models/cryptokey"], function (_exports, _cryptokey) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _cryptokey.default;
    }
  });
});
;define("rdc-ui-app-login/models/customer-preference", ["exports", "rdc-ui-adn-core/models/customer-preference"], function (_exports, _customerPreference) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _customerPreference.default;
    }
  });
});
;define("rdc-ui-app-login/models/customer", ["exports", "rdc-ui-adn-core/models/customer"], function (_exports, _customer) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _customer.default;
    }
  });
});
;define("rdc-ui-app-login/models/debit-card", ["exports", "rdc-ui-adn-core/models/debit-card"], function (_exports, _debitCard) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _debitCard.default;
    }
  });
});
;define("rdc-ui-app-login/models/delivery-ack", ["exports", "rdc-ui-adn-core/models/delivery-ack"], function (_exports, _deliveryAck) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _deliveryAck.default;
    }
  });
});
;define("rdc-ui-app-login/models/detail", ["exports", "rdc-ui-adn-core/models/detail"], function (_exports, _detail) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _detail.default;
    }
  });
});
;define("rdc-ui-app-login/models/device-registration-feature", ["exports", "rdc-ui-adn-core/models/device-registration-feature"], function (_exports, _deviceRegistrationFeature) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _deviceRegistrationFeature.default;
    }
  });
});
;define("rdc-ui-app-login/models/device-registration", ["exports", "rdc-ui-adn-core/models/device-registration"], function (_exports, _deviceRegistration) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _deviceRegistration.default;
    }
  });
});
;define("rdc-ui-app-login/models/device", ["exports", "rdc-ui-adn-core/models/device"], function (_exports, _device) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _device.default;
    }
  });
});
;define("rdc-ui-app-login/models/document", ["exports", "rdc-ui-adn-core/models/document"], function (_exports, _document) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _document.default;
    }
  });
});
;define("rdc-ui-app-login/models/eligible-plan", ["exports", "rdc-ui-adn-core/models/eligible-plan"], function (_exports, _eligiblePlan) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _eligiblePlan.default;
    }
  });
});
;define("rdc-ui-app-login/models/fx-rate", ["exports", "rdc-ui-adn-core/models/fx-rate"], function (_exports, _fxRate) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _fxRate.default;
    }
  });
});
;define("rdc-ui-app-login/models/hr-login", ["exports", "ember-data"], function (_exports, _emberData) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = _emberData.default.Model.extend({
    action: _emberData.default.attr('string'),
    countryCode: _emberData.default.attr('string'),
    payload: _emberData.default.attr(''),
    companyCode: _emberData.default.attr('string'),
    encryptValue: _emberData.default.attr('string'),
    encryptOtp: _emberData.default.attr('string'),
    otpPrefix: _emberData.default.attr('string'),
    newPassword: _emberData.default.attr('string'),
    hrLevel: _emberData.default.attr('string'),
    otpSerialNo: _emberData.default.attr('string'),
    password: _emberData.default.attr('string'),
    mobileNo: _emberData.default.attr('string'),
    hrEmpId: _emberData.default.attr('string'),
    base64Challenge: _emberData.default.attr('string'),
    modulus: _emberData.default.attr('string'),
    exponent: _emberData.default.attr('string')
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/models/license", ["exports", "rdc-ui-adn-core/models/license"], function (_exports, _license) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _license.default;
    }
  });
});
;define("rdc-ui-app-login/models/loan", ["exports", "rdc-ui-adn-core/models/loan"], function (_exports, _loan) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _loan.default;
    }
  });
});
;define("rdc-ui-app-login/models/location", ["exports", "rdc-ui-adn-core/models/location"], function (_exports, _location) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _location.default;
    }
  });
});
;define("rdc-ui-app-login/models/message", ["exports", "rdc-ui-adn-core/models/message"], function (_exports, _message) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _message.default;
    }
  });
});
;define("rdc-ui-app-login/models/ng-bvn", ["exports", "rdc-ui-adn-core/models/ng-bvn"], function (_exports, _ngBvn) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _ngBvn.default;
    }
  });
});
;define("rdc-ui-app-login/models/notification", ["exports", "rdc-ui-adn-core/models/notification"], function (_exports, _notification) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _notification.default;
    }
  });
});
;define("rdc-ui-app-login/models/payment-registration", ["exports", "rdc-ui-adn-core/models/payment-registration"], function (_exports, _paymentRegistration) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _paymentRegistration.default;
    }
  });
});
;define("rdc-ui-app-login/models/payment", ["exports", "rdc-ui-adn-core/models/payment"], function (_exports, _payment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _payment.default;
    }
  });
});
;define("rdc-ui-app-login/models/pop", ["exports", "rdc-ui-adn-core/models/pop"], function (_exports, _pop) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _pop.default;
    }
  });
});
;define("rdc-ui-app-login/models/prospect", ["exports", "rdc-ui-adn-core/models/prospect"], function (_exports, _prospect) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _prospect.default;
    }
  });
});
;define("rdc-ui-app-login/models/reference", ["exports", "rdc-ui-adn-core/models/reference"], function (_exports, _reference) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _reference.default;
    }
  });
});
;define("rdc-ui-app-login/models/registration", ["exports", "rdc-ui-adn-core/models/registration"], function (_exports, _registration) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _registration.default;
    }
  });
});
;define("rdc-ui-app-login/models/server-registration", ["exports", "rdc-ui-adn-core/models/server-registration"], function (_exports, _serverRegistration) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _serverRegistration.default;
    }
  });
});
;define("rdc-ui-app-login/models/soft-token-activation", ["exports", "rdc-ui-adn-core/models/soft-token-activation"], function (_exports, _softTokenActivation) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _softTokenActivation.default;
    }
  });
});
;define("rdc-ui-app-login/models/soft-token", ["exports", "rdc-ui-adn-core/models/soft-token"], function (_exports, _softToken) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _softToken.default;
    }
  });
});
;define("rdc-ui-app-login/models/transaction", ["exports", "rdc-ui-adn-core/models/transaction"], function (_exports, _transaction) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _transaction.default;
    }
  });
});
;define("rdc-ui-app-login/models/unit-trust", ["exports", "rdc-ui-adn-core/models/unit-trust"], function (_exports, _unitTrust) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _unitTrust.default;
    }
  });
});
;define("rdc-ui-app-login/models/user", ["exports", "rdc-ui-adn-core/models/user"], function (_exports, _user) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _user.default;
    }
  });
});
;define("rdc-ui-app-login/resolver", ["exports", "ember-resolver"], function (_exports, _emberResolver) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _emberResolver.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/router", ["exports", "rdc-ui-app-login/config/environment"], function (_exports, _environment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  const Router = Ember.Router.extend({
    location: _environment.default.locationType,
    rootURL: _environment.default.rootURL
  });
  Router.map(function () {
    this.route('login');
    this.route('kaisuccess');
    this.route('refappsuccess');
    this.route('kaifailure');
    this.route('open-banking-login');
    this.route('open-banking-consent-permission');
    this.route('staff-login');
    this.route('agent-login', function () {});
    this.route('agent-registration');
    this.route('get-agent-data');
  });
  var _default = Router;
  _exports.default = _default;
});
;define("rdc-ui-app-login/routes/agent-login", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Route.extend({
    beforeModel() {
      let params = {
        countryCode: "KE"
      };
      let srcURL = window.location.href;

      if (srcURL) {
        srcURL = srcURL.split('?')[1];

        if (srcURL) {
          srcURL = srcURL.split('&');
          srcURL.forEach(item => {
            if (item.indexOf('ctry') != -1) {
              params.countryCode = item.split('=')[1];
            } else if (item.indexOf('companyCode') != -1) {
              params.companyCode = item.split('=')[1];
            } else if (item.indexOf('hrEmployeeId') != -1) {
              params.hrEmployeeId = item.split('=')[1];
            } else if (item.indexOf('action') != -1) {
              params.action = item.split('=')[1];
            }
          });
          params = Ember.Object.create(params);
        }
      }

      if (!params.action) this.controllerFor('agent-login').set('inputParams', params);
    }

  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/routes/agent-registration", ["exports", "rdc-ui-app-login/mixins/show-error-message"], function (_exports, _showErrorMessage) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Route.extend(_showErrorMessage.default, {
    i18n: Ember.inject.service(),
    rdcLoadingIndicator: Ember.inject.service(),
    router: Ember.inject.service(),
    rdcAjax: Ember.inject.service(),
    actionType: 'create',
    queryParams: {
      action: {
        refreshModel: true
      }
    },

    model(params) {
      if (params) {
        this.set('actionType', params.action);
      }
    },

    validateCredentials(passwordValue, retypePasswordValue, loginIdValue) {
      //Regex for Valid Characters i.e. Alphabets, Numbers and Space.
      var regex = /^[A-Za-z0-9 ]+$/;
      this.clearLoginInputs();
      return !loginIdValue ? this.showLoginError(this.i18n.t("login.errorMessages.emptyLoginIdError")) : !passwordValue || !retypePasswordValue ? this.showLoginError(this.i18n.t("login.errorMessages.emptyPassword")) : passwordValue.length < 8 || retypePasswordValue.length < 8 ? this.showLoginError(this.i18n.t("login.errorMessages.passwordMinLengthError")) : !regex.test(passwordValue) || !regex.test(retypePasswordValue) ? this.showLoginError(this.i18n.t("login.errorMessages.passwordSpecialCharacterError")) : passwordValue !== retypePasswordValue ? this.showLoginError(this.i18n.t("login.errorMessages.passwordDoNotMatch")) : true;
    },

    clearLoginInputs() {
      this.controller.setProperties({
        loginIdValue: " "
      });
      this.get('store').unloadAll('hr-login');
    },

    registerLogin() {
      if (!Ember.isEmpty(this.controller.loginIdValue)) {
        this.controller.set('hasError', false);
        this.controller.set('errorLabel', null);
        let hrCreateRequest = this.get('store').createRecord('hrLogin', {
          id: this.controller.loginIdValue,
          action: this.get('actionType'),
          countryCode: this.controllerFor('agent-login').inputParams.countryCode,
          companyCode: this.controllerFor('agent-login').inputParams.companyCode,
          hrEmpId: this.controllerFor('agent-login').inputParams.hrEmployeeId
        });

        try {
          this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(hrCreateRequest.save()).then(responseData => {
            let otpData = Ember.Object.create({});
            otpData['otpSerialNo'] = responseData.otpSerialNo;
            otpData['companyCode'] = responseData.companyCode;
            otpData['countryCode'] = responseData.countryCode;
            otpData['otpPrefix'] = responseData.otpPrefix;
            otpData['id'] = responseData.id;
            otpData['actionType'] = this.get('actionType');
            this.controllerFor('agent-login').set("registerLogin", otpData);
            this.clearLoginInputs();
            this.transitionTo('get-agent-data');
          }, error => {
            this.showLoginError(error);
            this.clearLoginInputs();
          });
        } catch (error) {
          this.showLoginError(error);
          this.clearLoginInputs();
        }
      } else {
        this.controller.set('hasError', true);
        this.controller.set('errorLabel', this.i18n.t('errors.loginId'));
      }
    },

    actions: {
      register() {
        this.registerLogin();
      },

      navigateToLogin() {
        this.clearLoginInputs();
        this.transitionTo('agent-login');
      }

    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/routes/application", ["exports", "rdc-ui-adn-core/routes/application"], function (_exports, _application) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = _application.default.extend({});

  _exports.default = _default;
});
;define("rdc-ui-app-login/routes/authenticated-route", ["exports", "rdc-ui-adn-core/routes/authenticated-route"], function (_exports, _authenticatedRoute) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _authenticatedRoute.default;
    }
  });
});
;define("rdc-ui-app-login/routes/get-agent-data", ["exports", "rdc-ui-app-login/mixins/show-error-message"], function (_exports, _showErrorMessage) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Route.extend(_showErrorMessage.default, {
    i18n: Ember.inject.service(),
    rdcLoadingIndicator: Ember.inject.service(),
    router: Ember.inject.service(),
    rdcModalManager: Ember.inject.service(),

    model() {
      let modelData = this.controllerFor('agent-login').get("registerLogin");
      let randomChallengeData = this.get('store').queryRecord('hr-login', {
        id: modelData.id,
        filter: {
          countryCode: modelData.countryCode
        }
      }).then(result => {
        return result;
      }).catch(error => {
        this.showLoginError(error);
        this.clearLoginInputs();
      });
      return Ember.RSVP.hash({
        modelData: modelData,
        randomChallengeData: randomChallengeData
      });
    },

    clearLoginInputs() {
      this.controller.setProperties({
        otpValue: '',
        passwordValue: '',
        retypePasswordValue: ''
      });
      this.get('store').unloadAll('hr-login');
      this.transitionTo('agent-login');
    },

    validateCredentials(passwordValue, retypePasswordValue) {
      //Regex for Valid Characters i.e. Alphabets, Numbers and Space.
      var regex = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\S+$).{8,16}$/;
      return !passwordValue || !retypePasswordValue ? this.showLoginError(this.i18n.t("login.errorMessages.emptyPassword")) : passwordValue.length < 8 || retypePasswordValue.length < 8 ? this.showLoginError(this.i18n.t("login.errorMessages.passwordSpecialCharacterError")) : !regex.test(passwordValue) || !regex.test(retypePasswordValue) ? this.showLoginError(this.i18n.t("login.errorMessages.passwordSpecialCharacterError")) : passwordValue !== retypePasswordValue ? this.showLoginError(this.i18n.t("login.errorMessages.passwordDoNotMatch")) : true;
    },

    async agentRegister() {
      let {
        passwordValue,
        retypePasswordValue,
        otpValue
      } = this.controller;

      if (this.validateCredentials(passwordValue, retypePasswordValue) && !Ember.isEmpty(otpValue)) {
        let otpExponent = this.currentModel.randomChallengeData.exponent;
        let otpModulus = this.currentModel.randomChallengeData.modulus;
        let otpBase64Challenge = this.currentModel.randomChallengeData.base64Challenge;
        let encryptedSmsOtp = hex2b64(rsaEncrypt(otpExponent, otpModulus, otpValue + '_-_' + otpBase64Challenge));
        let encryptedPassword = hex2b64(rsaEncrypt(otpExponent, otpModulus, passwordValue + '_-_' + otpBase64Challenge));
        this.get('store').unloadAll('hr-login');
        let hrCreateRequest = this.get('store').createRecord('hrLogin', {
          id: this.currentModel.modelData.id,
          action: this.currentModel.modelData.actionType,
          countryCode: this.controllerFor('agent-login').inputParams.countryCode,
          companyCode: this.controllerFor('agent-login').inputParams.companyCode,
          hrEmpId: this.controllerFor('agent-login').inputParams.hrEmployeeId,
          encryptValue: encryptedPassword,
          encryptOtp: encryptedSmsOtp,
          otpSerialNo: this.currentModel.modelData.otpSerialNo
        });

        try {
          this.get('rdcLoadingIndicator').showLoadingIndicatorForPromise(hrCreateRequest.save()).then(responseData => {
            this.controllerFor('agent-login').set('responseData', responseData);
            this.clearLoginInputs();
            this.transitionTo('agent-login');
          }, error => {
            this.showLoginError(error);
            this.clearLoginInputs();
          });
        } catch (error) {
          this.showLoginError(error);
          this.clearLoginInputs();
        }
      }
    },

    actions: {
      agentRegister() {
        this.agentRegister();
      },

      navigateToRegistration() {
        this.clearLoginInputs();
        this.transitionTo('agent-registration');
      }

    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/routes/kaifailure", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Route.extend({
    actions: {
      didTransition: function () {
        Ember.Logger.debug('Failure Iframe redirect');
        Ember.run.later(this, function () {
          Ember.Logger.debug('Failure inner before close');
          window.close();
          Ember.Logger.debug('Failure inner after close');
        }, 5000);
      }
    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/routes/kaisuccess", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Route.extend({
    actions: {
      didTransition: function () {
        Ember.Logger.debug('Success Iframe redirect');
        window.top.postMessage({
          loginSuccess: true
        }, '*');
      }
    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/routes/login", ["exports", "ember-uuid"], function (_exports, _emberUuid) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Route.extend({
    rdcLoadingIndicator: Ember.inject.service(),
    rdcModalManager: Ember.inject.service(),
    i18n: Ember.inject.service(),
    urlParamsVal: null,

    setupController(controller) {
      controller.set("isCN", this.country === "CN");
      controller.set("showCaptchaLoading", this.captchaEnabled === "Y");
    },

    beforeModel() {
      this.rdcLoadingIndicator.showLoadingIndicator(" ");
      let srcURL = document.location.href;
      let hostURL = srcURL.split("?")[0];
      this.set('hostURL', hostURL);

      if (srcURL) {
        srcURL = srcURL.split("?")[1];

        if (srcURL) {
          srcURL = srcURL.split("&");
          srcURL.forEach(item => {
            if (item.indexOf("client_id") != -1) {
              this.set("clientId", "client_id=" + item.split("=")[1]);
            } else if (item.indexOf("state") != -1) {
              this.set("stateVal", "state=" + item.split("=")[1]);
            } else if (item.indexOf("redirect_uri") != -1) {
              this.set("redirectUri", "redirect_uri=" + item.split("=")[1]);
            } else if (item.indexOf("ctry") != -1) {
              this.set("country", item.split("=")[1]);
            } else if (item.indexOf("lang") != -1) {
              this.set("language", item.split("=")[1]);
            } else if (item.indexOf("captchaEnabled") != -1) {
              this.set("captchaEnabled", item.split("=")[1]);
            }
          });
          let urlParams = {
            clientId: this.clientId.split("=")[1],
            stateVal: this.stateVal.split("=")[1],
            redirectUri: this.redirectUri.split("=")[1],
            country: this.country
          };
          this.set("urlParamsloc", urlParams);
        }
      }
    },

    model() {
      const requestId = (0, _emberUuid.v4)();
      let country = this.country;
      let path = this.hostURL;
      let url = "/retail/api/v3/oauth2/authorize?response_type=code&" + this.clientId + "&" + this.stateVal + "&" + this.redirectUri + "&request_id=" + requestId + "&ctry=" + country + "&language=" + this.language + "&captchaEnabled=" + this.captchaEnabled;
      Ember.$.ajax({
        url: url,
        type: 'GET',
        beforeSend: function (req) {
          req.setRequestHeader("Accept", "application/json");

          if (path.toUpperCase().indexOf(country) != -1) {
            req.setRequestHeader("country", country);
          }
        }
      }).then(response => {
        Ember.run(() => {
          this.rdcLoadingIndicator.hideLoadingIndicator();
          this.controller.set('resNonce', response.nonce);
          this.controller.set('tmxId', requestId);
          this.controller.set('resExponent', response.extraApplicationProperties.exponent);
          this.controller.set('resModulus', response.extraApplicationProperties.modulus);
          this.controller.set('resScope', response.proposedScope);
          this.controller.set("urlParamsVal", this.urlParamsloc);
          this.controller.set("isWormholeEnabled", true);
          this.controller.set("captchaCode", !Ember.isEmpty(response.extraApplicationProperties.captchaCode) ? response.extraApplicationProperties.captchaCode : "");
          this.controller.set("nfsSessionId", !Ember.isEmpty(response.extraApplicationProperties.nfsSessionId) ? response.extraApplicationProperties.nfsSessionId : "");
          this.controller.set("showCaptchaLoading", false);
        });
      }).fail(() => {
        this.rdcModalManager.showDialogModal({
          level: "error",
          message: this.i18n.t("errors.unknownError"),
          acceptButtonLabel: this.i18n.t("generic.ok"),
          customClass: "login-app-popup"
        });
        this.rdcLoadingIndicator.hideLoadingIndicator();
      });
    },

    actions: {
      redirect(getUrl, target = '_self') {
        window.open(getUrl, target);
      },

      renewCaptcha() {
        this.controller.set("showCaptchaLoading", true);
        let url = "/retail/api/v3/auth/captcha/generate";
        let data = {
          country: this.country,
          channel: this.clientId.split("=")[1],
          language: this.i18n.locale,
          appVersion: "3.0",
          deviceName: "device",
          deviceInfo: navigator.appVersion
        };
        Ember.$.ajax({
          url: url,
          data: JSON.stringify(data),
          dataType: "json",
          contentType: 'application/json',
          type: 'POST'
        }).then(response => {
          Ember.run(() => {
            this.controller.set("showCaptchaLoading", false);
            this.controller.set("captchaCode", "data:image/gif;base64, " + response.captchaImage);
            this.controller.set("nfsSessionId", response.sessionId);
            return;
          });
        }).fail(() => {
          this.controller.set("showCaptchaLoading", false);
          this.rdcModalManager.showDialogModal({
            level: "error",
            message: this.i18n.t("errors.captchaError"),
            acceptButtonLabel: this.i18n.t("generic.ok"),
            customClass: "login-app-popup"
          });
        });
      }

    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/routes/open-banking-consent-permission", ["exports", "rdc-ui-app-login/mixins/csl-authenticated-route-mixin"], function (_exports, _cslAuthenticatedRouteMixin) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Route.extend(_cslAuthenticatedRouteMixin.default, {
    rdcAjax: Ember.inject.service(),
    store: Ember.inject.service(),
    cslLoginHeaders: Ember.inject.service(),
    session: Ember.inject.service(),
    ajax: Ember.inject.service(),
    rdcModalManager: Ember.inject.service(),
    i18n: Ember.inject.service(),

    beforeModel(param) {
      this._super(...arguments);

      if (Object.keys(param.queryParams).length != 0) {
        // if request id is empty 6 digit random number adding
        param.queryParams.request_id = param.queryParams.request_id ? param.queryParams.request_id : Math.floor(100000 + Math.random() * 900000);
        let queryString = Object.keys(param.queryParams).map(key => key + '=' + encodeURIComponent(param.queryParams[key])).join('&');
        this.cslLoginHeaders.set('queryParams', queryString);
        this.cslLoginHeaders.set('queryObject', JSON.parse('{"' + decodeURI(queryString).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g, '":"') + '"}'));
      }
    },

    model() {
      return this.store.query('authorize', {}).then(data => {
        return data.firstObject;
      });
    },

    setupController(contoller) {
      this._super(...arguments);

      if (this.cslLoginHeaders.queryObject) {
        contoller.set('scope', this.cslLoginHeaders.queryObject['scope']);
      }
    },

    actions: {
      error(err) {
        if (err && err.errors[0] && err.errors[0].code === "OB-AUTH-001") {
          const error = err.errors[0];
          const errorMsgDetail = error && error.meta && error.meta.details;
          this.rdcModalManager.showDialogModal({
            level: "error",
            message: errorMsgDetail,
            acceptButtonLabel: this.i18n.t("generic.ok")
          });
        } else {
          this.rdcModalManager.showDialogModal({
            level: "error",
            message: this.i18n.t("errors.genericError"),
            acceptButtonLabel: this.i18n.t("generic.ok")
          });
          err && err.status == 401 ? this.session.invalidate() : '';
        }
      }

    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/routes/open-banking-login", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Route.extend({
    cslLoginHeaders: Ember.inject.service(),

    beforeModel(param) {
      this._super(...arguments);

      if (Object.keys(param.queryParams).length != 0) {
        // if request id is empty 6 digit random number adding
        param.queryParams.request_id = param.queryParams.request_id ? param.queryParams.request_id : Math.floor(100000 + Math.random() * 900000);
        let queryString = Object.keys(param.queryParams).map(key => key + '=' + encodeURIComponent(param.queryParams[key])).join('&');
        this.cslLoginHeaders.set('queryParams', queryString);
      }
    }

  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/routes/refappsuccess", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Route.extend({
    beforeModel: function (transition) {
      Ember.Logger.debug('Success Iframe redirect');
      let redirectUri = transition.queryParams.redirectUri;
      let state = transition.queryParams.state;
      Ember.Logger.debug('redirectUri: ' + transition.queryParams.redirectUri);
      Ember.Logger.debug('state: ' + state);
      window.location.replace(redirectUri + "?state=" + state);
    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/routes/restricted-route", ["exports", "rdc-ui-adn-core/routes/restricted-route"], function (_exports, _restrictedRoute) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _restrictedRoute.default;
    }
  });
});
;define("rdc-ui-app-login/routes/staff-login", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Route.extend({});

  _exports.default = _default;
});
;define("rdc-ui-app-login/serializers/account-proxy", ["exports", "rdc-ui-adn-core/serializers/account-proxy"], function (_exports, _accountProxy) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _accountProxy.default;
    }
  });
});
;define("rdc-ui-app-login/serializers/application", ["exports", "rdc-ui-adn-core/serializers/application"], function (_exports, _application) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _application.default;
    }
  });
});
;define("rdc-ui-app-login/serializers/authorize", ["exports", "ember-data"], function (_exports, _emberData) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = _emberData.default.JSONAPISerializer.extend({
    normalizeQueryResponse(store, primaryModelClass, payload) {
      let formattedPayload = {
        data: [{
          id: "1",
          type: "authorize",
          attributes: {
            accounts: payload.accounts,
            permissions: payload.permissions,
            permissionsAsStrings: payload.permissionsAsStrings,
            clientId: payload.clientId,
            nonce: payload.nonce,
            state: payload.state,
            redirectUri: payload.redirectUri,
            responseType: payload.responseType,
            extraApplicationProperties: payload.extraApplicationProperties
          }
        }]
      };
      return formattedPayload;
    }

  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/serializers/country", ["exports", "rdc-ui-adn-core/serializers/country"], function (_exports, _country) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _country.default;
    }
  });
});
;define("rdc-ui-app-login/serializers/customer", ["exports", "rdc-ui-adn-core/serializers/customer"], function (_exports, _customer) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _customer.default;
    }
  });
});
;define("rdc-ui-app-login/serializers/delivery-ack", ["exports", "rdc-ui-adn-core/serializers/delivery-ack"], function (_exports, _deliveryAck) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _deliveryAck.default;
    }
  });
});
;define("rdc-ui-app-login/serializers/notification", ["exports", "rdc-ui-adn-core/serializers/notification"], function (_exports, _notification) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _notification.default;
    }
  });
});
;define("rdc-ui-app-login/serializers/payment", ["exports", "rdc-ui-adn-core/serializers/payment"], function (_exports, _payment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _payment.default;
    }
  });
});
;define("rdc-ui-app-login/services/adobe-data-service", ["exports", "rdc-ui-adn-core/services/adobe-data-service"], function (_exports, _adobeDataService) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _adobeDataService.default;
    }
  });
});
;define("rdc-ui-app-login/services/adobe-service", ["exports", "rdc-ui-adn-core/services/adobe-service"], function (_exports, _adobeService) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _adobeService.default;
    }
  });
});
;define("rdc-ui-app-login/services/ajax", ["exports", "ember-ajax/services/ajax"], function (_exports, _ajax) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _ajax.default;
    }
  });
});
;define("rdc-ui-app-login/services/axway-config", ["exports", "rdc-ui-adn-core/services/axway-config"], function (_exports, _axwayConfig) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _axwayConfig.default;
    }
  });
});
;define("rdc-ui-app-login/services/burger-menu", ["exports", "rdc-ui-adn-components/services/burger-menu"], function (_exports, _burgerMenu) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _burgerMenu.default;
    }
  });
});
;define("rdc-ui-app-login/services/config", ["exports", "rdc-ui-adn-core/services/config"], function (_exports, _config) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _config.default;
    }
  });
});
;define("rdc-ui-app-login/services/cookies", ["exports", "ember-cookies/services/cookies"], function (_exports, _cookies) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _cookies.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/services/csl-login-headers", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Service.extend({});

  _exports.default = _default;
});
;define("rdc-ui-app-login/services/face-auth-manager", ["exports", "rdc-ui-adn-core/services/face-auth-manager"], function (_exports, _faceAuthManager) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _faceAuthManager.default;
    }
  });
});
;define("rdc-ui-app-login/services/fap", ["exports", "rdc-ui-adn-core/services/fap"], function (_exports, _fap) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _fap.default;
    }
  });
});
;define("rdc-ui-app-login/services/file-queue", ["exports", "ember-file-upload/services/file-queue"], function (_exports, _fileQueue) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _fileQueue.default;
    }
  });
});
;define("rdc-ui-app-login/services/i18n", ["exports", "ember-i18n/services/i18n"], function (_exports, _i18n) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _i18n.default;
    }
  });
});
;define("rdc-ui-app-login/services/idle-session-timer", ["exports", "rdc-ui-adn-core/services/idle-session-timer"], function (_exports, _idleSessionTimer) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _idleSessionTimer.default;
    }
  });
});
;define("rdc-ui-app-login/services/iframe-manager", ["exports", "rdc-ui-adn-components/services/iframe-manager"], function (_exports, _iframeManager) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _iframeManager.default;
    }
  });
});
;define("rdc-ui-app-login/services/liquid-fire-transitions", ["exports", "liquid-fire/transition-map"], function (_exports, _transitionMap) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _transitionMap.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/services/login-client", ["exports", "ember-concurrency"], function (_exports, _emberConcurrency) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.Service.extend({
    router: Ember.inject.service(),
    rdcLoadingIndicator: Ember.inject.service(),
    rdcModalManager: Ember.inject.service(),
    i18n: Ember.inject.service(),
    accCode: "",
    initlogin: (0, _emberConcurrency.task)(function* (bsoiSecurityParams, identification, password, captcha, nfsSessionId, resScope, tmxId) {
      let results;

      if (bsoiSecurityParams.urlParamsVal.redirectUri !== undefined && bsoiSecurityParams.urlParamsVal.redirectUri.includes("ref-app")) {
        results = yield this.encryptPassword(bsoiSecurityParams, identification, password, null, resScope, tmxId);
      } else {
        results = yield this.encryptPassword(bsoiSecurityParams, identification, password, captcha, nfsSessionId, resScope, tmxId);
      }

      if (results != undefined) {
        if (results[0] == 'CN') {
          window.location.href = results[1];
        } else {
          this.rdcLoadingIndicator.hideLoadingIndicator();
          this.set("accCode", results[0]);

          if (bsoiSecurityParams.urlParamsVal.redirectUri != undefined && bsoiSecurityParams.urlParamsVal.redirectUri.includes("ref-app")) {
            this.router.transitionTo("refappsuccess", {
              queryParams: {
                redirectUri: bsoiSecurityParams.urlParamsVal.redirectUri,
                state: bsoiSecurityParams.urlParamsVal.stateVal
              }
            });
          } else {
            this.router.transitionTo("kaisuccess");
          }
        }
      }
    }).drop(),

    encryptPassword(params, identification, password, captcha, nfsSessionId, resScope, tmxId) {
      let i18nVar = this.i18n.locale;
      let encpass = encrypt(params.e2eRsaExponent, params.e2eRsaModulus, params.securityNonce, password);
      let url = "/retail/api/v3/oauth2/authorize/decision";
      let data = {
        client_id: params.urlParamsVal.clientId,
        scope: resScope,
        state: params.urlParamsVal.stateVal,
        redirect_uri: params.urlParamsVal.redirectUri,
        username: identification,
        password: encpass,
        nonce: params.securityNonce,
        country: !Ember.isEmpty(params.urlParamsVal.country) ? params.urlParamsVal.country : "HK",
        channel: "IBNK",
        language: i18nVar,
        captcha: captcha,
        nfs_session_id: nfsSessionId
      };
      return Ember.$.ajax({
        url: url,
        type: 'POST',
        contentType: 'application/x-www-form-urlencoded',
        data: data,
        headers: {
          "TMX-SESSION-ID": tmxId
        }
      }).then(response => {
        let resp = response.split(",");
        return resp;
      }).fail(response => {
        let errorMsg = this.i18n.t("errors.unknownError");
        let tmxErrorFlag = false;

        if (response.responseJSON) {
          if (response.responseJSON.error != undefined && response.responseJSON.error == "Login failed") {
            errorMsg = this.i18n.t("login.errorMessages.wrongUserNamePassword");
          }

          let tmxError = response.responseJSON.error_description;

          if (tmxError == "CSL-TMX-666" || tmxError == "CSL-TMX-667") {
            errorMsg = this.i18n.t("errors." + tmxError);
            tmxErrorFlag = true;
          }
        }

        this.rdcModalManager.showDialogModal({
          level: "error",
          message: errorMsg,
          acceptButtonLabel: this.i18n.t("generic.ok"),
          customClass: "login-app-popup"
        }).then(() => {
          if (tmxErrorFlag) {
            window.top.postMessage({
              loginSuccess: 'immediate'
            }, '*');
          }

          window.location.reload();
        });
        this.rdcLoadingIndicator.hideLoadingIndicator();
      });
    }

  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/services/media", ["exports", "ember-responsive/services/media"], function (_exports, _media) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _media.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/services/moment", ["exports", "ember-moment/services/moment", "rdc-ui-app-login/config/environment"], function (_exports, _moment, _environment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  const {
    get
  } = Ember;

  var _default = _moment.default.extend({
    defaultFormat: get(_environment.default, 'moment.outputFormat')
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/services/otp-manager", ["exports", "rdc-ui-adn-core/services/otp-manager"], function (_exports, _otpManager) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _otpManager.default;
    }
  });
});
;define("rdc-ui-app-login/services/raven", ["exports", "ember-cli-sentry/services/raven", "raven"], function (_exports, _raven, _raven2) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  /* eslint-disable no-console */
  var _default = _raven.default.extend({
    config: Ember.inject.service(),

    init() {
      this._super(...arguments);

      this.setTagsContext({
        target: this.get('config.target'),
        buildTarget: this.get('config.buildTarget')
      });
    },

    log(message, options = {}) {
      let {
        level = 'into',
        category = 'general',
        showOnConsole = true
      } = options;
      let breadcrumb = {
        level: level,
        category: category
      };
      typeof message === 'string' ? breadcrumb['message'] = message : breadcrumb['data'] = message;
      this.captureBreadcrumb(breadcrumb);
      if (showOnConsole) console.log(breadcrumb);
    },

    setUserContext(context) {
      this.callRaven('setUserContext', context);
    },

    setExtraContext(context) {
      this.callRaven('setExtraContext', context);
    },

    setTagsContext(context) {
      this.callRaven('setTagsContext', context);
    },

    captureException(error) {
      if (this.isRavenUsable) {
        _raven2.default.captureException(...arguments);
      } else {
        console.log(error);
      }
    }

  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/services/rdc-accordion", ["exports", "rdc-ui-adn-components/services/rdc-accordion"], function (_exports, _rdcAccordion) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcAccordion.default;
    }
  });
});
;define("rdc-ui-app-login/services/rdc-ajax", ["exports", "rdc-ui-adn-core/services/rdc-ajax"], function (_exports, _rdcAjax) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcAjax.default;
    }
  });
});
;define("rdc-ui-app-login/services/rdc-doc-viewer", ["exports", "rdc-ui-adn-components/services/rdc-doc-viewer"], function (_exports, _rdcDocViewer) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcDocViewer.default;
    }
  });
});
;define("rdc-ui-app-login/services/rdc-file-upload", ["exports", "rdc-ui-adn-components/services/rdc-file-upload"], function (_exports, _rdcFileUpload) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcFileUpload.default;
    }
  });
});
;define("rdc-ui-app-login/services/rdc-loading-indicator", ["exports", "rdc-ui-adn-components/services/rdc-loading-indicator"], function (_exports, _rdcLoadingIndicator) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcLoadingIndicator.default;
    }
  });
});
;define("rdc-ui-app-login/services/rdc-mobile-detector", ["exports", "rdc-ui-adn-components/services/rdc-mobile-detector"], function (_exports, _rdcMobileDetector) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcMobileDetector.default;
    }
  });
});
;define("rdc-ui-app-login/services/rdc-modal-manager", ["exports", "rdc-ui-adn-components/services/rdc-modal-manager"], function (_exports, _rdcModalManager) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _rdcModalManager.default;
    }
  });
});
;define("rdc-ui-app-login/services/session", ["exports", "ember-simple-auth/services/session"], function (_exports, _session) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  var _default = _session.default;
  _exports.default = _default;
});
;define("rdc-ui-app-login/services/soft-token-otp-manager", ["exports", "rdc-ui-adn-core/services/soft-token-otp-manager"], function (_exports, _softTokenOtpManager) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _softTokenOtpManager.default;
    }
  });
});
;define("rdc-ui-app-login/services/text-measurer", ["exports", "ember-text-measurer/services/text-measurer"], function (_exports, _textMeasurer) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _textMeasurer.default;
    }
  });
});
;define("rdc-ui-app-login/services/threat-metrix", ["exports", "rdc-ui-adn-core/services/threat-metrix"], function (_exports, _threatMetrix) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _threatMetrix.default;
    }
  });
});
;define("rdc-ui-app-login/services/transaction-pwd-manager", ["exports", "rdc-ui-adn-core/services/transaction-pwd-manager"], function (_exports, _transactionPwdManager) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _transactionPwdManager.default;
    }
  });
});
;define("rdc-ui-app-login/session-stores/application", ["exports", "ember-simple-auth/session-stores/adaptive"], function (_exports, _adaptive) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = _adaptive.default.extend();

  _exports.default = _default;
});
;define("rdc-ui-app-login/storages/user-preferences", ["exports", "rdc-ui-adn-core/storages/user-preferences"], function (_exports, _userPreferences) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _userPreferences.default;
    }
  });
});
;define("rdc-ui-app-login/templates/agent-login", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.HTMLBars.template({
    "id": "+YZp/U8O",
    "block": "{\"symbols\":[],\"statements\":[[7,\"header\"],[11,\"class\",\"fere-desktop-header agent-header\"],[9],[0,\"\\n  \"],[7,\"div\"],[11,\"class\",\"right-header-button\"],[9],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"save-exit-btn\"],[9],[0,\"\\n      \"],[7,\"i\"],[11,\"class\",\"icon uxlab-icon-sc-s-phone-call\"],[9],[10],[0,\"\\n      \"],[7,\"span\"],[11,\"class\",\"name\"],[9],[0,\"\\n        \"],[1,[27,\"t\",[\"login.custCareNo\"],null],false],[0,\"\\n      \"],[10],[0,\"\\n    \"],[10],[0,\"\\n    \"],[7,\"img\"],[11,\"src\",\"https://av.sc.com/corp-en/content/images/standardchartered@2x.png\"],[11,\"alt\",\"logo\"],[9],[10],[0,\"\\n  \"],[10],[0,\"\\n\"],[10],[0,\"\\n\"],[7,\"div\"],[11,\"class\",\"rdc-view-wrapper login-view pane-login agent-login\"],[9],[0,\"\\n  \"],[7,\"div\"],[11,\"class\",\"login-view___scroll-content\"],[9],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"view-content\"],[9],[0,\"\\n      \"],[7,\"div\"],[11,\"class\",\"agent-login-box\"],[9],[0,\"\\n        \"],[7,\"h1\"],[9],[0,\"\\n          \"],[1,[27,\"t\",[\"login.enter_your_agent_details\"],null],false],[0,\"\\n        \"],[10],[0,\"\\n        \"],[7,\"div\"],[11,\"class\",\"login-details-div\"],[9],[0,\"\\n          \"],[7,\"div\"],[11,\"class\",\"inputs-wrapper\"],[9],[0,\"\\n            \"],[1,[27,\"rdc-login-textbox\",null,[[\"placeholder\",\"value\",\"name\",\"class\",\"maxlength\"],[[27,\"t\",[\"login.user_name\"],null],[23,[\"identification\"]],\"input-username\",\"rdc-login-username\",16]]],false],[0,\"\\n            \"],[7,\"div\"],[11,\"class\",\"password-wrapper\"],[9],[0,\"\\n              \"],[1,[27,\"rdc-login-textbox\",null,[[\"type\",\"placeholder\",\"value\",\"name\",\"class\",\"maxlength\"],[\"password\",[27,\"t\",[\"login.password\"],null],[23,[\"password\"]],\"input-password\",\"rdc-login-password\",16]]],false],[0,\"\\n            \"],[10],[0,\"\\n          \"],[10],[0,\"\\n          \"],[7,\"div\"],[11,\"class\",\"login-buttons-holder\"],[9],[0,\"\\n            \"],[7,\"a\"],[11,\"href\",\"javascript:;\"],[11,\"class\",\"rdc-button rdc-button---primary uppercase rdc-login-button\"],[11,\"name\",\"btn-login\"],[9],[0,\"\\n              \"],[1,[27,\"t\",[\"generic.login\"],null],false],[0,\"\\n            \"],[3,\"action\",[[22,0,[]],\"login\"]],[10],[0,\"\\n          \"],[10],[0,\"\\n          \"],[7,\"div\"],[11,\"class\",\"agent-forgot-link\"],[9],[0,\"\\n            \"],[1,[27,\"t\",[\"login.forgot_agent_details\"],null],false],[0,\"\\n          \"],[3,\"action\",[[22,0,[]],\"navigateToRegistration\",\"reset\"]],[10],[0,\"\\n        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n    \"],[10],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"agent-registration-block\"],[9],[0,\"\\n      \"],[7,\"span\"],[11,\"class\",\"register-text\"],[9],[1,[27,\"t\",[\"login.registration_agent\"],null],false],[10],[0,\"\\n      \"],[7,\"span\"],[11,\"class\",\"register-button\"],[9],[1,[27,\"t\",[\"login.registerLabel\"],null],false],[3,\"action\",[[22,0,[]],\"navigateToRegistration\",\"create\"]],[10],[0,\"\\n    \"],[10],[0,\"\\n  \"],[10],[0,\"\\n\"],[10],[0,\"\\n\"]],\"hasEval\":false}",
    "meta": {
      "moduleName": "rdc-ui-app-login/templates/agent-login.hbs"
    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/templates/agent-registration", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.HTMLBars.template({
    "id": "bu463DRs",
    "block": "{\"symbols\":[],\"statements\":[[7,\"header\"],[11,\"class\",\"fere-desktop-header agent-header\"],[9],[0,\"\\n  \"],[7,\"div\"],[11,\"class\",\"right-header-button\"],[9],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"save-exit-btn\"],[9],[0,\"\\n      \"],[7,\"i\"],[11,\"class\",\"icon uxlab-icon-sc-s-phone-call\"],[9],[10],[0,\"\\n      \"],[7,\"span\"],[11,\"class\",\"name\"],[9],[0,\"\\n        \"],[1,[27,\"t\",[\"login.custCareNo\"],null],false],[0,\"\\n      \"],[10],[0,\"\\n    \"],[10],[0,\"\\n    \"],[7,\"img\"],[11,\"src\",\"https://av.sc.com/corp-en/content/images/standardchartered@2x.png\"],[11,\"alt\",\"logo\"],[9],[10],[0,\"\\n  \"],[10],[0,\"\\n\"],[10],[0,\"\\n\"],[7,\"div\"],[11,\"class\",\"rdc-view-wrapper agent-registration\"],[9],[0,\"\\n  \"],[7,\"div\"],[11,\"class\",\"row fere-page-container \"],[9],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"left-column col-xs-12 col-md-7\"],[9],[0,\"\\n      \"],[7,\"div\"],[11,\"class\",\"rdc-fere-scroll-form rdc-fere-scroll-content has-footer rdc-view rdc-fere\"],[9],[0,\"\\n        \"],[7,\"div\"],[11,\"class\",\"rdc-app-title-header\"],[9],[0,\"\\n          \"],[7,\"h1\"],[9],[1,[27,\"t\",[\"login.register_header\"],null],false],[10],[0,\"\\n        \"],[10],[0,\"\\n        \"],[7,\"div\"],[11,\"class\",\"userid-text\"],[9],[0,\"\\n          \"],[1,[27,\"log\",[[23,[\"hasError\"]]],null],false],[0,\"\\n          \"],[5,\"rdc-textbox\",[],[[\"@type\",\"@value\",\"@label\",\"@required\",\"@noCopyAndPaste\",\"@maxlength\",\"@hasError\",\"@errorLabel\"],[\"text\",[21,\"loginIdValue\"],[27,\"t\",[\"login.loginId\"],null],true,true,\"16\",[21,\"hasError\"],[21,\"errorLabel\"]]]],[0,\"\\n        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n      \"],[7,\"div\"],[11,\"class\",\"rdc-fere-footer\"],[9],[0,\"\\n        \"],[7,\"div\"],[11,\"class\",\"fere-nav-button-group\"],[9],[0,\"\\n          \"],[7,\"button\"],[11,\"class\",\"rdc-button fere-nav-button-group___nav-buttons left-btn rdc-button---secondary ember-view\"],[11,\"type\",\"secondary\"],[9],[0,\"\\n            \"],[7,\"span\"],[9],[10],[0,\"\\n          \"],[3,\"action\",[[22,0,[]],[23,[\"send\"]],\"navigateToLogin\"]],[10],[0,\"\\n          \"],[7,\"button\"],[11,\"class\",\"rdc-button fere-nav-button-group___nav-buttons right-btn rdc-button---primary ember-view\"],[11,\"type\",\"primary\"],[9],[0,\"\\n            \"],[7,\"span\"],[9],[10],[0,\"\\n          \"],[3,\"action\",[[22,0,[]],[23,[\"send\"]],\"register\"]],[10],[0,\"\\n        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n    \"],[10],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"right-column col-xs-12 col-md-5\"],[9],[10],[0,\"\\n  \"],[10],[0,\"\\n\"],[10],[0,\"\\n\"]],\"hasEval\":false}",
    "meta": {
      "moduleName": "rdc-ui-app-login/templates/agent-registration.hbs"
    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/templates/application", ["exports", "rdc-ui-adn-core/templates/application"], function (_exports, _application) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _application.default;
    }
  });
});
;define("rdc-ui-app-login/templates/get-agent-data", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.HTMLBars.template({
    "id": "EVhtkrPZ",
    "block": "{\"symbols\":[],\"statements\":[[7,\"header\"],[11,\"class\",\"fere-desktop-header agent-header\"],[9],[0,\"\\n  \"],[7,\"div\"],[11,\"class\",\"right-header-button\"],[9],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"save-exit-btn\"],[9],[0,\"\\n      \"],[7,\"i\"],[11,\"class\",\"icon uxlab-icon-sc-s-phone-call\"],[9],[10],[0,\"\\n      \"],[7,\"span\"],[11,\"class\",\"name\"],[9],[0,\"\\n        \"],[1,[27,\"t\",[\"login.custCareNo\"],null],false],[0,\"\\n      \"],[10],[0,\"\\n    \"],[10],[0,\"\\n    \"],[7,\"img\"],[11,\"src\",\"https://av.sc.com/corp-en/content/images/standardchartered@2x.png\"],[11,\"alt\",\"logo\"],[9],[10],[0,\"\\n  \"],[10],[0,\"\\n\"],[10],[0,\"\\n\"],[7,\"div\"],[11,\"class\",\"rdc-view-wrapper agent-registration\"],[9],[0,\"\\n  \"],[7,\"div\"],[11,\"class\",\"row fere-page-container \"],[9],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"left-column col-xs-12 col-md-7\"],[9],[0,\"\\n      \"],[7,\"div\"],[11,\"class\",\"rdc-fere-scroll-form rdc-fere-scroll-content has-footer rdc-view rdc-fere\"],[9],[0,\"\\n        \"],[7,\"div\"],[11,\"class\",\"rdc-app-title-header\"],[9],[0,\"\\n          \"],[7,\"h1\"],[9],[1,[27,\"t\",[\"login.register_header\"],null],false],[10],[0,\"\\n        \"],[10],[0,\"\\n        \"],[7,\"div\"],[11,\"class\",\"otp-field\"],[9],[0,\"\\n            \"],[5,\"rdc-textbox\",[],[[\"@prefix\",\"@type\",\"@value\",\"@label\",\"@required\",\"@noCopyAndPaste\",\"@maxlength\"],[[23,[\"model\",\"modelData\",\"otpPrefix\"]],\"number\",[21,\"otpValue\"],[27,\"t\",[\"login.register_otp\"],null],\"required\",true,\"6\"]]],[0,\"\\n        \"],[10],[0,\"\\n        \"],[7,\"div\"],[11,\"class\",\"first-text\"],[9],[0,\"\\n          \"],[1,[27,\"rdc-textbox\",null,[[\"type\",\"value\",\"label\",\"required\",\"noCopyAndPaste\",\"maxlength\"],[\"password\",[23,[\"passwordValue\"]],[27,\"t\",[\"login.register_newPwd\"],null],[23,[\"required\"]],true,16]]],false],[0,\"\\n        \"],[10],[0,\"\\n        \"],[7,\"div\"],[12,\"class\",[28,[\"retype-input \",[27,\"if\",[[27,\"or\",[[23,[\"hasError2\"]],[23,[\"mismatchMessage\"]]],null],\"has-errors\"],null]]]],[9],[0,\"\\n          \"],[1,[27,\"rdc-textbox\",null,[[\"type\",\"value\",\"label\",\"required\",\"noCopyAndPaste\",\"maxlength\"],[\"password\",[23,[\"retypePasswordValue\"]],[27,\"t\",[\"login.register_reconfirm\"],null],[23,[\"required\"]],true,16]]],false],[0,\"\\n        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n      \"],[7,\"div\"],[11,\"class\",\"rdc-fere-footer\"],[9],[0,\"\\n        \"],[7,\"div\"],[11,\"class\",\"fere-nav-button-group\"],[9],[0,\"\\n          \"],[7,\"button\"],[11,\"class\",\"rdc-button fere-nav-button-group___nav-buttons left-btn rdc-button---secondary ember-view\"],[11,\"type\",\"secondary\"],[9],[0,\"\\n            \"],[7,\"span\"],[9],[10],[0,\"\\n          \"],[3,\"action\",[[22,0,[]],[23,[\"send\"]],\"navigateToRegistration\"]],[10],[0,\"\\n          \"],[7,\"button\"],[11,\"class\",\"rdc-button fere-nav-button-group___nav-buttons right-btn rdc-button---primary ember-view\"],[11,\"type\",\"primary\"],[9],[0,\"\\n            \"],[7,\"span\"],[9],[10],[0,\"\\n          \"],[3,\"action\",[[22,0,[]],[23,[\"send\"]],\"agentRegister\"]],[10],[0,\"\\n        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n    \"],[10],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"right-column col-xs-12 col-md-5\"],[9],[10],[0,\"\\n  \"],[10],[0,\"\\n\"],[10],[0,\"\\nSaaZ\"]],\"hasEval\":false}",
    "meta": {
      "moduleName": "rdc-ui-app-login/templates/get-agent-data.hbs"
    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/templates/kaifailure", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.HTMLBars.template({
    "id": "zVB/vIQA",
    "block": "{\"symbols\":[],\"statements\":[[7,\"div\"],[11,\"class\",\"rdc-view-wrapper login-view pane-login kaipanel\"],[9],[0,\"\\n  \"],[7,\"div\"],[11,\"class\",\"login-view___scroll-content\"],[9],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"view-content kaifailure\"],[9],[0,\"\\n      \"],[7,\"h2\"],[9],[0,\"\\n        \"],[7,\"span\"],[9],[0,\"\\n          Login Failed\\n        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n    \"],[10],[0,\"\\n  \"],[10],[0,\"\\n\"],[10]],\"hasEval\":false}",
    "meta": {
      "moduleName": "rdc-ui-app-login/templates/kaifailure.hbs"
    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/templates/kaisuccess", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.HTMLBars.template({
    "id": "kVqHr1H7",
    "block": "{\"symbols\":[],\"statements\":[[7,\"div\"],[11,\"class\",\"rdc-view-wrapper login-view pane-login kaipanel\"],[9],[0,\"\\n  \"],[7,\"div\"],[11,\"class\",\"login-view___scroll-content\"],[9],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"view-content kaisuccess\"],[9],[0,\"\\n      \"],[7,\"h2\"],[9],[0,\"\\n        \"],[7,\"span\"],[9],[0,\"\\n          Login Successful\\n        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n    \"],[10],[0,\"\\n  \"],[10],[0,\"\\n\"],[10]],\"hasEval\":false}",
    "meta": {
      "moduleName": "rdc-ui-app-login/templates/kaisuccess.hbs"
    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/templates/login", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.HTMLBars.template({
    "id": "gBliOTMd",
    "block": "{\"symbols\":[],\"statements\":[[7,\"div\"],[11,\"class\",\"rdc-view-wrapper login-view pane-login\"],[9],[0,\"\\n\"],[0,\"  \"],[7,\"div\"],[11,\"class\",\"login-view___scroll-content\"],[9],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"view-content\"],[9],[0,\"\\n      \"],[7,\"h1\"],[9],[0,\"\\n        \"],[7,\"span\"],[9],[0,\"\\n          \"],[1,[27,\"t\",[\"login.heading\"],null],false],[0,\"\\n        \"],[10],[0,\"\\n        \"],[7,\"span\"],[11,\"href\",\"javascript:;\"],[11,\"class\",\"country-trigger\"],[11,\"name\",\"btn-country\"],[9],[0,\"\\n\"],[4,\"if\",[[23,[\"isCN\"]]],null,{\"statements\":[[0,\"            \"],[7,\"i\"],[11,\"class\",\"flag-icon country-CN\"],[9],[10],[0,\"\\n\"]],\"parameters\":[]},{\"statements\":[[0,\"            \"],[7,\"i\"],[11,\"class\",\"flag-icon country-HK\"],[9],[10],[0,\"\\n\"]],\"parameters\":[]}],[0,\"          \"],[7,\"i\"],[11,\"class\",\"sc-icon uxlab-icon-sc-s-arrow-down-02\"],[9],[10],[0,\"\\n        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n      \"],[7,\"div\"],[11,\"class\",\"inputs-wrapper\"],[9],[0,\"\\n        \"],[1,[27,\"rdc-login-textbox\",null,[[\"placeholder\",\"value\",\"name\",\"class\",\"maxlength\"],[[27,\"t\",[\"login.user_name\"],null],[23,[\"identification\"]],\"input-username\",\"rdc-login-username\",16]]],false],[0,\"\\n        \"],[7,\"div\"],[11,\"class\",\"password-wrapper\"],[9],[0,\"\\n          \"],[1,[27,\"rdc-login-textbox\",null,[[\"type\",\"placeholder\",\"value\",\"name\",\"class\",\"maxlength\"],[\"password\",[27,\"t\",[\"login.password\"],null],[23,[\"password\"]],\"input-password\",\"rdc-login-password\",16]]],false],[0,\"\\n\"],[4,\"if\",[[23,[\"mobilePlatform\"]]],null,{\"statements\":[[0,\"            \"],[7,\"a\"],[11,\"href\",\"javascript:;\"],[11,\"name\",\"btn-forgot-password\"],[11,\"class\",\"forgot-password ember-view\"],[9],[0,\"\\n              \"],[1,[27,\"t\",[\"login.forgot\"],null],false],[0,\"\\n            \"],[3,\"action\",[[22,0,[]],\"redirect\",[27,\"t\",[\"login.forgotPasswordUrl\"],null]]],[10],[0,\"\\n\"]],\"parameters\":[]},{\"statements\":[[4,\"if\",[[23,[\"isRedirectUri\"]]],null,{\"statements\":[[0,\"              \"],[7,\"a\"],[11,\"href\",\"javascript:;\"],[11,\"name\",\"btn-forgot-password\"],[11,\"class\",\"forgot-password ember-view\"],[9],[0,\"\\n                \"],[1,[27,\"t\",[\"login.forgot\"],null],false],[0,\"\\n              \"],[3,\"action\",[[22,0,[]],\"redirect\",[27,\"t\",[\"login.forgotPasswordUrl\"],null]]],[10],[0,\"\\n\"]],\"parameters\":[]},{\"statements\":[[4,\"if\",[[23,[\"isMobile\"]]],null,{\"statements\":[[4,\"ral-link\",null,[[\"classNames\",\"name\",\"url\"],[\"forgot-password\",\"btn-forgot-password\",[27,\"t\",[\"login.forgotPasswordUrlWeb\"],null]]],{\"statements\":[[0,\"                  \"],[1,[27,\"t\",[\"login.forgot\"],null],false],[0,\"\\n\"]],\"parameters\":[]},null]],\"parameters\":[]},{\"statements\":[[0,\"                \"],[7,\"a\"],[11,\"href\",\"javascript:;\"],[11,\"name\",\"btn-forgot-password\"],[11,\"class\",\"forgot-password ember-view\"],[9],[0,\"\\n                  \"],[1,[27,\"t\",[\"login.forgot\"],null],false],[0,\"\\n                \"],[3,\"action\",[[22,0,[]],\"redirect\",[27,\"t\",[\"login.forgotPasswordUrlWeb\"],null],\"_blank\"]],[10],[0,\"\\n\"]],\"parameters\":[]}]],\"parameters\":[]}]],\"parameters\":[]}],[0,\"        \"],[10],[0,\"\\n\"],[4,\"if\",[[23,[\"isCN\"]]],null,{\"statements\":[[0,\"          \"],[7,\"div\"],[11,\"class\",\"login-view-captchaBox\"],[9],[0,\"\\n            \"],[7,\"div\"],[11,\"class\",\"login-view-captchaInputBox\"],[9],[0,\"\\n              \"],[1,[27,\"rdc-login-textbox\",null,[[\"placeholder\",\"value\",\"name\",\"class\",\"maxlength\"],[[27,\"t\",[\"login.captcha\"],null],[23,[\"captcha\"]],\"input-captcha\",\"rdc-login-password\",6]]],false],[0,\"\\n            \"],[10],[0,\"\\n            \"],[7,\"div\"],[11,\"class\",\"login-view-captchaCode\"],[9],[0,\"\\n\"],[4,\"if\",[[23,[\"showCaptchaLoading\"]]],null,{\"statements\":[[0,\"                \"],[7,\"img\"],[11,\"class\",\"rdc-load-more___image\"],[11,\"src\",\"rdc-ui-adn-components/assets/images/loading-grey.gif\"],[11,\"alt\",\"loading\"],[9],[10],[0,\"\\n\"]],\"parameters\":[]},{\"statements\":[[0,\"                \"],[7,\"img\"],[12,\"src\",[21,\"captchaCode\"]],[11,\"role\",\"button\"],[11,\"class\",\"forgot-password ember-view\"],[11,\"alt\",\"\"],[9],[3,\"action\",[[22,0,[]],\"renewCaptcha\"]],[10],[0,\"\\n\"]],\"parameters\":[]}],[0,\"            \"],[10],[0,\"\\n          \"],[10],[0,\"\\n\"]],\"parameters\":[]},null],[0,\"      \"],[10],[0,\"\\n      \"],[7,\"div\"],[11,\"class\",\"login-buttons-holder\"],[9],[0,\"\\n        \"],[7,\"a\"],[11,\"href\",\"javascript:;\"],[11,\"class\",\"rdc-button rdc-button---primary uppercase rdc-login-button\"],[11,\"name\",\"btn-login\"],[9],[0,\"\\n          \"],[1,[27,\"t\",[\"generic.login\"],null],false],[0,\"\\n        \"],[3,\"action\",[[22,0,[]],\"login\"]],[10],[0,\"\\n      \"],[10],[0,\"\\n\\n\"],[4,\"unless\",[[23,[\"isCN\"]]],null,{\"statements\":[[0,\"        \"],[7,\"div\"],[11,\"class\",\"floating-footer\"],[9],[0,\"\\n\"],[4,\"if\",[[23,[\"media\",\"isMobile\"]]],null,{\"statements\":[[0,\"            \"],[7,\"p\"],[9],[0,\"\\n              \"],[1,[27,\"t\",[\"login.registrationLabel\"],null],false],[0,\"\\n            \"],[10],[0,\"\\n\"]],\"parameters\":[]},{\"statements\":[[0,\"            \"],[7,\"p\"],[9],[0,\"\\n              \"],[1,[27,\"t\",[\"login.registrationLabel_Web\"],null],false],[0,\"\\n            \"],[10],[0,\"\\n\"]],\"parameters\":[]}],[0,\"          \"],[7,\"a\"],[11,\"href\",\"javascript:;\"],[11,\"name\",\"btn-register-here\"],[11,\"class\",\"ember-view\"],[9],[0,\"\\n            \"],[1,[27,\"t\",[\"login.registrationLink\"],null],false],[0,\"\\n          \"],[3,\"action\",[[22,0,[]],\"redirect\",[27,\"t\",[\"login.mobileRegistrationUrl\"],null]]],[10],[0,\"\\n        \"],[10],[0,\"\\n\"]],\"parameters\":[]},null],[0,\"    \"],[10],[0,\"\\n  \"],[10],[0,\"\\n\"],[10],[0,\"\\n\\n\"],[4,\"if\",[[23,[\"isWormholeEnabled\"]]],null,{\"statements\":[[4,\"ember-wormhole\",null,[[\"to\"],[\"app-login\"]],{\"statements\":[[0,\"    \"],[7,\"iframe\"],[11,\"style\",\"width: 100px; height: 100px; border: 0; position: absolute; top: -5000px;\"],[12,\"src\",[28,[\"https://svc2.sc.com/fp/tags?org_id=49jnml1b&session_id=\",[21,\"tmxId\"]]]],[9],[10],[0,\"\\n\"]],\"parameters\":[]},null]],\"parameters\":[]},null]],\"hasEval\":false}",
    "meta": {
      "moduleName": "rdc-ui-app-login/templates/login.hbs"
    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/templates/open-banking-consent-permission", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.HTMLBars.template({
    "id": "8OeAFwKu",
    "block": "{\"symbols\":[\"account\",\"permission\"],\"statements\":[[7,\"div\"],[11,\"class\",\"rdc-view-wrapper view-authorize-access view-responsive\"],[9],[0,\"\\n\"],[0,\"  \"],[1,[27,\"rdc-navbar\",null,[[\"title\",\"showLeftNavigation\",\"showRightNavigation\"],[\"Authorise Access\",false,false]]],false],[0,\"\\n\\n  \"],[7,\"div\"],[11,\"class\",\"rdc-scroll-content has-padded-footer\"],[9],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"logo-wrapper\"],[9],[0,\"\\n      \"],[7,\"img\"],[11,\"src\",\"assets/svg/sc-logo-colour.svg\"],[11,\"alt\",\"Standard Chartered Logo\"],[11,\"class\",\"sc-logo\"],[9],[10],[0,\"\\n      \"],[7,\"span\"],[11,\"class\",\"seperator\"],[9],[10],[0,\"\\n      \"],[7,\"h1\"],[11,\"class\",\"title\"],[9],[0,\"\\n        Authorise Third Party Access\\n      \"],[10],[0,\"\\n    \"],[10],[0,\"\\n\\n    \"],[7,\"div\"],[11,\"class\",\"content-wrapper\"],[9],[0,\"\\n      \"],[7,\"div\"],[11,\"class\",\"heading-section\"],[9],[0,\"\\n\"],[0,\"        \"],[7,\"img\"],[11,\"src\",\"assets/Tarabut_Logo.png\"],[11,\"alt\",\"Standard Chartered Logo\"],[11,\"width\",\"80\"],[11,\"height\",\"80\"],[11,\"class\",\"sc-logo\"],[9],[10],[0,\"\\n        \"],[7,\"p\"],[9],[0,\"\\n          \"],[7,\"span\"],[11,\"class\",\"strong\"],[9],[0,\"\\n            TARABUT GATEWAY\\n          \"],[10],[0,\"\\n          is requesting access to your selected account(s).\\n        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n      \"],[7,\"p\"],[11,\"class\",\"section-title section-title\"],[9],[0,\"\\n        This will allow them to\\n      \"],[10],[0,\"\\n      \"],[7,\"ul\"],[11,\"class\",\"authorize-item-list\"],[9],[0,\"\\n\"],[4,\"each\",[[23,[\"model\",\"permissionsAsStrings\"]]],null,{\"statements\":[[0,\"          \"],[7,\"li\"],[9],[0,\"\\n            \"],[1,[22,2,[]],false],[0,\"\\n          \"],[10],[0,\"\\n\"]],\"parameters\":[2]},null],[0,\"      \"],[10],[0,\"\\n\\n      \"],[7,\"p\"],[11,\"class\",\"section-title section-title\"],[9],[0,\"\\n        Grant Permissions for\\n      \"],[10],[0,\"\\n      \"],[7,\"ul\"],[11,\"class\",\"account-list\"],[9],[0,\"\\n        \"],[7,\"li\"],[9],[0,\"\\n\"],[4,\"each\",[[23,[\"model\",\"parsedAccounts\"]]],null,{\"statements\":[[4,\"rdc-checkbox\",null,[[\"selected\",\"action\",\"readonly\"],[[22,1,[\"consent_permission\"]],[27,\"action\",[[22,0,[]],\"toggleAccount\",[22,1,[]]],null],[23,[\"readonly\"]]]],{\"statements\":[[0,\"              \"],[7,\"div\"],[11,\"class\",\"account-info\"],[9],[0,\"\\n                \"],[7,\"label\"],[11,\"class\",\"account-name\"],[9],[0,\"\\n                  \"],[1,[22,1,[\"product_description\"]],false],[0,\"\\n                \"],[10],[0,\"\\n                \"],[7,\"label\"],[11,\"class\",\"account-number\"],[9],[0,\"\\n                  \"],[1,[22,1,[\"account_number\"]],false],[0,\"\\n                \"],[10],[0,\"\\n              \"],[10],[0,\"\\n\"]],\"parameters\":[]},null]],\"parameters\":[1]},null],[0,\"        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n\\n      \"],[7,\"p\"],[11,\"class\",\"description-info mt20\"],[9],[0,\"\\n        By Granting access, you are allowing the above mentioned third party to access your accounts information.\\n      \"],[10],[0,\"\\n    \"],[10],[0,\"\\n  \"],[10],[0,\"\\n\\n  \"],[7,\"div\"],[11,\"class\",\"rdc-view___footer padded open-api\"],[9],[0,\"\\n    \"],[1,[27,\"rdc-button\",null,[[\"default\",\"name\",\"type\",\"action\"],[\"DECLINE\",\"Decline\",\"secondary\",[27,\"action\",[[22,0,[]],\"deny\"],null]]]],false],[0,\"\\n\"],[4,\"rdc-button\",null,[[\"name\",\"type\",\"action\"],[\"Grant Access\",\"primary\",[27,\"action\",[[22,0,[]],\"allow\"],null]]],{\"statements\":[[4,\"if\",[[23,[\"isRunning\"]]],null,{\"statements\":[[0,\"        \"],[1,[21,\"rdc-spinner\"],false],[0,\"\\n\"]],\"parameters\":[]},{\"statements\":[[0,\"        GRANT ACCESS\\n\"]],\"parameters\":[]}]],\"parameters\":[]},null],[0,\"  \"],[10],[0,\"\\n\\n  \"],[7,\"form\"],[12,\"action\",[21,\"decisionURL\"]],[11,\"method\",\"POST\"],[11,\"id\",\"consent-form\"],[9],[0,\"\\n    \"],[7,\"input\"],[11,\"name\",\"client_id\"],[12,\"value\",[23,[\"model\",\"clientId\"]]],[11,\"type\",\"hidden\"],[9],[10],[0,\"\\n    \"],[7,\"input\"],[11,\"name\",\"client_Secret\"],[11,\"value\",\"BH_TPP_PRE_123\"],[11,\"type\",\"hidden\"],[9],[10],[0,\"\\n    \"],[7,\"input\"],[11,\"name\",\"nonce\"],[12,\"value\",[23,[\"model\",\"nonce\"]]],[11,\"type\",\"hidden\"],[9],[10],[0,\"\\n    \"],[7,\"input\"],[11,\"name\",\"state\"],[12,\"value\",[23,[\"model\",\"state\"]]],[11,\"type\",\"hidden\"],[9],[10],[0,\"\\n    \"],[7,\"input\"],[11,\"name\",\"redirect_uri\"],[12,\"value\",[23,[\"model\",\"redirectUri\"]]],[11,\"type\",\"hidden\"],[9],[10],[0,\"\\n    \"],[7,\"input\"],[11,\"name\",\"response_type\"],[12,\"value\",[23,[\"model\",\"responseType\"]]],[11,\"type\",\"hidden\"],[9],[10],[0,\"\\n    \"],[7,\"input\"],[11,\"name\",\"consent_id\"],[12,\"value\",[23,[\"model\",\"extraApplicationProperties\",\"ConsentId\"]]],[11,\"type\",\"hidden\"],[9],[10],[0,\"\\n    \"],[7,\"input\"],[11,\"name\",\"scope\"],[12,\"value\",[21,\"scope\"]],[11,\"type\",\"hidden\"],[9],[10],[0,\"\\n    \"],[7,\"input\"],[11,\"name\",\"oauthDecision\"],[11,\"value\",\"allow\"],[11,\"type\",\"hidden\"],[9],[10],[0,\"\\n    \"],[7,\"input\"],[11,\"name\",\"accounts\"],[12,\"value\",[21,\"selectedAccounts\"]],[11,\"type\",\"hidden\"],[9],[10],[0,\"\\n  \"],[10],[0,\"\\n\"],[10],[0,\"\\n\"],[4,\"if\",[[23,[\"isRunning\"]]],null,{\"statements\":[[0,\"  \"],[1,[27,\"layout/rdc-translucent-overlay\",null,[[\"opacity\"],[0]]],false],[0,\"\\n\"]],\"parameters\":[]},null]],\"hasEval\":false}",
    "meta": {
      "moduleName": "rdc-ui-app-login/templates/open-banking-consent-permission.hbs"
    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/templates/open-banking-login", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.HTMLBars.template({
    "id": "SlAUJzFn",
    "block": "{\"symbols\":[],\"statements\":[[7,\"div\"],[11,\"class\",\"rdc-view-wrapper login-view pane-login\"],[9],[0,\"\\n\"],[0,\"  \"],[7,\"div\"],[11,\"class\",\"login-view___scroll-content\"],[9],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"view-content\"],[9],[0,\"\\n      \"],[7,\"h1\"],[9],[0,\"\\n        \"],[7,\"span\"],[9],[0,\"\\n          \"],[1,[27,\"t\",[\"login.heading\"],null],false],[0,\"\\n        \"],[10],[0,\"\\n        \"],[7,\"span\"],[11,\"href\",\"javascript:;\"],[11,\"class\",\"country-trigger\"],[11,\"name\",\"btn-country\"],[9],[0,\"\\n          \"],[7,\"i\"],[12,\"class\",[28,[\"flag-icon country-\",[21,\"country\"]]]],[9],[10],[0,\"\\n          \"],[7,\"i\"],[11,\"class\",\"sc-icon uxlab-icon-sc-s-arrow-down-02\"],[9],[10],[0,\"\\n        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n      \"],[7,\"div\"],[11,\"class\",\"inputs-wrapper\"],[9],[0,\"\\n        \"],[1,[27,\"rdc-login-textbox\",null,[[\"placeholder\",\"value\",\"name\",\"class\",\"keyPress\",\"maxlength\"],[[27,\"t\",[\"login.user_name\"],null],[23,[\"identification\"]],\"input-username\",\"rdc-login-username\",[27,\"action\",[[22,0,[]],\"keyPress\"],null],16]]],false],[0,\"\\n        \"],[7,\"div\"],[11,\"class\",\"password-wrapper\"],[9],[0,\"\\n          \"],[1,[27,\"rdc-login-textbox\",null,[[\"type\",\"placeholder\",\"value\",\"name\",\"class\",\"keyPress\",\"maxlength\"],[\"password\",[27,\"t\",[\"login.password\"],null],[23,[\"password\"]],\"input-password\",\"rdc-login-password\",[27,\"action\",[[22,0,[]],\"keyPress\"],null],16]]],false],[0,\"\\n        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n      \"],[7,\"div\"],[11,\"class\",\"login-buttons-holder\"],[9],[0,\"\\n        \"],[7,\"a\"],[11,\"href\",\"javascript:;\"],[11,\"class\",\"rdc-button rdc-button---primary uppercase rdc-login-button\"],[11,\"name\",\"btn-login\"],[9],[0,\"\\n\"],[4,\"if\",[[23,[\"isRunning\"]]],null,{\"statements\":[[0,\"            \"],[1,[21,\"rdc-spinner\"],false],[0,\"\\n\"]],\"parameters\":[]},{\"statements\":[[0,\"            \"],[1,[27,\"t\",[\"generic.login\"],null],false],[0,\"\\n\"]],\"parameters\":[]}],[0,\"        \"],[3,\"action\",[[22,0,[]],\"login\"]],[10],[0,\"\\n      \"],[10],[0,\"\\n    \"],[10],[0,\"\\n  \"],[10],[0,\"\\n\"],[10]],\"hasEval\":false}",
    "meta": {
      "moduleName": "rdc-ui-app-login/templates/open-banking-login.hbs"
    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/templates/staff-login", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;

  var _default = Ember.HTMLBars.template({
    "id": "SvQE74Jz",
    "block": "{\"symbols\":[],\"statements\":[[7,\"div\"],[11,\"class\",\"rdc-view-wrapper login-view pane-login\"],[9],[0,\"\\n\"],[0,\"  \"],[7,\"div\"],[11,\"class\",\"login-view___scroll-content\"],[9],[0,\"\\n    \"],[7,\"div\"],[11,\"class\",\"view-content\"],[9],[0,\"\\n      \"],[7,\"h1\"],[9],[0,\"\\n        \"],[7,\"span\"],[9],[0,\"\\n          \"],[1,[27,\"t\",[\"login.enter_your_staff_details\"],null],false],[0,\"\\n        \"],[10],[0,\"\\n        \"],[7,\"span\"],[11,\"href\",\"javascript:;\"],[11,\"class\",\"country-trigger\"],[11,\"name\",\"btn-country\"],[9],[0,\"\\n          \"],[7,\"i\"],[12,\"class\",[28,[\"flag-icon country-\",[21,\"country\"]]]],[9],[10],[0,\"\\n          \"],[7,\"i\"],[11,\"class\",\"sc-icon uxlab-icon-sc-s-arrow-down-02\"],[9],[10],[0,\"\\n        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n      \"],[7,\"div\"],[11,\"class\",\"inputs-wrapper\"],[9],[0,\"\\n        \"],[1,[27,\"rdc-login-textbox\",null,[[\"placeholder\",\"value\",\"name\",\"class\",\"maxlength\"],[[27,\"t\",[\"login.user_name\"],null],[23,[\"identification\"]],\"input-username\",\"rdc-login-username\",16]]],false],[0,\"\\n        \"],[7,\"div\"],[11,\"class\",\"password-wrapper\"],[9],[0,\"\\n          \"],[1,[27,\"rdc-login-textbox\",null,[[\"type\",\"placeholder\",\"value\",\"name\",\"class\",\"maxlength\"],[\"password\",[27,\"t\",[\"login.password\"],null],[23,[\"password\"]],\"input-password\",\"rdc-login-password\",16]]],false],[0,\"\\n        \"],[10],[0,\"\\n      \"],[10],[0,\"\\n      \"],[7,\"div\"],[11,\"class\",\"login-buttons-holder\"],[9],[0,\"\\n        \"],[7,\"a\"],[11,\"href\",\"javascript:;\"],[11,\"class\",\"rdc-button rdc-button---primary uppercase rdc-login-button\"],[11,\"name\",\"btn-login\"],[9],[0,\"\\n\"],[4,\"if\",[[23,[\"isRunning\"]]],null,{\"statements\":[[0,\"            \"],[1,[21,\"rdc-spinner\"],false],[0,\"\\n\"]],\"parameters\":[]},{\"statements\":[[0,\"            \"],[1,[27,\"t\",[\"generic.login\"],null],false],[0,\"\\n\"]],\"parameters\":[]}],[0,\"        \"],[3,\"action\",[[22,0,[]],\"login\"]],[10],[0,\"\\n      \"],[10],[0,\"\\n    \"],[10],[0,\"\\n  \"],[10],[0,\"\\n\"],[10],[0,\"\\n\"]],\"hasEval\":false}",
    "meta": {
      "moduleName": "rdc-ui-app-login/templates/staff-login.hbs"
    }
  });

  _exports.default = _default;
});
;define("rdc-ui-app-login/transitions/cross-fade", ["exports", "liquid-fire/transitions/cross-fade"], function (_exports, _crossFade) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _crossFade.default;
    }
  });
});
;define("rdc-ui-app-login/transitions/default", ["exports", "liquid-fire/transitions/default"], function (_exports, _default) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _default.default;
    }
  });
});
;define("rdc-ui-app-login/transitions/explode", ["exports", "liquid-fire/transitions/explode"], function (_exports, _explode) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _explode.default;
    }
  });
});
;define("rdc-ui-app-login/transitions/fade", ["exports", "liquid-fire/transitions/fade"], function (_exports, _fade) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _fade.default;
    }
  });
});
;define("rdc-ui-app-login/transitions/flex-grow", ["exports", "liquid-fire/transitions/flex-grow"], function (_exports, _flexGrow) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _flexGrow.default;
    }
  });
});
;define("rdc-ui-app-login/transitions/fly-to", ["exports", "liquid-fire/transitions/fly-to"], function (_exports, _flyTo) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _flyTo.default;
    }
  });
});
;define("rdc-ui-app-login/transitions/move-over", ["exports", "liquid-fire/transitions/move-over"], function (_exports, _moveOver) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _moveOver.default;
    }
  });
});
;define("rdc-ui-app-login/transitions/scale", ["exports", "liquid-fire/transitions/scale"], function (_exports, _scale) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _scale.default;
    }
  });
});
;define("rdc-ui-app-login/transitions/scroll-then", ["exports", "liquid-fire/transitions/scroll-then"], function (_exports, _scrollThen) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _scrollThen.default;
    }
  });
});
;define("rdc-ui-app-login/transitions/to-down", ["exports", "liquid-fire/transitions/to-down"], function (_exports, _toDown) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _toDown.default;
    }
  });
});
;define("rdc-ui-app-login/transitions/to-left", ["exports", "liquid-fire/transitions/to-left"], function (_exports, _toLeft) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _toLeft.default;
    }
  });
});
;define("rdc-ui-app-login/transitions/to-right", ["exports", "liquid-fire/transitions/to-right"], function (_exports, _toRight) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _toRight.default;
    }
  });
});
;define("rdc-ui-app-login/transitions/to-up", ["exports", "liquid-fire/transitions/to-up"], function (_exports, _toUp) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _toUp.default;
    }
  });
});
;define("rdc-ui-app-login/transitions/wait", ["exports", "liquid-fire/transitions/wait"], function (_exports, _wait) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _wait.default;
    }
  });
});
;define("rdc-ui-app-login/utils/constants", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.randomString = _exports.openAPIURL = _exports.openAPI = void 0;
  const openAPI = {
    AUTH_GRANT: '/retail/v1/oauth2/authorize?',
    AUTH_DECISION: '/retail/v1/oauth2/authorize/decision'
  }; // For open banking login retail.sc.com should point api.sc.com and test-retail.sc.com should point test-api.sc.com

  _exports.openAPI = openAPI;

  const openAPIURL = function (hostName) {
    let splittedHost = hostName.split('.');
    splittedHost[0] = splittedHost[0] == 'test-retail' ? 'test-api' : splittedHost[0] == 'retail' ? 'api' : null;
    let customHostName = splittedHost[0] ? `https://${splittedHost.join('.')}` : '';
    return {
      AUTH_GRANT: `${customHostName}/retail/v1/oauth2/authorize?`,
      AUTH_DECISION: `${customHostName}/retail/v1/oauth2/authorize/decision`
    };
  };

  _exports.openAPIURL = openAPIURL;

  const randomString = function (lengthToGenerate) {
    let chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz'.split('');

    if (!lengthToGenerate) {
      lengthToGenerate = Math.floor(Math.random() * chars.length);
    }

    let str = '';

    for (let i = 0; i < lengthToGenerate; i++) {
      str += chars[Math.floor(Math.random() * chars.length)];
    }

    return str;
  };

  _exports.randomString = randomString;
});
;define("rdc-ui-app-login/utils/i18n/compile-template", ["exports", "ember-i18n/utils/i18n/compile-template"], function (_exports, _compileTemplate) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _compileTemplate.default;
    }
  });
});
;define("rdc-ui-app-login/utils/i18n/missing-message", ["exports", "ember-i18n/utils/i18n/missing-message"], function (_exports, _missingMessage) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _missingMessage.default;
    }
  });
});
;define("rdc-ui-app-login/utils/uuid-generator", ["exports", "ember-uuid/utils/uuid-generator"], function (_exports, _uuidGenerator) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _uuidGenerator.default;
    }
  });
  Object.defineProperty(_exports, "v4", {
    enumerable: true,
    get: function () {
      return _uuidGenerator.v4;
    }
  });
  Object.defineProperty(_exports, "v1", {
    enumerable: true,
    get: function () {
      return _uuidGenerator.v1;
    }
  });
  Object.defineProperty(_exports, "parse", {
    enumerable: true,
    get: function () {
      return _uuidGenerator.parse;
    }
  });
  Object.defineProperty(_exports, "unparse", {
    enumerable: true,
    get: function () {
      return _uuidGenerator.unparse;
    }
  });
});
;define("rdc-ui-app-login/validators/alias", ["exports", "ember-cp-validations/validators/alias"], function (_exports, _alias) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _alias.default;
    }
  });
});
;define("rdc-ui-app-login/validators/belongs-to", ["exports", "ember-cp-validations/validators/belongs-to"], function (_exports, _belongsTo) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _belongsTo.default;
    }
  });
});
;define("rdc-ui-app-login/validators/collection", ["exports", "ember-cp-validations/validators/collection"], function (_exports, _collection) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _collection.default;
    }
  });
});
;define("rdc-ui-app-login/validators/confirmation", ["exports", "ember-cp-validations/validators/confirmation"], function (_exports, _confirmation) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _confirmation.default;
    }
  });
});
;define("rdc-ui-app-login/validators/date", ["exports", "ember-cp-validations/validators/date"], function (_exports, _date) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _date.default;
    }
  });
});
;define("rdc-ui-app-login/validators/dependent", ["exports", "ember-cp-validations/validators/dependent"], function (_exports, _dependent) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _dependent.default;
    }
  });
});
;define("rdc-ui-app-login/validators/ds-error", ["exports", "ember-cp-validations/validators/ds-error"], function (_exports, _dsError) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _dsError.default;
    }
  });
});
;define("rdc-ui-app-login/validators/exclusion", ["exports", "ember-cp-validations/validators/exclusion"], function (_exports, _exclusion) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _exclusion.default;
    }
  });
});
;define("rdc-ui-app-login/validators/format", ["exports", "ember-cp-validations/validators/format"], function (_exports, _format) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _format.default;
    }
  });
});
;define("rdc-ui-app-login/validators/has-many", ["exports", "ember-cp-validations/validators/has-many"], function (_exports, _hasMany) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _hasMany.default;
    }
  });
});
;define("rdc-ui-app-login/validators/inclusion", ["exports", "ember-cp-validations/validators/inclusion"], function (_exports, _inclusion) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _inclusion.default;
    }
  });
});
;define("rdc-ui-app-login/validators/inline", ["exports", "ember-cp-validations/validators/inline"], function (_exports, _inline) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _inline.default;
    }
  });
});
;define("rdc-ui-app-login/validators/length", ["exports", "ember-cp-validations/validators/length"], function (_exports, _length) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _length.default;
    }
  });
});
;define("rdc-ui-app-login/validators/messages", ["exports", "ember-cp-validations/validators/messages"], function (_exports, _messages) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _messages.default;
    }
  });
});
;define("rdc-ui-app-login/validators/number", ["exports", "ember-cp-validations/validators/number"], function (_exports, _number) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _number.default;
    }
  });
});
;define("rdc-ui-app-login/validators/presence", ["exports", "ember-cp-validations/validators/presence"], function (_exports, _presence) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "default", {
    enumerable: true,
    get: function () {
      return _presence.default;
    }
  });
});
;

;define('rdc-ui-app-login/config/environment', [], function() {
  var prefix = 'rdc-ui-app-login';
try {
  var metaName = prefix + '/config/environment';
  var rawConfig = document.querySelector('meta[name="' + metaName + '"]').getAttribute('content');
  var config = JSON.parse(decodeURIComponent(rawConfig));

  var exports = { 'default': config };

  Object.defineProperty(exports, '__esModule', { value: true });

  return exports;
}
catch(err) {
  throw new Error('Could not read config from meta tag with name "' + metaName + '".');
}

});

;
          if (!runningTests) {
            require("rdc-ui-app-login/app")["default"].create({"name":"rdc-ui-app-login","version":"1.5.1+4a723831"});
          }
        
//# sourceMappingURL=rdc-ui-app-login.map
