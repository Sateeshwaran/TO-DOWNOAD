'use strict';

define("rdc-ui-app-login/tests/helpers/destroy-app", ["exports"], function (_exports) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = destroyApp;

  function destroyApp(application) {
    Ember.run(application, 'destroy');
  }
});
define("rdc-ui-app-login/tests/helpers/ember-i18n/test-helpers", ["ember-i18n/test-support/-private/t", "ember-i18n/test-support/-private/assert-translation"], function (_t2, _assertTranslation2) {
  "use strict";

  // example usage: find(`.header:contains(${t('welcome_message')})`)
  Ember.Test.registerHelper('t', function (app, key, interpolations) {
    return (0, _t2.default)(app.__container__, key, interpolations);
  }); // example usage: expectTranslation('.header', 'welcome_message');

  Ember.Test.registerHelper('expectTranslation', function (app, element, key, interpolations) {
    const text = (0, _t2.default)(app.__container__, key, interpolations);
    (0, _assertTranslation2.default)(element, key, text);
  });
});
define("rdc-ui-app-login/tests/helpers/ember-power-select", ["exports", "ember-power-select/test-support/helpers"], function (_exports, _helpers) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = deprecatedRegisterHelpers;
  _exports.selectChoose = _exports.touchTrigger = _exports.nativeTouch = _exports.clickTrigger = _exports.typeInSearch = _exports.triggerKeydown = _exports.nativeMouseUp = _exports.nativeMouseDown = _exports.findContains = void 0;

  function deprecateHelper(fn, name) {
    return function (...args) {
      (true && !(false) && Ember.deprecate(`DEPRECATED \`import { ${name} } from '../../tests/helpers/ember-power-select';\` is deprecated. Please, replace it with \`import { ${name} } from 'ember-power-select/test-support/helpers';\``, false, {
        until: '1.11.0',
        id: `ember-power-select-test-support-${name}`
      }));
      return fn(...args);
    };
  }

  let findContains = deprecateHelper(_helpers.findContains, 'findContains');
  _exports.findContains = findContains;
  let nativeMouseDown = deprecateHelper(_helpers.nativeMouseDown, 'nativeMouseDown');
  _exports.nativeMouseDown = nativeMouseDown;
  let nativeMouseUp = deprecateHelper(_helpers.nativeMouseUp, 'nativeMouseUp');
  _exports.nativeMouseUp = nativeMouseUp;
  let triggerKeydown = deprecateHelper(_helpers.triggerKeydown, 'triggerKeydown');
  _exports.triggerKeydown = triggerKeydown;
  let typeInSearch = deprecateHelper(_helpers.typeInSearch, 'typeInSearch');
  _exports.typeInSearch = typeInSearch;
  let clickTrigger = deprecateHelper(_helpers.clickTrigger, 'clickTrigger');
  _exports.clickTrigger = clickTrigger;
  let nativeTouch = deprecateHelper(_helpers.nativeTouch, 'nativeTouch');
  _exports.nativeTouch = nativeTouch;
  let touchTrigger = deprecateHelper(_helpers.touchTrigger, 'touchTrigger');
  _exports.touchTrigger = touchTrigger;
  let selectChoose = deprecateHelper(_helpers.selectChoose, 'selectChoose');
  _exports.selectChoose = selectChoose;

  function deprecatedRegisterHelpers() {
    (true && !(false) && Ember.deprecate("DEPRECATED `import registerPowerSelectHelpers from '../../tests/helpers/ember-power-select';` is deprecated. Please, replace it with `import registerPowerSelectHelpers from 'ember-power-select/test-support/helpers';`", false, {
      until: '1.11.0',
      id: 'ember-power-select-test-support-register-helpers'
    }));
    return (0, _helpers.default)();
  }
});
define("rdc-ui-app-login/tests/helpers/ember-simple-auth", ["exports", "ember-simple-auth/authenticators/test"], function (_exports, _test) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.authenticateSession = authenticateSession;
  _exports.currentSession = currentSession;
  _exports.invalidateSession = invalidateSession;
  const TEST_CONTAINER_KEY = 'authenticator:test';

  function ensureAuthenticator(app, container) {
    const authenticator = container.lookup(TEST_CONTAINER_KEY);

    if (!authenticator) {
      app.register(TEST_CONTAINER_KEY, _test.default);
    }
  }

  function deprecateOldTestingApi() {
    Ember.deprecate('Ember Simple Auth: The legacy testing API is deprecated; switch to the new testing helpers available from "ember-simple-auth/test-support".', false, {
      id: `ember-simple-auth.testing.legacy-testing-api`,
      until: '3.0.0'
    });
  }

  function authenticateSession(app, sessionData) {
    deprecateOldTestingApi();
    const {
      __container__: container
    } = app;
    const session = container.lookup('service:session');
    ensureAuthenticator(app, container);
    session.authenticate(TEST_CONTAINER_KEY, sessionData);
    return app.testHelpers.wait();
  }

  function currentSession(app) {
    deprecateOldTestingApi();
    return app.__container__.lookup('service:session');
  }

  function invalidateSession(app) {
    deprecateOldTestingApi();

    const session = app.__container__.lookup('service:session');

    if (session.get('isAuthenticated')) {
      session.invalidate();
    }

    return app.testHelpers.wait();
  }
});
define("rdc-ui-app-login/tests/helpers/module-for-acceptance", ["exports", "qunit", "rdc-ui-app-login/tests/helpers/start-app", "rdc-ui-app-login/tests/helpers/destroy-app"], function (_exports, _qunit, _startApp, _destroyApp) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = _default;

  function _default(name, options = {}) {
    (0, _qunit.module)(name, {
      beforeEach() {
        this.application = (0, _startApp.default)();

        if (options.beforeEach) {
          return options.beforeEach.apply(this, arguments);
        }
      },

      afterEach() {
        let afterEach = options.afterEach && options.afterEach.apply(this, arguments);
        return Ember.RSVP.resolve(afterEach).then(() => (0, _destroyApp.default)(this.application));
      }

    });
  }
});
define("rdc-ui-app-login/tests/helpers/start-app", ["exports", "rdc-ui-app-login/app", "rdc-ui-app-login/config/environment"], function (_exports, _app, _environment) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = startApp;

  function startApp(attrs) {
    let attributes = Ember.merge({}, _environment.default.APP);
    attributes.autoboot = true;
    attributes = Ember.merge(attributes, attrs); // use defaults, but you can override;

    return Ember.run(() => {
      let application = _app.default.create(attributes);

      application.setupForTesting();
      application.injectTestHelpers();
      return application;
    });
  }
});
define("rdc-ui-app-login/tests/helpers/upload", ["exports", "ember-file-upload/test-helpers"], function (_exports, _testHelpers) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  Object.defineProperty(_exports, "upload", {
    enumerable: true,
    get: function () {
      return _testHelpers.upload;
    }
  });
});
define("rdc-ui-app-login/tests/lint/app.lint-test", [], function () {
  "use strict";

  QUnit.module('ESLint | app');
  QUnit.test('adapters/authorize.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'adapters/authorize.js should pass ESLint\n\n');
  });
  QUnit.test('adapters/hr-login.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'adapters/hr-login.js should pass ESLint\n\n');
  });
  QUnit.test('app.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'app.js should pass ESLint\n\n');
  });
  QUnit.test('controllers/agent-login.js', function (assert) {
    assert.expect(1);
    assert.ok(false, 'controllers/agent-login.js should pass ESLint\n\n56:31 - \'hex2b64\' is not defined. (no-undef)\n56:39 - \'rsaEncrypt\' is not defined. (no-undef)');
  });
  QUnit.test('controllers/agent-registration.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'controllers/agent-registration.js should pass ESLint\n\n');
  });
  QUnit.test('controllers/application.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'controllers/application.js should pass ESLint\n\n');
  });
  QUnit.test('controllers/login.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'controllers/login.js should pass ESLint\n\n');
  });
  QUnit.test('controllers/open-banking-consent-permission.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'controllers/open-banking-consent-permission.js should pass ESLint\n\n');
  });
  QUnit.test('controllers/open-banking-login.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'controllers/open-banking-login.js should pass ESLint\n\n');
  });
  QUnit.test('controllers/staff-login.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'controllers/staff-login.js should pass ESLint\n\n');
  });
  QUnit.test('locales/cn/translations.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'locales/cn/translations.js should pass ESLint\n\n');
  });
  QUnit.test('locales/en/config.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'locales/en/config.js should pass ESLint\n\n');
  });
  QUnit.test('locales/en/translations.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'locales/en/translations.js should pass ESLint\n\n');
  });
  QUnit.test('locales/zh-hk/translations.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'locales/zh-hk/translations.js should pass ESLint\n\n');
  });
  QUnit.test('mixins/csl-authenticated-route-mixin.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/csl-authenticated-route-mixin.js should pass ESLint\n\n');
  });
  QUnit.test('mixins/show-error-message.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'mixins/show-error-message.js should pass ESLint\n\n');
  });
  QUnit.test('models/authorize.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/authorize.js should pass ESLint\n\n');
  });
  QUnit.test('models/hr-login.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'models/hr-login.js should pass ESLint\n\n');
  });
  QUnit.test('resolver.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'resolver.js should pass ESLint\n\n');
  });
  QUnit.test('router.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'router.js should pass ESLint\n\n');
  });
  QUnit.test('routes/agent-login.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/agent-login.js should pass ESLint\n\n');
  });
  QUnit.test('routes/agent-registration.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/agent-registration.js should pass ESLint\n\n');
  });
  QUnit.test('routes/application.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/application.js should pass ESLint\n\n');
  });
  QUnit.test('routes/get-agent-data.js', function (assert) {
    assert.expect(1);
    assert.ok(false, 'routes/get-agent-data.js should pass ESLint\n\n54:29 - \'hex2b64\' is not defined. (no-undef)\n55:31 - \'hex2b64\' is not defined. (no-undef)');
  });
  QUnit.test('routes/kaifailure.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/kaifailure.js should pass ESLint\n\n');
  });
  QUnit.test('routes/kaisuccess.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/kaisuccess.js should pass ESLint\n\n');
  });
  QUnit.test('routes/login.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/login.js should pass ESLint\n\n');
  });
  QUnit.test('routes/open-banking-consent-permission.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/open-banking-consent-permission.js should pass ESLint\n\n');
  });
  QUnit.test('routes/open-banking-login.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/open-banking-login.js should pass ESLint\n\n');
  });
  QUnit.test('routes/refappsuccess.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/refappsuccess.js should pass ESLint\n\n');
  });
  QUnit.test('routes/staff-login.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'routes/staff-login.js should pass ESLint\n\n');
  });
  QUnit.test('serializers/authorize.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'serializers/authorize.js should pass ESLint\n\n');
  });
  QUnit.test('services/csl-login-headers.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/csl-login-headers.js should pass ESLint\n\n');
  });
  QUnit.test('services/login-client.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/login-client.js should pass ESLint\n\n');
  });
  QUnit.test('services/raven.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'services/raven.js should pass ESLint\n\n');
  });
  QUnit.test('templates/application.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'templates/application.js should pass ESLint\n\n');
  });
  QUnit.test('utils/constants.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'utils/constants.js should pass ESLint\n\n');
  });
});
define("rdc-ui-app-login/tests/lint/templates.template.lint-test", [], function () {
  "use strict";

  QUnit.module('TemplateLint');
  QUnit.test('rdc-ui-app-login/templates/agent-login.hbs', function (assert) {
    assert.expect(1);
    assert.ok(false, 'rdc-ui-app-login/templates/agent-login.hbs should pass TemplateLint.\n\nrdc-ui-app-login/templates/agent-login.hbs\n  50:41  error  Interaction added to non-interactive element  no-invalid-interactive\n  58:35  error  Interaction added to non-interactive element  no-invalid-interactive\n');
  });
  QUnit.test('rdc-ui-app-login/templates/agent-registration.hbs', function (assert) {
    assert.expect(1);
    assert.ok(false, 'rdc-ui-app-login/templates/agent-registration.hbs should pass TemplateLint.\n\nrdc-ui-app-login/templates/agent-registration.hbs\n  20:10  error  Unexpected {{log}} usage.  no-log\n  27:23  error  Attribute @maxlength should be either quoted or wrapped in mustaches  no-quoteless-attributes\n');
  });
  QUnit.test('rdc-ui-app-login/templates/get-agent-data.hbs', function (assert) {
    assert.expect(1);
    assert.ok(false, 'rdc-ui-app-login/templates/get-agent-data.hbs should pass TemplateLint.\n\nrdc-ui-app-login/templates/get-agent-data.hbs\n  20:12  error  Incorrect indentation for `<RdcTextbox>` beginning at L20:C12. Expected `<RdcTextbox>` to be at an indentation of 10 but was found at 12.  block-indentation\n  27:23  error  Attribute @maxlength should be either quoted or wrapped in mustaches  no-quoteless-attributes\n');
  });
  QUnit.test('rdc-ui-app-login/templates/kaifailure.hbs', function (assert) {
    assert.expect(1);
    assert.ok(true, 'rdc-ui-app-login/templates/kaifailure.hbs should pass TemplateLint.\n\n');
  });
  QUnit.test('rdc-ui-app-login/templates/kaisuccess.hbs', function (assert) {
    assert.expect(1);
    assert.ok(true, 'rdc-ui-app-login/templates/kaisuccess.hbs should pass TemplateLint.\n\n');
  });
  QUnit.test('rdc-ui-app-login/templates/login.hbs', function (assert) {
    assert.expect(1);
    assert.ok(true, 'rdc-ui-app-login/templates/login.hbs should pass TemplateLint.\n\n');
  });
  QUnit.test('rdc-ui-app-login/templates/open-banking-consent-permission.hbs', function (assert) {
    assert.expect(1);
    assert.ok(true, 'rdc-ui-app-login/templates/open-banking-consent-permission.hbs should pass TemplateLint.\n\n');
  });
  QUnit.test('rdc-ui-app-login/templates/open-banking-login.hbs', function (assert) {
    assert.expect(1);
    assert.ok(true, 'rdc-ui-app-login/templates/open-banking-login.hbs should pass TemplateLint.\n\n');
  });
  QUnit.test('rdc-ui-app-login/templates/staff-login.hbs', function (assert) {
    assert.expect(1);
    assert.ok(true, 'rdc-ui-app-login/templates/staff-login.hbs should pass TemplateLint.\n\n');
  });
});
define("rdc-ui-app-login/tests/lint/tests.lint-test", [], function () {
  "use strict";

  QUnit.module('ESLint | tests');
  QUnit.test('helpers/destroy-app.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/destroy-app.js should pass ESLint\n\n');
  });
  QUnit.test('helpers/module-for-acceptance.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/module-for-acceptance.js should pass ESLint\n\n');
  });
  QUnit.test('helpers/start-app.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'helpers/start-app.js should pass ESLint\n\n');
  });
  QUnit.test('test-helper.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'test-helper.js should pass ESLint\n\n');
  });
  QUnit.test('unit/adapters/authorize-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/adapters/authorize-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/adapters/hr-login-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/adapters/hr-login-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/controllers/agent-login-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/controllers/agent-login-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/controllers/agent-registration-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/controllers/agent-registration-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/controllers/application-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/controllers/application-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/controllers/login-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/controllers/login-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/controllers/open-banking-consent-permission-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/controllers/open-banking-consent-permission-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/controllers/open-banking-login-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/controllers/open-banking-login-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/controllers/staff-login-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/controllers/staff-login-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/mixins/csl-authenticated-route-mixin-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/mixins/csl-authenticated-route-mixin-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/mixins/show-error-message-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/mixins/show-error-message-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/models/authorize-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/models/authorize-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/models/hr-login-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/models/hr-login-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/routes/agent-login-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/agent-login-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/routes/agent-registration-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/agent-registration-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/routes/application-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/application-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/routes/get-agent-data-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/get-agent-data-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/routes/kaifailure-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/kaifailure-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/routes/kaisuccess-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/kaisuccess-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/routes/login-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/login-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/routes/open-banking-consent-permission-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/open-banking-consent-permission-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/routes/open-banking-login-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/open-banking-login-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/routes/staff-login-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/routes/staff-login-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/serializers/authorize-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/serializers/authorize-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/services/csl-login-headers-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/services/csl-login-headers-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/services/login-client-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/services/login-client-test.js should pass ESLint\n\n');
  });
  QUnit.test('unit/services/raven-test.js', function (assert) {
    assert.expect(1);
    assert.ok(true, 'unit/services/raven-test.js should pass ESLint\n\n');
  });
});
define("rdc-ui-app-login/tests/test-helper", ["rdc-ui-app-login/app", "rdc-ui-app-login/config/environment", "@ember/test-helpers", "ember-qunit"], function (_app, _environment, _testHelpers, _emberQunit) {
  "use strict";

  (0, _testHelpers.setApplication)(_app.default.create(_environment.default.APP));
  (0, _emberQunit.start)();
});
define("rdc-ui-app-login/tests/unit/adapters/authorize-test", ["ember-qunit"], function (_emberQunit) {
  "use strict";

  (0, _emberQunit.moduleFor)('adapter:authorize', 'Unit | Adapter | authorize', {// Specify the other units that are required for this test.
    // needs: ['serializer:foo']
  }); // Replace this with your real tests.

  (0, _emberQunit.test)('it exists', function (assert) {
    let adapter = this.subject();
    assert.ok(adapter);
  });
});
define("rdc-ui-app-login/tests/unit/adapters/hr-login-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Adapter | hr login', function (hooks) {
    (0, _emberQunit.setupTest)(hooks); // Replace this with your real tests.

    (0, _qunit.test)('it exists', function (assert) {
      let adapter = this.owner.lookup('adapter:hr-login');
      assert.ok(adapter);
    });
  });
});
define("rdc-ui-app-login/tests/unit/controllers/agent-login-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Controller | agent-login', function (hooks) {
    (0, _emberQunit.setupTest)(hooks); // Replace this with your real tests.

    (0, _qunit.test)('it exists', function (assert) {
      let controller = this.owner.lookup('controller:agent-login');
      assert.ok(controller);
    });
  });
});
define("rdc-ui-app-login/tests/unit/controllers/agent-registration-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Controller | agent-registration', function (hooks) {
    (0, _emberQunit.setupTest)(hooks); // Replace this with your real tests.

    (0, _qunit.test)('it exists', function (assert) {
      let controller = this.owner.lookup('controller:agent-registration');
      assert.ok(controller);
    });
  });
});
define("rdc-ui-app-login/tests/unit/controllers/application-test", ["ember-qunit"], function (_emberQunit) {
  "use strict";

  (0, _emberQunit.moduleFor)('controller:application', 'Unit | Controller | application', {// Specify the other units that are required for this test.
    // needs: ['controller:foo']
  }); // Replace this with your real tests.

  (0, _emberQunit.test)('it exists', function (assert) {
    let controller = this.subject();
    assert.ok(controller);
  });
});
define("rdc-ui-app-login/tests/unit/controllers/login-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Controller | login', function (hooks) {
    (0, _emberQunit.setupTest)(hooks); // Replace this with your real tests.

    (0, _qunit.test)('it exists', function (assert) {
      let controller = this.owner.lookup('controller:login');
      assert.ok(controller);
    });
  });
});
define("rdc-ui-app-login/tests/unit/controllers/open-banking-consent-permission-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Controller | open-banking-consent-permission', function (hooks) {
    (0, _emberQunit.setupTest)(hooks); // Replace this with your real tests.

    (0, _qunit.test)('it exists', function (assert) {
      let controller = this.owner.lookup('controller:open-banking-consent-permission');
      assert.ok(controller);
    });
  });
});
define("rdc-ui-app-login/tests/unit/controllers/open-banking-login-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Controller | open-banking-login', function (hooks) {
    (0, _emberQunit.setupTest)(hooks); // Replace this with your real tests.

    (0, _qunit.test)('it exists', function (assert) {
      let controller = this.owner.lookup('controller:open-banking-login');
      assert.ok(controller);
    });
  });
});
define("rdc-ui-app-login/tests/unit/controllers/staff-login-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Controller | staff-login', function (hooks) {
    (0, _emberQunit.setupTest)(hooks); // Replace this with your real tests.

    (0, _qunit.test)('it exists', function (assert) {
      let controller = this.owner.lookup('controller:staff-login');
      assert.ok(controller);
    });
  });
});
define("rdc-ui-app-login/tests/unit/mixins/csl-authenticated-route-mixin-test", ["rdc-ui-app-login/mixins/csl-authenticated-route-mixin", "qunit"], function (_cslAuthenticatedRouteMixin, _qunit) {
  "use strict";

  (0, _qunit.module)('Unit | Mixin | csl-authenticated-route-mixin', function () {
    // Replace this with your real tests.
    (0, _qunit.test)('it works', function (assert) {
      let CslAuthenticatedRouteMixinObject = Ember.Object.extend(_cslAuthenticatedRouteMixin.default);
      let subject = CslAuthenticatedRouteMixinObject.create();
      assert.ok(subject);
    });
  });
});
define("rdc-ui-app-login/tests/unit/mixins/show-error-message-test", ["rdc-ui-app-login/mixins/show-error-message", "qunit"], function (_showErrorMessage, _qunit) {
  "use strict";

  (0, _qunit.module)('Unit | Mixin | showErrorMessage', function () {
    // Replace this with your real tests.
    (0, _qunit.test)('it works', function (assert) {
      let ShowErrorMessageObject = Ember.Object.extend(_showErrorMessage.default);
      let subject = ShowErrorMessageObject.create();
      assert.ok(subject);
    });
  });
});
define("rdc-ui-app-login/tests/unit/models/authorize-test", ["ember-qunit"], function (_emberQunit) {
  "use strict";

  (0, _emberQunit.moduleForModel)('authorize', 'Unit | Model | authorize', {
    // Specify the other units that are required for this test.
    needs: []
  });
  (0, _emberQunit.test)('it exists', function (assert) {
    let model = this.subject(); // let store = this.store();

    assert.ok(!!model);
  });
});
define("rdc-ui-app-login/tests/unit/models/hr-login-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Model | hr login', function (hooks) {
    (0, _emberQunit.setupTest)(hooks); // Replace this with your real tests.

    (0, _qunit.test)('it exists', function (assert) {
      let store = this.owner.lookup('service:store');
      let model = store.createRecord('hr-login', {});
      assert.ok(model);
    });
  });
});
define("rdc-ui-app-login/tests/unit/routes/agent-login-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Route | agent-login', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let route = this.owner.lookup('route:agent-login');
      assert.ok(route);
    });
  });
});
define("rdc-ui-app-login/tests/unit/routes/agent-registration-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Route | agent-registration', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let route = this.owner.lookup('route:agent-registration');
      assert.ok(route);
    });
  });
});
define("rdc-ui-app-login/tests/unit/routes/application-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Route | application', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let route = this.owner.lookup('route:application');
      assert.ok(route);
    });
  });
});
define("rdc-ui-app-login/tests/unit/routes/get-agent-data-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Route | get-agent-data', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let route = this.owner.lookup('route:get-agent-data');
      assert.ok(route);
    });
  });
});
define("rdc-ui-app-login/tests/unit/routes/kaifailure-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Route | kaifailure', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let route = this.owner.lookup('route:kaifailure');
      assert.ok(route);
    });
  });
});
define("rdc-ui-app-login/tests/unit/routes/kaisuccess-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Route | kaisuccess', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let route = this.owner.lookup('route:kaisuccess');
      assert.ok(route);
    });
  });
});
define("rdc-ui-app-login/tests/unit/routes/login-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Route | login', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let route = this.owner.lookup('route:login');
      assert.ok(route);
    });
  });
});
define("rdc-ui-app-login/tests/unit/routes/open-banking-consent-permission-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Route | openBankingConsentPermission', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let route = this.owner.lookup('route:open-banking-consent-permission');
      assert.ok(route);
    });
  });
});
define("rdc-ui-app-login/tests/unit/routes/open-banking-login-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Route | openBankingLogin', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let route = this.owner.lookup('route:open-banking-login');
      assert.ok(route);
    });
  });
});
define("rdc-ui-app-login/tests/unit/routes/staff-login-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Route | staff-login', function (hooks) {
    (0, _emberQunit.setupTest)(hooks);
    (0, _qunit.test)('it exists', function (assert) {
      let route = this.owner.lookup('route:staff-login');
      assert.ok(route);
    });
  });
});
define("rdc-ui-app-login/tests/unit/serializers/authorize-test", ["ember-qunit"], function (_emberQunit) {
  "use strict";

  (0, _emberQunit.moduleForModel)('authorize', 'Unit | Serializer | authorize', {
    // Specify the other units that are required for this test.
    needs: ['serializer:authorize']
  }); // Replace this with your real tests.

  (0, _emberQunit.test)('it serializes records', function (assert) {
    let record = this.subject();
    let serializedRecord = record.serialize();
    assert.ok(serializedRecord);
  });
});
define("rdc-ui-app-login/tests/unit/services/csl-login-headers-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Service | cslLoginHeaders', function (hooks) {
    (0, _emberQunit.setupTest)(hooks); // Replace this with your real tests.

    (0, _qunit.test)('it exists', function (assert) {
      let service = this.owner.lookup('service:csl-login-headers');
      assert.ok(service);
    });
  });
});
define("rdc-ui-app-login/tests/unit/services/login-client-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Service | login-client', function (hooks) {
    (0, _emberQunit.setupTest)(hooks); // Replace this with your real tests.

    (0, _qunit.test)('it exists', function (assert) {
      let service = this.owner.lookup('service:login-client');
      assert.ok(service);
    });
  });
});
define("rdc-ui-app-login/tests/unit/services/raven-test", ["qunit", "ember-qunit"], function (_qunit, _emberQunit) {
  "use strict";

  (0, _qunit.module)('Unit | Service | raven', function (hooks) {
    (0, _emberQunit.setupTest)(hooks); // Replace this with your real tests.

    (0, _qunit.test)('it exists', function (assert) {
      let service = this.owner.lookup('service:raven');
      assert.ok(service);
    });
  });
});
define('rdc-ui-app-login/config/environment', [], function() {
  var prefix = 'rdc-ui-app-login';
try {
  var metaName = prefix + '/config/environment';
  var rawConfig = document.querySelector('meta[name="' + metaName + '"]').getAttribute('content');
  var config = JSON.parse(decodeURIComponent(rawConfig));

  var exports = { 'default': config };

  Object.defineProperty(exports, '__esModule', { value: true });

  return exports;
}
catch(err) {
  throw new Error('Could not read config from meta tag with name "' + metaName + '".');
}

});

require('rdc-ui-app-login/tests/test-helper');
EmberENV.TESTS_FILE_LOADED = true;
//# sourceMappingURL=tests.map
